import re
XMC_IGE=True

if XMC_IGE:
    PASSEDTEST=True
    FAILEDTEST=False
else:
    # EWC Return Codes should be
    PASSEDTEST=False
    FAILEDTEST=True

# Helper functions
def addressInNetwork(ip, net): # returns true when 'ip' is within the 'net'. Ex. addressInNetwork("1.1.1.1", 1.1.1.0/24") returns 'true'
    import socket,struct
    ipaddr = int(''.join([ '%02x' % int(x) for x in ip.split('.') ]), 16)
    netstr, bits = net.split('/')
    netaddr = int(''.join([ '%02x' % int(x) for x in netstr.split('.') ]), 16)
    mask = (0xffffffff << (32 - int(bits))) & 0xffffffff
    return (ipaddr & mask) == (netaddr & mask)

def inverseMask(mask): # accepts an inverted mask and returns a regular maks
    octets = mask.split(".")
    for o in octets:
        o = 255 - o
    mask = ".".join(octets)
    print "inverseMask = [%s]" % mask
    return mask

def netmask_to_cidr(netmask):
    '''
    :param netmask: netmask ip addr (eg: 255.255.255.0)
    :return: equivalent cidr number to given netmask ip (eg: 24)
    '''
    return sum([bin(int(x)).count('1') for x in netmask.split('.')])

def inverseNetmask_to_cidr(netmask):
    return 32 - netmask_to_cidr(netmask)

def getMgmtIp(lines):
    # return the mgmt ipAddress
    for line in lines:
        # Using the mgmt addr, look up the firmware version in the netsight DB
        m = re.search('.+ip\s+address\s+(\d+.\d+.\d+.\d+)\/\d+', line)
        if m:
            ipAddress = m.group(1)
            print("getMgmtIp INFO: Check to see if the ip address [%s] is in XMC's database." % ipAddress)
            if isitinDB(ipAddress):
                print("getMgmtIp INFO: It is!")
                return ipAddress
    print("getMgmtIp Error: None of the IP address are in XMC. This should never happen, check regex")
    return False

def getFirmware(ipaddress):
    # returns the firmware version for a device IP if it exists. Returns False if it does not exist.
    import MySQLdb

    # Open database connection
    # FIXME: Read from configuration...
    db = MySQLdb.connect("localhost","netsight","enterasys","netsight", unix_socket="/tmp/netsight_mysql.sock")

    # prepare a cursor object using cursor() method
    cursor = db.cursor()

    # execute SQL query using execute() method.
    cursor.execute("SELECT FIRMWARE from nsdevices WHERE IP = '%s'" % ipaddress)

    # Fetch a single row using fetchone() method.
    data = cursor.fetchone()
    print "%s => %s" % (ipaddress, data)
    if data:
        # disconnect from server
        db.close()
        return data
    else:
        # disconnect from server
        db.close()
        return False

def isitinDB(ipaddress):
    # returns True is the IP is in the netsight database, False otherwise.
    import MySQLdb

    # Open database connection
    # FIXME: Read from configuration...
    db = MySQLdb.connect("localhost","netsight","enterasys","netsight", unix_socket="/tmp/netsight_mysql.sock")

    # prepare a cursor object using cursor() method
    cursor = db.cursor()

    # execute SQL query using execute() method.
    cursor.execute("SELECT IP from nsdevices WHERE IP = '%s'" % ipaddress)

    # Fetch a single row using fetchone() method.
    data = cursor.fetchone()
    if data:
        # disconnect from server
        db.close()
        print "%s => %s" % (ipaddress, data)
        return True
    else:
        # disconnect from server
        db.close()
        print "%s => Not in DB" % (ipaddress)
        return False


# STIG Tests

def EXOS_NET0340_Login_Banner(audit_node, lines, dev_parsed, xml_log_data, cl):
    import xml.etree.ElementTree as ET
    import glob
    num_matches = 0
    myBanner = ""
    validBanners = []

    # load banner reference files
    bannerPath = "/usr/local/Extreme_Networks/NetSight/GovernanceEngine/audit-tests/STIG/DoD_Banners/"
    bannerFiles = glob.glob('%s*.banner' % bannerPath)
    for bannerFile in bannerFiles:
        print "STIG:EXOS_NET0340_Login_Banner INFO: Banner files are %s" % bannerFile
        with open(bannerFile, 'r') as myfile:
            data = "".join(myfile.read().split()).lower() #remove all whitespace
            validBanners.append(data)

    print "STIG:EXOS_NET0340_Login_Banner INFO: Banner file contents \n%s" % validBanners

    # lines are a list, convert to a string to use the XML parsing
    root = ET.fromstring(''.join(lines))
    # extract banner from configuration file.
    result = root.iter("loginBanner")
    if result:
        print ("result -> %s" % result)
        for c in result :
            print("atrib: %s -> test: %s" % (c.attrib, c.text))
            myBanner = "".join(c.text.replace("\\n","").split()).lower()
            num_matches += 1
            print "STIG:EXOS_NET0340_Login_Banner INFO: Configured banner is %s" % myBanner

    if not myBanner:
        return (FAILEDTEST, "Login banner is not configured in the switch.")

    # compare the configuration banner to all of the valid banners
    for banner in validBanners:
        if myBanner == banner:
            print "STIG:VDX_NET0340_Login_Banner PASS: Configured banner is valid!"
            return (PASSEDTEST, "Valid DoD login banner is present!")

    print "STIG:VDX_NET0340_Login_Banner FAIL"
    return (FAILEDTEST, "Login banner is not present or does not conform to DoD standards. Check the banners present in the folder %s" % bannerPath)



    return (FAILEDTEST, "Login banner is not present or does not conform to DoD standards. Check the banners present in the folder %s" % bannerPath)

def VDX_NET0340_Login_Banner(audit_node, lines, dev_parsed, xml_log_data, cl):
    import glob
    num_matches = 0
    myBanner = ""
    validBanners = []

    # load banner reference files
    bannerPath = "/usr/local/Extreme_Networks/NetSight/GovernanceEngine/audit-tests/STIG/DoD_Banners/"
    bannerFiles = glob.glob('%s*.banner' % bannerPath)
    for bannerFile in bannerFiles:
        print "STIG:VDX_NET0340_Login_Banner INFO: Banner files are %s" % bannerFile
        with open(bannerFile, 'r') as myfile:
            data = "".join(myfile.read().split()).lower() #remove all whitespace
            validBanners.append(data)

    print "STIG:VDX_NET0340_Login_Banner INFO: Banner file contents \n%s" % validBanners

    # extract banner from configuration file.
    for line in lines:
        m = re.search('^banner\s+login(.+)', line)
        if m:
            myBanner = "".join(m.group(1).replace("\\n","").split()).lower()
            num_matches += 1
            print "STIG:VDX_NET0340_Login_Banner INFO: Configured banner is %s" % myBanner
        else:
            pass

    if not myBanner:
        return (FAILEDTEST, "Login banner is not configured in the switch.")

    # compare the configuration banner to all of the valid banners
    for banner in validBanners:
        if myBanner == banner:
            print "STIG:VDX_NET0340_Login_Banner PASS: Configured banner is valid!"
            return (PASSEDTEST, "Valid DoD login banner is present!")

    print "STIG:VDX_NET0340_Login_Banner FAIL"
    return (FAILEDTEST, "Login banner is not present or does not conform to DoD standards. Check the banners present in the folder %s" % bannerPath)

def VDX_NET0408_All_BGP_Peers_Authenticated(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET0408_All_BGP_Peers_Authenticated: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    bgpPeers = []
    bgpAuthPeers = []
    missingBgpPeers = []
    
    # get a list of all bgpPeers
    for line in lines:
        m = re.search('\s+neighbor\s+(\d+.\d+.\d+.\d+)\s+remote-as', line)
        if m:
            bgpPeers.append(m.group(1))

    # get a list of all authenticated bgpPeers
    for line in lines:
        m = re.search('\s+neighbor\s+(\d+.\d+.\d+.\d+)\s+password\s+\d+\s+\S+', line)
        if m:
            bgpAuthPeers.append(m.group(1))
    bgpPeers.sort()
    bgpAuthPeers.sort()

    if bgpPeers == bgpAuthPeers:
        print "STIG:VDX_NET0408_All_BGP_Peers_Authenticated PASS"
        if len(bgpPeers) > 0:
            return (PASSEDTEST, "All BGP Peers are authenticated. %s" %(bgpAuthPeers))
        else:
            return (PASSEDTEST, "No BGP Peers are configured.")
            
    else:
        # Isolate errors: find the difference in the two lists, either the bgp peer or the authentication statement.
        if len(bgpPeers) > len(bgpAuthPeers): # Are there more neighbor remote-as statements?
            missingBgpPeers = list(set(bgpPeers) - set(bgpAuthPeers))

        if len(bgpAuthPeers) > len(bgpPeers): # Are there more neighbor authentication statements?
            missingBgpPeers = list(set(bgpAuthPeers) - set(bgpPeers))

        print "STIG:VDX_NET0408_All_BGP_Peers_Authenticated FAIL"
        return (FAILEDTEST, "BGP peer authentication not conforming to the STIG. Check these BGP Peers: %s." % (missingBgpPeers))


def EXOS_NET0440_Account_last_resort(audit_node, lines, dev_parsed, xml_log_data, cl):
    num_matches = 0
    usingDefaults = []

    for line in lines:
        m = re.search(r'<account><default_val>\d+</default_val><isAccountFrontendEnabled>(\d+)</isAccountFrontendEnabled><name><!\[CDATA\[(\S+)\]\]></name><password><!\[CDATA\[(\S+)\]\]></password><readwrite>\d+</readwrite></account>', line)
        if m:
            accountEnabled=m.group(1)
            username=m.group(2)
            password=m.group(3)
            print "STIG:EXOS_NET0440_account_last_resort  match for user [%s] pass [%s] [%s]" % (username, password, accountEnabled)
            if accountEnabled == "1":
                num_matches += 1
                usingDefaults.append(username)
                print "STIG:EXOS_NET0440_account_last_resort  accountEnabled ==1 for user [%s] pass [%s] [%s]" % (username, password, accountEnabled)
            else:
                print "STIG:EXOS_NET0440_account_last_resort  accountEnabled !=1 for user [%s] pass [%s] [%s]" % (username, password, accountEnabled)

    if num_matches == 1:
        print "STIG:EXOS_NET0440_account_last_resort PASS"
        return (PASSEDTEST, "The Device is password protected with a single account %s." % usingDefaults)
    else:
        print "STIG:EXOS_NET0440_account_last_resort FAIL"
        return (FAILEDTEST, "Error: A single last resort user account should be configured. Configured users are: %s" % usingDefaults )



def VDX_NET0440_Account_last_resort(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET0440_account_last_resort: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    for line in lines:
        m = re.search('^username.*role\s', line)
        if m:
            num_matches += 1
            print "STIG:VDX_NET0440_account_last_resort is present with admin privledges"
        else:
            pass
            #print "STIG:VDX_NET0440_account_last_resort no match on %s" % line
    if num_matches == 1:
        print "STIG:VDX_NET0440_account_last_resort PASS"
        return (PASSEDTEST, "A single last resort Admin account is present with admin privledges")
    else:
        print "STIG:VDX_NET0440_account_last_resort FAIL"
        if num_matches < 1:
            return (FAILEDTEST, "An Emergency Admin account is not present" )
        if num_matches > 1:
            return (FAILEDTEST, "Too many Emergency Admin accounts. Note that %d accounts are present" % num_matches )




def EXOS_NET0441_Emergency_account(audit_node, lines, dev_parsed, xml_log_data, cl):
    num_matches = 0
    usingDefaults = []

    for line in lines:
        m = re.search(r'<account><default_val>\d+</default_val><isAccountFrontendEnabled>(\d+)</isAccountFrontendEnabled><name><!\[CDATA\[(\S+)\]\]></name><password><!\[CDATA\[(\S+)\]\]></password><readwrite>(\d+)</readwrite></account>', line)
        if m:
            accountEnabled=m.group(1)
            username=m.group(2)
            password=m.group(3)
            privledge=m.group(4)
            print "STIG:EXOS_NET0441_emergency_account match for user [%s] pass [%s] [%s]" % (username, password, accountEnabled)
            if privledge == "1":
                num_matches += 1
                usingDefaults.append(username)
                print "STIG:EXOS_NET0441_emergency_account admin account ==1 for user [%s] pass [%s] [%s]" % (username, password, accountEnabled)
            else:
                print "STIG:EXOS_NET0441_emergency_account admin account !=1 for user [%s] pass [%s] [%s]" % (username, password, accountEnabled)

    if num_matches == 1:
        print "STIG:EXOS_NET0441_emergency_account PASS"
        return (PASSEDTEST, "The Device is password protected with a single 'admin' account %s." % usingDefaults)
    else:
        print "STIG:EXOS_NET0441_emergency_account FAIL"
        return (FAILEDTEST, "Error: A single last resort 'admin' account should be configured. Configured users are: %s" % usingDefaults )


def VDX_NET0441_Emergency_account(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET0441_emergency_account: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    for line in lines:
        m = re.search('^username.*role\s+admin', line)
        if m:
            num_matches += 1
            print "STIG:VDX_NET0441_emergency_account is present with admin privledges"
        else:
            pass
            #print "STIG:VDX_NET0441_emergency_account no match on %s" % line
    if num_matches > 0:
        print "STIG:VDX_NET0441_emergency_account PASS"
        return (PASSEDTEST, "An Emergency Admin account is present with admin privledges")
    else:
        print "STIG:VDX_NET0441_emergency_account FAIL"
        return (FAILEDTEST, "An Emergency Admin account is not present" )


def VDX_NET0600_Password_Viewable(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET0600_Password_Viewable: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    for line in lines:
        m = re.search('service\s+password-encryption', line)
        if m:
            num_matches += 1
            print "STIG:VDX_NET0600_Password_Viewable 'service password-encryption' is enabled"
        else:
            pass
            #print "STIG:VDX_NET0600_Password_Viewable no match on %s" % line
    if num_matches > 0:
        print "STIG:VDX_NET0600_Password_Viewable PASS"
        return (PASSEDTEST, "Passwords are not viewable, 'service password-encryption' is enabled")
    else:
        print "STIG:VDX_NET0600_Password_Viewable FAIL"
        return (FAILEDTEST, "Passwords are viewable, 'service password-encryption' is not enabled" )


def VDX_NET0740_HTTP_Server_Disabled(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET0740_HTTP_Server_Disabled: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    for line in lines:
        m = re.search('^\s+http\s+server\s+shutdown', line)
        if m:
            num_matches += 1
            print "STIG:VDX_NET0740_HTTP_Server_Disabled http server is disabled."
        else:
            pass
            #print "STIG:VDX_NET0740_HTTP_Server_Disabled no match on %s" % line

    if num_matches > 0:
        print "STIG:VDX_NET0740_HTTP_Server_Disabled PASS"
        return (PASSEDTEST, "The http server is disabled")
    else:
        print "STIG:VDX_NET0740_HTTP_Server_Disabled FAIL"
        return (FAILEDTEST, "The http server is not disabled")


def VDX_NET0901_SFLOW_Uses_Mgmt_Vrf(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET0901_SFLOW_Uses_Mgmt_Vrf: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    sflowIsUsed = False
    # find the management interface
    for line in lines:
        # Check to see if any sflow configuration exists
        m = re.search('sflow.+', line)
        if m:
            sflowIsUsed = True
        # check to see that sflow is setting the source interface
        m = re.search('sflow\s+source-ip\s+(\S+)', line)
        if m:
            print "STIG:VDX_NET0901_SFLOW_Uses_Mgmt_Vrf MATCH = [%s]" % line
            source = m.group(1)
            if source == "mm-ip" or source == "chassis-ip":
                num_matches += 1
                print "STIG:VDX_NET0901_SFLOW_Uses_Mgmt_Vrf using source = [%s]." % source

    if sflowIsUsed and num_matches < 1:
        print "STIG:VDX_NET0901_SFLOW_Uses_Mgmt_Vrf FAIL"
        return (FAILEDTEST, "SFLOW must use the Management VRF.")
    else:
        print "STIG:VDX_NET0901_SFLOW_Uses_Mgmt_Vrf PASS"
        return (PASSEDTEST, "SFLOW configuration conforms to the STIG.")


def VDX_NET0903_iBGP_Uses_Loopback(audit_node, lines, dev_parsed, xml_log_data, cl):
    num_matches = 0
    localBgpAs = ""
    iBgpUsingLoopback = []
    iBgpNeighbors = []
    for line in lines:
        m = re.search('\s+local-as\s+(\d+)', line)
        if m:
            localBgpAs=m.group(1)

    #  neighbor 1.101.1.2 remote-as 101
    #  neighbor 1.101.1.2 shutdown
    #  neighbor 3.3.3.3 remote-as 101
    #  neighbor 3.3.3.3 update-source loopback 1

    print "STIG:VDX_NET0903_iBGP_Uses_Loopback local BGP AS is %s" % localBgpAs

    # Get a list of each iBGP peer using a loopback interface
    #   neighbor 3.3.3.3 update-source loopback 1
    for line in lines:
        m = re.search('\s+neighbor\s+(\d+.\d+.\d+.\d+)\s+update-source\s+loopback\s+(\d+)', line)
        if m:
            #check to see if the neighbor is using a loopback as the source IP
            print "STIG:VDX_NET0903_iBGP_Uses_Loopback neighbor [%s], loopback [%s]" % (m.group(1), m.group(2))
            if m.group(1) not in iBgpUsingLoopback:
                print "STIG:VDX_NET0903_iBGP_Uses_Loopback iBgpNeighbor [%s] is not using a loopback" % (m.group(1))
                iBgpUsingLoopback.append(m.group(1))

    # Get a list of the iBGP neighbors
    # neighbor 3.3.3.3 remote-as 101
    for line in lines:
        m = re.search('\s+neighbor\s+(\d+.\d+.\d+.\d+)\s+remote-as\s+(\d+)', line)
        if m:
            #check to see if the neighbor BGP AS matches the local AS
            neighborAs = m.group(2)
            if localBgpAs == neighborAs:
                print "STIG:VDX_NET0903_iBGP_Uses_Loopback adding iBGP neighbor [%s]" % m.group(1)
                iBgpNeighbors.append(m.group(1))

    # compare the two lists and create a list of iBGP neighbors that are not using the loopback.
    if iBgpUsingLoopback == iBgpNeighbors:
        print "STIG:VDX_NET0903_iBGP_Uses_Loopback PASS"
        return (PASSEDTEST, "All iBGP Neighbors are using a loopback address.")
    else:
        print "STIG:VDX_NET0903_iBGP_Uses_Loopback FAIL"
        return (FAILEDTEST, "iBGP Neighbors not using a loopback address %s " % list(set(iBgpNeighbors) - set(iBgpUsingLoopback)))


def VDX_NET0965_Drop_Half_Open_Tcp(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET0965_Drop_Half_Open_Tcp: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    inMgmtInterface = 0
    num_matches = 0
    tcp_misses = []
    # find the management interface
    for line in lines:
        if inMgmtInterface == 0:
            m = re.search('interface\s+(Management\s+\S+)', line)
            if m:
                inMgmtInterface = 1
                mgmtInt = m.group(1)
                print "STIG:VDX_NET0965_Drop_Half_Open_Tcp Entered interface %s" % mgmtInt

        if inMgmtInterface == 1:
            m = re.search('^\s+tcp\s+(burstrate|lockup)\s+(\d+)', line)
            if m:
                if m.group(1) == "burstrate": #looking for tcp burstrate
                    print "STIG:VDX_NET0965_Drop_Half_Open_Tcp Contains [%s] value is  [%s]" % (m.group(1), m.group(2))
                    if int(m.group(2)) > 100:
                        # command is present, but the value is not acceptable
                        tcp_misses.append("TCP burstrate [%s] is too high." % m.group(2))
                    else:
                        # value is acceptable
                        num_matches += 1
 
                if m.group(1) == "lockup": #looking for tcp lockup
                    print "STIG:VDX_NET0965_Drop_Half_Open_Tcp Contains [%s] value is  [%s]" % (m.group(1), m.group(2))
                    if int(m.group(2)) < 300:
                        # command is present, but the value is not acceptable
                        tcp_misses.append("TCP lockup [%s] is too low." % m.group(2))
                    else:
                        # value is acceptable
                        num_matches += 1

        if inMgmtInterface == 1 and re.search('^!', line): # look for the end of the section
            inMgmtInterface = 0

    if num_matches >= 2:
        print "STIG:VDX_NET0965_Drop_Half_Open_Tcp PASS"
        return (PASSEDTEST, "All TCP burst statements present.")
    else:
        print "STIG:VDX_NET0965_Drop_Half_Open_Tcp FAIL"
        return (FAILEDTEST, "Unacceptable TCP burst configuraiton on management interface %s." % tcp_misses)


def VDX_NET0966_Control_Plane_Protection(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET0966_Control_Plane_Protection: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    inMgmtInterface = 0
    num_matches = 0
    controlPlane_misses = []
    # find the management interface
    for line in lines:
        if inMgmtInterface == 0:
            m = re.search('interface\s+(Management\s+\S+)', line)
            if m:
                inMgmtInterface = 1
                mgmtInt = m.group(1)
                print "STIG:VDX_NET0966_Control_Plane_Protection Entered interface %s" % mgmtInt

        if inMgmtInterface == 1:
            m = re.search('^\s+tcp\s+(burstrate|lockup)\s+(\d+)', line)
            if m:
                if m.group(1) == "burstrate": #looking for tcp burstrate
                    print "STIG:VDX_NET0966_Control_Plane_Protection Contains [%s] value is [%s]" % (m.group(1), m.group(2))
                    if int(m.group(2)) > 100:
                        # command is present, but the value is not acceptable
                        controlPlane_misses.append("TCP burstrate [%s] is too high." % m.group(2))
                    else:
                        # value is acceptable
                        num_matches += 1

                if m.group(1) == "lockup": #looking for tcp lockup
                    print "STIG:VDX_NET0966_Control_Plane_Protection Contains [%s] value is [%s]" % (m.group(1), m.group(2))
                    if int(m.group(2)) < 300:
                        # command is present, but the value is not acceptable
                        controlPlane_misses.append("TCP lockup [%s] is too low." % m.group(2))
                    else:
                        # value is acceptable
                        num_matches += 1

            m = re.search('^\s+(ip|ipv6)\s+(icmp|icmpv6)\s+rate-limiting\s+(\d+)', line)
            if m:
                if m.group(2) == "icmp":
                    print "STIG:VDX_NET0966_Control_Plane_Protection Contains [%s] rate-limit [%s]" % (m.group(2), m.group(3))
                    if int(m.group(3)) > 300:
                        # command is present, but the value is not acceptable
                        controlPlane_misses.append("FIXME: ICMP rate limit [%s] is too high." % m.group(3))
                    else:
                        # value is acceptable
                        num_matches += 1
                        
                if m.group(2) == "icmpv6":
                    print "STIG:VDX_NET0966_Control_Plane_Protection Contains [%s] rate-limit [%s]" % (m.group(2), m.group(3))
                    if int(m.group(3)) > 300:
                        # command is present, but the value is not acceptable
                        controlPlane_misses.append("FIXME: ICMPv6 rate limit [%s] is too high." % m.group(3))
                    else:
                        # value is acceptable
                        num_matches += 1
            else:
                print "STIG:VDX_NET0966_Control_Plane_Protection miss-on-line [%s]" % (line)

        if inMgmtInterface == 1 and re.search('^!', line): # look for the end of the section
            inMgmtInterface = 0

    if num_matches >= 4:
        print "STIG:VDX_NET0966_Control_Plane_Protection PASS"
        return (PASSEDTEST, "All burst statements present.")
    else:
        print "STIG:VDX_NET0966_Control_Plane_Protection FAIL"
        return (FAILEDTEST, "Unacceptable burst configuraiton on management interface %s." % controlPlane_misses)



def VDX_NET0991_IpAddr_On_Mgmt(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET0991_IpAddr_On_Mgmt: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    interfaceMode = False
    num_matches = 0
    # find the management interface
    for line in lines:
        if interfaceMode == False:
            m = re.search('^interface\s+Management', line)
        else:
           m = re.search('\s+ip\s+address\s+(\d+.\d+.\d+.\d+\/\d+)', line)

        if m and interfaceMode == False:
            print "STIG:VDX_NET0991_IpAddr_On_Mgmt Entered interface mode %s" % line
            interfaceMode = True

        if m and interfaceMode ==True:
            print "STIG:VDX_NET0991_IpAddr_On_Mgmt Found a match for an ipaddress/mask %s" % line
            num_matches += 1
            break # break the for loop

    if num_matches > 0:
        print "STIG:VDX_NET0991_IpAddr_On_Mgmt PASS"
        return (PASSEDTEST, "A management ip address is configured. Verify that the IP is valid for the range if the managment network.")
    else:
        print "STIG:VDX_NET0991_IpAddr_On_Mgmt FAIL"
        return (FAILEDTEST, "A management ip address is required on the management interface.")

def VDX_NET0992_device_mgmt_ACL_configured(audit_node, lines, dev_parsed, xml_log_data, cl):
    num_matches = 0
    inMgtInterface = False
    inMgtAcl = False
    mgmt_subnet = ""
    accessGroup = ""
    acl_subnet_not_in_mgmt_subnet = False
    mgmt_subnet_exists = False
    mgmt_ACL_exists = False
    offending_subnets = []
 
    for line in lines:
        # Verify the ACL restricts access to hosts in the management network
                
        if inMgtInterface == False:
            m = re.search('^interface\s+Management\s+\S+', line)
            if m:
                inMgtInterface = True
                print "STIG:VDX_NET0992_device_mgmt_ACL_configured Entered Interface mode [%s]" % line

        # Determine the IP_Subnet of the management network
        if inMgtInterface == True:
            m = re.search('\s+ip\s+address\s+(\d+.\d+.\d+.\d+/\d+)', line)
            if m:
                mgmt_subnet = m.group(1)
                mgmt_subnet_exists = True
                print "STIG:VDX_NET0992_device_mgmt_ACL_configured Management Subnet is [%s]" % (mgmt_subnet)
                
        # Determine the ACL Applied to the management network                    
        if inMgtInterface == True:
            m = re.search(r'\s+ip\s+access-group\s+(\S+|\S+_\S+)\s+\S+', line)
            if m:
                mgmt_ACL_exists = True
                accessGroup = m.group(1)
                print "STIG:VDX_NET0992_device_mgmt_ACL_configured accessGroup is [%s]" % (accessGroup)

        # Exit the Management Interface
        if inMgtInterface == True and re.search('^!', line): # look for the end of the Management Interface
            inMgtInterface = False
            print "STIG:VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net exiting the Mgmt interface."

    for line in lines:

        # Enter the STD ACL appied to the Management Interface, if we are not already in it.
        acl = re.search(r'ip\s+access-list\s+(standard|extended)\s+(\w+)', line)
        if acl:
            acl_type = acl.group(1)
            acl_name = acl.group(2)
            # Verify that this access-list is the one that's applied to the management interface
            print "STIG:VDX_NET0992_device_mgmt_ACL_configured [type=>%s name=>%s], mgmt accessGroup [%s]?" %(acl_type, acl_name, accessGroup)
            if acl_name == accessGroup:
                print "STIG:VDX_NET0992_device_mgmt_ACL_configured Parsing Mgmt [%s] ACL [%s]" % (acl_type, accessGroup)
                inMgtAcl = True


        # Check the permit statements and verify that the networks are restricted to the Management Subnet.
        # Note that this should work for both extended and standard ACLS.
        if inMgtAcl == True:
            # ACLs use 'any' as a shorthand for "0.0.0.0 255.255.255.255". To make parsing easy, replace any with dotted-decimal.
            line = line.replace("any", "0.0.0.0 255.255.255.255")
            print "STIG:VDX_NET0992_device_mgmt_ACL_configured Replaced 'any'. Result is [%s]" % (line)

        m = re.search('\s+seq\s+\d+\s+permit(\s+|\s+\S+\s+)(\d+.\d+.\d+.\d+)\s+(\d+.\d+.\d+.\d+)', line)
        if inMgtAcl == True and m:
            ip = m.group(2)
            inverseMask = m.group(3)
            acl_subnet = ip + "/" + str(inverseNetmask_to_cidr(inverseMask))
            print "STIG:VDX_NET0992_device_mgmt_ACL_configured Mgmt acl_subnet is [%s]" % (acl_subnet)

            # Evaluate the subnet. Is it in the same network as the management network?
            print "STIG:VDX_NET0992_device_mgmt_ACL_configured Testing mgmt_subnet [%s] =? acl_subnet [%s]" % (mgmt_subnet, acl_subnet)
            if addressInNetwork(ip, mgmt_subnet):
                print "STIG:VDX_NET0992_device_mgmt_ACL_configured Mgmt [%s] == ACL [%s]" % (mgmt_subnet, acl_subnet)
            else:
                print "STIG:VDX_NET0992_device_mgmt_ACL_configured Error: Mgmt [%s] != ACL [%s]" % (mgmt_subnet, acl_subnet)
                offending_subnets.append(acl_subnet)
                acl_subnet_not_in_mgmt_subnet = True
        
        # exit the Management ACL
        if inMgtAcl == True and re.search('^!', line): # look for the end of the ACL
            inMgtAcl = False

    if not acl_subnet_not_in_mgmt_subnet and mgmt_subnet_exists and mgmt_ACL_exists:
        print "STIG:VDX_NET0992_device_mgmt_ACL_configured PASS"
        return (PASSEDTEST, "All Permit ACLs are within the management network.")
    else:
        print "STIG:VDX_NET0992_device_mgmt_ACL_configured FAIL"
        return (FAILEDTEST, "ACL hosts not in management network: %s. A Mgmt_subnet_exists [%s]. A Mgmt_ACL_exists [%s]." % (offending_subnets, mgmt_subnet_exists, mgmt_ACL_exists))


def EXOS_NET0230_Device_Password_Protected(audit_node, lines, dev_parsed, xml_log_data, cl):
    num_matches = 0
    usingDefaults = []

    for line in lines:
        m = re.search(r'<account><default_val>\d+</default_val><isAccountFrontendEnabled>1</isAccountFrontendEnabled><name><!\[CDATA\[(\S+)\]\]></name><password><!\[CDATA\[(\S+)\]\]></password><readwrite>\d+</readwrite></account>', line)
        if m:
            username=m.group(1)
            password=m.group(2)
            # the empty password '' hashes to "$5$UnC2aF$dwUptJ.K67B.fKFD7B02omwYgeK3h.d0NpmjIhs3dQ4"
            print "STIG:EXOS_NET0230_Device_Password_Protected  match on user [%s] pass [%s]" % (username, password)
            if password == "$5$UnC2aF$dwUptJ.K67B.fKFD7B02omwYgeK3h.d0NpmjIhs3dQ4":
                num_matches += 1
                usingDefaults.append(username)
                print "STIG:EXOS_NET0230_Device_Password_Protected FAIL: A factory-default password is present %s -> %s " % (username, password)
            else:
                print "STIG:EXOS_NET0230_Device_Password_Protected A non-factory-default password is present"

    if num_matches == 0:
        print "STIG:EXOS_NET0230_Device_Password_Protected PASS"
        return (PASSEDTEST, "The Device is password protected.")
    else:
        print "STIG:EXOS_NET0230_Device_Password_Protected FAIL"
        return (FAILEDTEST, "Error: Default passwords present for these users %s" % usingDefaults )

def VDX_NET0230_Device_Password_Protected(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET0230_Device_Password_Protected: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    num_matches = 0
    usingDefaults = []

    for line in lines:
        m = re.search(r'^username\s+(\S+)\s+password\s+(\S+).+', line)
        if m:
	    username=m.group(1)
	    password=m.group(2)
            # the password 'password' hashes to "BwrsDbB+tABWGWpINOVKoQ==\n"
            print "STIG:VDX_NET0230_Device_Password_Protected  match on user [%s] pass [%s]" % (username, password)
	    if password == "\"BwrsDbB+tABWGWpINOVKoQ==\\n\"":
	        num_matches += 1
                usingDefaults.append(username)
                print "STIG:VDX_NET0230_Device_Password_Protected INFO: A factory-default password is present %s -> %s " % (username, password)
            else:
                pass
                #print "STIG:VDX_NET0230_Device_Password_Protected A non-factory-default password is present"

    if num_matches == 0:
        print "STIG:VDX_NET0230_Device_Password_Protected PASS"
        return (PASSEDTEST, "The Device is password protected.")
    else:
        print "STIG:VDX_NET0230_Device_Password_Protected FAIL"
        return (FAILEDTEST, "Error: Default passwords present for these users %s" % usingDefaults )


def EXOS_NET0240_No_Default_Password(audit_node, lines, dev_parsed, xml_log_data, cl):
    num_matches = 0
    usingDefaults = []

    for line in lines:
        m = re.search(r'<account><default_val>\d+</default_val><isAccountFrontendEnabled>1</isAccountFrontendEnabled><name><!\[CDATA\[(\S+)\]\]></name><password><!\[CDATA\[(\S+)\]\]></password><readwrite>\d+</readwrite></account>', line)
        if m:
            username=m.group(1)
            password=m.group(2)
            if password == "$5$UnC2aF$dwUptJ.K67B.fKFD7B02omwYgeK3h.d0NpmjIhs3dQ4":
                num_matches += 1
                usingDefaults.append(username)
                print "STIG:EXOS_NET0240_No_Default_Password FAIL: A factory-default password is present"
            else:
                print "STIG:EXOS_NET0240_No_Default_Password A non-factory-default password [%s -> %s] is present" % (username, password)
                #pass

    if num_matches < 1:
        print "STIG:EXOS_NET0240_No_Default_Password PASS"
        return (PASSEDTEST, "No default passwords are present")
    else:
        print "STIG:EXOS_NET0240_No_Default_Password FAIL"
        return (FAILEDTEST, "Error: Default passwords present for these users %s" % usingDefaults )



def VDX_NET0240_No_Default_Password(audit_node, lines, dev_parsed, xml_log_data, cl):
    parsed_details = None
    num_matches = 0
    usingDefaults = []
    
    # Find the VDX mgmt addr
    mgmtIp = getMgmtIp(lines)
    # Using the mgmt addr, look up the firmware version in the netsight DB
    firmwareVersion = getFirmware(mgmtIp)
    print "STIG:VDX_NET0240_No_Default_Password INFO: Firmware version is %s" % firmwareVersion

    # FIXME: If this version is greater than version TBD, the password value could be salted (VDX), so we won't know if it is a default.
    # if version > some version then don't test for defualt passwords because they are salted.
    # otherwise, continue.

    #username admin password "BwrsDbB+tABWGWpINOVKoQ==\n" encryption-level 7 role admin desc Administrator 
    for line in lines:
        m = re.search(r'^username\s+(\S+)\s+password\s+(\S+).+', line)
        if m:
	    username=m.group(1)
	    password=m.group(2)
	    if password == "\"BwrsDbB+tABWGWpINOVKoQ==\\n\"":
                num_matches += 1
                usingDefaults.append(username)
                print "STIG:VDX_NET0240_No_Default_Password A factory-default password is present"
            else:
                pass
                #print "STIG:VDX_NET0240_No_Default_Password A non-factory-default password [%s -> %s] is present" % (username, password)

    if num_matches < 1:
        print "STIG:VDX_NET0240_No_Default_Password PASS"
        return (PASSEDTEST, "No default passwords are present")
    else:
        print "STIG:VDX_NET0240_No_Default_Password FAIL"
        return (FAILEDTEST, "Error: Default passwords present for these users %s" % usingDefaults )


def VDX_NET0812_Multiple_NTP_Servers(audit_node, lines, dev_parsed, xml_log_data, cl):
    num_matches = 0
    for line in lines:
        m = re.search('ntp\s+server\s+\d+.\d+.\d+.\d+\s+use-vrf\s+\S+', line)
        if m:
            num_matches += 1
            print "STIG:VDX_NET0812_Multiple_NTP_Servers looping... num_matches is %d" % num_matches
        else:
            pass
            #print "STIG:VDX_NET0812_Multiple_NTP_Servers no match on %s" % line
    #print "STIG:VDX_NET0812_Multiple_NTP_Servers done looping... num_matches is %d" % num_matches
    if num_matches > 1:
        print "STIG:VDX_NET0812_Multiple_NTP_Servers PASS"
        return (PASSEDTEST, "All NTP servers are using approved authentication keys")
    else:
        print "STIG:VDX_NET0812_Multiple_NTP_Servers FAIL"
        return (FAILEDTEST, "Number of ntp servers is %d" % num_matches )


def VDX_NET0813_NTP_Authentication(audit_node, lines, dev_parsed, xml_log_data, cl):
    num_matches = 0
    authKeys = {}
    for line in lines:
        m = re.search('^ntp\s+authentication-(\S+\s+\d+)\s+(\S+)', line)
        if m:
            key=m.group(1)
	    auth_alg=m.group(2)
            # Need to load a dictionary of the keys and auth encryption types
            if key not in authKeys.keys():
                authKeys[key] =  auth_alg
                #print "STIG:VDX_NET0813_NTP_Authentication Added key %s:%s" % (key, auth_alg)
        else:
            pass
            #print "STIG:VDX_NET0813_NTP_Authentication no match on %s" % line
    print "STIG:VDX_NET0813_NTP_Authentication loaded keys %s" % authKeys.keys()

    failed = 0
    # Ensure that each ntp server key is using 'sha1'
    for line in lines:
        m = re.search('^ntp\s+server\s+(\S+)\s+use-vrf\s+\S+\s+(key\s+\d+)', line)
        if m:
            #check to see if the ntp server's key is not md5
            print "STIG:VDX_NET0813_NTP_Authentication testing key=[%s] : [%s]" % (m.group(2), authKeys.get(m.group(2)))
            if not authKeys.get(m.group(2)) == "sha1":
                print "STIG:VDX_NET0813_NTP_Authentication Warning key=[%s] is not sha1" % (m.group(2))
                failed = 1
    if failed:
        print "STIG:VDX_NET0813_NTP_Authentication FAIL"
        return (FAILEDTEST, "NTP Authentication Key for %s is not SHA1 %s. Note that MD5 authentication is only a CAT 3 finding." % (m.group(1), m.group(2)) )
    else:
        print "STIG:VDX_NET0813_NTP_Authentication PASS"
        return (PASSEDTEST, "NTP Authenticaiton Key is SHA1")

def VDX_NET0820_DNS_Resolver(audit_node, lines, dev_parsed, xml_log_data, cl):
    num_matches = 0
    for line in lines:
        m = re.search('ip\s+dns\s+name-server\s+\d+.\d+.\d+.\d+', line)
        if m:
            num_matches += 1
            print "STIG:VDX_NET0820_DNS_Resolver looping... num_matches is %d" % num_matches
    if num_matches > 0:
        print "STIG:VDX_NET0820_DNS_Resolver PASS"
        return (PASSEDTEST, "A DNS server is configured")
    else:
        print "STIG:VDX_NET0820_DNS_Resolver FAIL"
        return (FAILEDTEST, "A DNS server is not configured.")

def EXOS_NET0433_Multiple_Auth_Servers(audit_node, lines, dev_parsed, xml_log_data, cl):
    import xml.etree.ElementTree as ET
    num_matches = 0
    authServers = []
    
    # lines are a list, convert to a string to use the XML parsing
    root = ET.fromstring(''.join(lines))
    # count the radius and tacacs server entries
    for R in root.findall("*//etsRadiusAuthServerEntry"):
        address = R.find('address').text
        if address != "0.0.0.0":
            authServers.append("radius: " + address)
            print "STIG:EXOS_NET0433_Multiple_Auth_Servers: radiusServer #%d: %s" % (num_matches, address)
            num_matches = num_matches + 1

    for R in root.findall("*//tacacs"):
        address = R.find('host_ipaddr').text
        if address != "0.0.0.0":
            authServers.append("tacacs: " + address)
            print "STIG:EXOS_NET0433_Multiple_Auth_Servers: tacacsServer #%d: %s" % (num_matches, address)
            num_matches = num_matches + 1


    if num_matches > 1:
        print "STIG:EXOS_NET0433_Multiple_Auth_Servers PASS"
        return (num_matches, "Multiple Authentication Servers %s Pass" % authServers)
    else:
        print "STIG:EXOS_NET0433_Multiple_Auth_Servers FAIL"
        return (FAILEDTEST, "Number of auth servers is only %d must be at least 2" % num_matches )

def VDX_NET0433_Multiple_Auth_Servers(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET0433_Multiple_Auth_Servers: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    authServers = []
    for line in lines:
        m = re.search('^(tacacs|radius)-server\s+host\s+(\S+)', line)
        if m:
            # servers need to be seperate. need to ensure different IP address.
            if m.group(2) not in authServers:
                authServers.append(m.group(2))
                num_matches += 1
                #print "STIG:VDX_NET0433_Multiple_Auth_Servers looping... num_matches is %d" % num_matches
            else:
                print "STIG:VDX_NET0433_Multiple_Auth_Servers authServer duplicate ip. Require sperate servers"
        else:
            pass
            #print "STIG:VDX_NET0433_Multiple_Auth_Servers no match on %s" % line
    #print "STIG:VDX_NET0433_Multiple_Auth_Servers done looping... num_matches is %d" % num_matches
    if num_matches > 1:
        print "STIG:VDX_NET0433_Multiple_Auth_Servers PASS"
        return (num_matches, "Multiple Authentication Servers Pass")
    else:
        print "STIG:VDX_NET0433_Multiple_Auth_Servers FAIL"
        return (FAILEDTEST, "Number of auth servers is %d" % num_matches )


def VDX_NET0894_Snmp_Read_Only(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET0894_Snmp_Read_Only: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    for line in lines:
        # snmp-server group write_group v1 read xmc_view write xmc_view notify xmc_view
        m = re.search('^snmp-server\s+group\s+\S+\s+(\S+)\s+(\S+)\s+\S+\s+(\S+)\s+\S+\s+\S+\s+\S+', line)
        if m:
            snmpVersion=m.group(1)
            rw1=m.group(2)
            rw2=m.group(3)
            if rw1 == "write" or rw2 == "write":
                num_matches += 1
                print "STIG:VDX_NET0894_Snmp_Read_Only SNMP write feature is present."
        else:
            pass
            #print "STIG:VDX_NET0894_Snmp_Read_Only no match on %s" % line

    if num_matches == 0:
        print "STIG:VDX_NET0894_Snmp_Read_Only PASS"
        return (PASSEDTEST, "SNMP Read-Only Pass")
    else:
        print "STIG:VDX_NET0894_Snmp_Read_Only FAIL"
        return (FAILEDTEST, "Number of snmp write strings present is %d" % num_matches )


def VDX_NET0897_Auth_Uses_Mgmt_Vrf(audit_node, lines, dev_parsed, xml_log_data, cl):
    num_matches = 0
    num_interfaces = 0
    interfaceName = ""
    interfaceNumber = ""
    mgmtVrfsOn = []

    for line in lines:
        m = re.search('^(tacacs|radius)-server host \S+ use-vrf\s+(\S+)', line)
        if m:
            vrf=m.group(2)
            # we are looking to see that the vrf matches 'mgmt-vrf' if not then we fail the test.
            if not vrf == "mgmt-vrf":
                num_matches += 1
                print "STIG:VDX_NET0897_Auth_Uses_Mgmt_Vrf auth not using mgmt-vrf."

    # Ensure the mgmt-vrf is only applied to a single interface.
    inInterface = False
    for line in lines:
        # count interfaces
        m = re.search('interface\s+(\S+)\s+(\S+)', line)
        if m:
            print "STIG:VDX_NET0897_Auth_Uses_Mgmt_Vrf Setting In Interface."
            interfaceName = m.group(1)
            interfaceNumber = m.group(2)
            inInterface = True

        if inInterface:
            if interfaceName == "Management" and num_interfaces == 0:
                #print "STIG:VDX_NET0897_Auth_Uses_Mgmt_Vrf count only the first management interfaces i.e., logical chassis mode"
                num_interfaces += 1
            else:
                #print "STIG:VDX_NET0897_Auth_Uses_Mgmt_Vrf -Else- Interface is %s %s" % (interfaceName, interfaceNumber)
                # this is not a management interface, need to count it if in the mgmt-vrf
                m = re.search('\s+vrf\s+forwarding\s+mgmt-vrf', line)
                if m:
                    print "STIG:VDX_NET0897_Auth_Uses_Mgmt_Vrf interface has mgmt-vrf configured"
                    num_interfaces += 1
                    mgmtVrfsOn.append("%s%s" % (interfaceName, interfaceNumber))
   
        # look for the end of the interface section
        m = re.search('^!', line)
        if m:
            inInterface = False

    #print "STIG:VDX_NET0897_Auth_Uses_Mgmt_Vrf num_matches == %s num_interfaces == %s " % (num_matches, num_interfaces)
    if num_matches == 0 and num_interfaces == 2:
        print "STIG:VDX_NET0897_Auth_Uses_Mgmt_Vrf PASS "
        return (PASSEDTEST, "All auth servers are using the mgmt-vrf. Interfaces configured for mgmt-vrf are %s" % mgmtVrfsOn)
    else:
        print "STIG:VDX_NET0897_Auth_Uses_Mgmt_Vrf FAIL"
        return (FAILEDTEST, "Number of auth servers not using the mgmt-vrf=%d. Num_interfaces %d. Mgmt-vrf on interfaces %s" % (num_matches, num_interfaces, mgmtVrfsOn))


def VDX_NET0898_Syslog_Uses_Mgmt_Vrf(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET0898_Syslog_Uses_Mgmt_Vrf: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    num_mgmtVrfInterfaces = 0
    syslog_misses = []
    errorMsg = []

    # Mgmt-vrf should only be applied to 1 interface. Count how many interfaces are in the mgmt-vrf.
    for line in lines:
        m = re.search('\s+vrf\s+forwarding\s+mgmt-vrf', line)
        if m:
            num_mgmtVrfInterfaces += 1

    for line in lines:
        m = re.search('^logging\s+syslog-server\s+(\d+.\d+.\d+.\d+)+\s+use-vrf\s+(\S+)', line)
        if m:
            vrf=m.group(2)
            # we are looking to see that the vrf matches 'mgmt-vrf' if not then we fail the test.
            if not vrf == "mgmt-vrf":
                num_matches += 1
                syslog_misses.append(m.group(1))
                print "STIG:VDX_NET0898_Syslog_Uses_Mgmt_Vrf syslog is using [%s] not mgmt-vrf." % vrf
        else:
            pass
            #print "STIG:VDX_NET0898_Syslog_Uses_Mgmt_Vrf no match on %s" % line
    if num_mgmtVrfInterfaces > 1:
        errorMsg.append("Error: Too many interfaces in the mgmt-vrf.")

    # We Pass if the SYSLOG servers are using the mgmt-vrf and the mgmt-vrf is applied to a single interface
    if num_matches == 0 and num_mgmtVrfInterfaces == 1:
        print "STIG:VDX_NET0898_Syslog_Uses_Mgmt_Vrf PASS"
        return (PASSEDTEST, "All SYSLOG servers are using the mgmt-vrf")
    else:
        print "STIG:VDX_NET0898_Syslog_Uses_Mgmt_Vrf FAIL"
        return (FAILEDTEST, "SYSLOG servers not using the mgmt-vrf=%s. %s" % (syslog_misses, errorMsg))


def VDX_NET0899_NTP_Uses_Mgmt_Vrf(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET0899_NTP_Uses_Mgmt_Vrf: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    num_mgmtVrfInterfaces = 0
    errorMsg = []

    # Mgmt-vrf should only be applied to 1 interface. Count how many interfaces are in the mgmt-vrf.
    for line in lines:
        m = re.search('\s+vrf\s+forwarding\s+mgmt-vrf', line)
        if m:
            num_mgmtVrfInterfaces += 1

    for line in lines:
        m = re.search('^ntp server \S+ use-vrf\s+(\S+)', line)
        if m:
            vrf=m.group(1)
            # we are looking to see that the vrf matches 'mgmt-vrf' if not then we fail the test.
            if not vrf == "mgmt-vrf":
                num_matches += 1
                print "STIG:VDX_NET0899_NTP_Uses_Mgmt_Vrf ntp not using mgmt-vrf."
        else:
            pass
            #print "STIG:VDX_NET0899_NTP_Uses_Mgmt_Vrf no match on %s" % line

    if num_mgmtVrfInterfaces > 1:
        errorMsg.append("Error: Too many interfaces in the mgmt-vrf.")

    # We Pass if the NTP servers are using the mgmt-vrf and the mgmt-vrf is applied to a single interface
    if num_matches == 0 and num_mgmtVrfInterfaces == 1:
        print "STIG:VDX_NET0899_NTP_Uses_Mgmt_Vrf PASS"
        return (PASSEDTEST, "NTP servers are using the mgmt-vrf and the mgmt-vrf is applied to a single interface.")
    else:
        print "STIG:VDX_NET0899_NTP_Uses_Mgmt_Vrf FAIL"
        return (FAILEDTEST, "Number of NTP servers not using the mgmt-vrf=%d %s" % (num_matches, errorMsg))


def VDX_NET1020_Int_ACL_Deny_Not_Logged(audit_node, lines, dev_parsed, xml_log_data, cl):
    inAclSection = 0
    num_matches = 0
    num_misses = 0
    Acl_misses = []

    for line in lines:
        if inAclSection == 0:
            m = re.search('ip\ access-list\s+(\S+)\s+(\S+)', line)
            if m:
                inAclSection = 1
                Acl = m.group(2)
                print "STIG:VDX_NET1020_Int_ACL_Deny_Not_Logged Entered ACL mode %s" % line

        if inAclSection == 1:
            m = re.search('\s+seq\s+\d+\s+(deny|hard-drop).+(log$|.+)', line)           
            if m:
                if m.group(2) == "g": #looking for the "g" in "log"
                    print "STIG:VDX_NET1020_Int_ACL_Deny_Not_Logged ACL %s Contains log statement [%s]" % (Acl, line)
                    num_matches += 1
                else:
                    print "STIG:VDX_NET1020_Int_ACL_Deny_Not_Logged ACL %s Missing log statement [%s]" % (Acl, line)
                    Acl_misses.append(Acl)
                    num_misses += 1
            
        if inAclSection == 1 and re.search('^!', line): # look for the end of the ACL
            inAclSection = 0

    if num_misses == 0:
        print "STIG:VDX_NET1020_Int_ACL_Deny_Not_Logged PASS"
        return (PASSEDTEST, "All ACLs have log statements")
    else:
        print "STIG:VDX_NET1020_Int_ACL_Deny_Not_Logged FAIL"
        return (FAILEDTEST, "ACLs missing log statements on deny or hard-drop %s." % Acl_misses)

def VDX_NET1021_All_Messages_Logged(audit_node, lines, dev_parsed, xml_log_data, cl):
    # VDX MUDG indicates the following must be configured:
        #logging raslog console INFO
        #logging auditlog class SECURITY
        #logging auditlog class CONFIGURATION
        #logging auditlog class FIRMWARE
      
    num_matches = 0
    for line in lines:
        m = re.search('^logging\s+raslog\s+console\s+(INFO)', line)
        if m:
            print "STIG:VDX_NET1021_All_Messages_Logged raslog console configured."
            num_matches += 1

        m = re.search('^logging\s+auditlog\s+class\s+(CONFIGURATION|FIRMWARE|SECURITY)', line)
        if m:
            print "STIG:VDX_NET1021_All_Messages_Logged audit class %s configured." % m.group(1)
            num_matches += 1

    if num_matches == 4:
        print "STIG:VDX_NET1021_All_Messages_Logged PASS"
        return (PASSEDTEST, "All Messages are logged.")
    else:
        print "STIG:VDX_NET1021_All_Messages_Logged FAIL"
        return (FAILEDTEST, "All messages are not logged.")


def VDX_NET1624_Console_Timeout(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET1624_Console_Timeout: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    # NOTE: for the VDX this is the same test for VDX_NET1639
    inVty = 0
    num_matches = 0
    # find the management interface
    for line in lines:
        if inVty == 0:
            m = re.search('^line vty', line)
            if m:
                inVty = 1
                print "STIG:VDX_NET1624_Console_Timeout Entered line vty"
        # " exec-timeout 10"
        if inVty == 1:
            m = re.search('\s+exec-timeout\s+(\d+)', line)
            if m:
                timeout = int(m.group(1))
                if timeout != 0 and timeout < 11 : #Timeout must be 1 to 10 minutes
                    print "STIG:VDX_NET1624_Console_Timeout VTY timeout is [%d]" % timeout
                    num_matches += 1
                else:
                    print "STIG:VDX_NET1624_Console_Timeout is too long [%d]" % timeout

        if inVty == 1 and re.search('^!', line): # look for the end of the ACL
            inVty = 0

    if num_matches > 0:
        print "STIG:VDX_NET1624_Console_Timeout PASS"
        return (PASSEDTEST, "Timeout %d conforms to STIG." % timeout)
    else:
        print "STIG:VDX_NET1624_Console_Timeout FAIL"
        return (FAILEDTEST, "Timeout violates STIG. Line vty timeout is set to %d minutes. It must be set in the range of 1 to 10 minutes." % timeout)



def VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net(audit_node, lines, dev_parsed, xml_log_data, cl):
    # An ACL must be configured on the Management interface and restrict access to to hosts within that network.
    num_matches = 0
    inMgtInterface = 0
    inMgtAcl = 0
    mgmt_subnet = ""
    accessGroup = ""
    acl_subnet_not_in_mgmt_subnet = False
    mgmt_subnet_exists = False
    mgmt_ACL_exists = False
    offending_subnets = []
 
    for line in lines:
        
        # Verify the ACL restricts access to hosts in the management network
                
        if inMgtInterface == 0:
            m = re.search('^interface\s+Management\s+\S+', line)
            if m:
                inMgtInterface = 1
                print "STIG:VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net Entered Interface mode [%s]" % line

        # Determine the IP_Subnet of the management network
        if inMgtInterface == 1:
            m = re.search('\s+ip\s+address\s+(\d+.\d+.\d+.\d+/\d+)', line)
            if m:
                mgmt_subnet = m.group(1)
                mgmt_subnet_exists = True
                print "STIG:VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net Management Subnet is [%s]" % (mgmt_subnet)
                
        # Determine the ACL Applied to the management network                    
        if inMgtInterface == 1:
            m = re.search(r'\s+ip\s+access-group\s+(\S+|\S+_\S+)\s+\S+', line)
            if m:
                mgmt_ACL_exists = True
                accessGroup = m.group(1)
                print "STIG:VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net accessGroup is [%s]" % (accessGroup)

        # Exit the Management Interface
        if inMgtInterface == 1 and re.search('^!', line): # look for the end of the Management Interface
            inMgtInterface = 0
            print "STIG:VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net exiting the Mgmt interface."

    for line in lines:

        # Enter the STD ACL appied to the Management Interface, if we are not already in it.
        acl = re.search(r'ip\s+access-list\s+(standard|extended)\s+(\w+)', line)
        if acl:
            acl_type = acl.group(1)
            acl_name = acl.group(2)
            # Verify that this access-list is the one that's applied to the management interface
            print "STIG:VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net [type=>%s name=>%s], mgmt accessGroup [%s]?" %(acl_type, acl_name, accessGroup)
            if acl_name == accessGroup:
                print "STIG:VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net Parsing Mgmt [%s] ACL [%s]" % (acl_type, accessGroup)
                inMgtAcl = 1


        # Check the permit statements and verify that the networks are restricted to the Management Subnet.
        # Note that this should work for both extended and standard ACLS.
        if inMgtAcl == 1:
            # ACLs use 'any' as a shorthand for "0.0.0.0 255.255.255.255". To make parsing easy, replace any with dotted-decimal.
            line = line.replace("any", "0.0.0.0 255.255.255.255")
            print "STIG:VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net Replaced 'any'. Result is [%s]" % (line)

        m = re.search('\s+seq\s+\d+\s+permit(\s+|\s+\S+\s+)(\d+.\d+.\d+.\d+)\s+(\d+.\d+.\d+.\d+)', line)
        if inMgtAcl == 1 and m:
            ip = m.group(2)
            inverseMask = m.group(3)
            acl_subnet = ip + "/" + str(inverseNetmask_to_cidr(inverseMask))
            print "STIG:VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net Mgmt acl_subnet is [%s]" % (acl_subnet)

            # Evaluate the subnet. Is it in the same network as the management network?
            print "STIG:VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net Testing mgmt_subnet [%s] =? acl_subnet [%s]" % (mgmt_subnet, acl_subnet)
            if addressInNetwork(ip, mgmt_subnet):
                print "STIG:VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net Mgmt [%s] == ACL [%s]" % (mgmt_subnet, acl_subnet)
            else:
                print "STIG:VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net Error: Mgmt [%s] != ACL [%s]" % (mgmt_subnet, acl_subnet)
                offending_subnets.append(acl_subnet)
                acl_subnet_not_in_mgmt_subnet = True
        
        # exit the Management ACL
        if inMgtAcl == 1 and re.search('^!', line): # look for the end of the ACL
            inMgtAcl = 0

    if not acl_subnet_not_in_mgmt_subnet and mgmt_subnet_exists and mgmt_ACL_exists:
        print "STIG:VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net PASS"
        return (PASSEDTEST, "All Permit ACLs are within the management network.")
    else:
        print "STIG:VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net FAIL"
        return (FAILEDTEST, "ACL hosts not in management network: %s. A Mgmt_subnet_exists [%s]. A Mgmt_ACL_exists [%s]." % (offending_subnets, mgmt_subnet_exists, mgmt_ACL_exists))

def VDX_NET1638_Mgt_FIPS140_Only(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET1638_Mgt_FIPS140_Only: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)

    num_matches = 0
    telnetShutdown = False
    httpShutdown = False
    snmpComPub = False
    
    # find the management interface
    for line in lines:
        m = re.search('(telnet\s+server\s+shutdown|http\s+server\s+shutdown|no\s+snmp-server\s+community\s+public)', line)
        if m:
            print "STIG:VDX_NET1638_Mgt_FIPS140_Only detected %s" % m.group(1)
            num_matches += 1
            if m.group(1) == "telnet server shutdown":
                telnetShutdown = True
            if m.group(1) == "telnet server shutdown":
                httpShutdown = True
            if m.group(1) == "telnet server shutdown":
                snmpComPub = True
        
        
    if num_matches > 2:
        print "STIG:VDX_NET1638_Mgt_FIPS140_Only PASS"
        return (PASSEDTEST, "Conforms to STIG.")
    else:
        print "STIG:VDX_NET1638_Mgt_FIPS140_Only FAIL"
        return (FAILEDTEST, "Violates STIG. Telnet is disabled %s. Http is disabled %s. 'SNMP community public' disabled %s" % (telnetShutdown, httpShutdown, snmpComPub))


def VDX_NET1645_Ssh_Session_Timeout(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET1645_Ssh_Session_Timeout: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    errorString=[]
    for line in lines:
        m = re.search('\s+ssh\s+server\s+(max-idle-timeout|max-login-timeout)\s+(\d+)', line)
        if m:
            timeout=m.group(1)
            value=m.group(2)
            if timeout == "max-idle-timeout":
                if int(value) <= 10:
                    num_matches += 1
                else:
                    errorString.append("max-idle-timeout [%s] is too high." % value)
                print "STIG:VDX_NET1645_Ssh_Session_Timeout auth not using mgmt-vrf."
            if timeout == "max-login-timeout":
                if int(value) <= 60:
                    num_matches += 1
                else:
                    errorString.append("max-idle-timeout [%s] is too high." % value)
                print "STIG:VDX_NET1645_Ssh_Session_Timeout auth not using mgmt-vrf."                
        else:
            pass
            #print "STIG:VDX_NET1645_Ssh_Session_Timeout no match on %s" % line

    if num_matches >= 2 :
        print "STIG:VDX_NET1645_Ssh_Session_Timeout PASS"
        return (PASSEDTEST, "SSH timeout parameters are sufficient.")
    else:
        if errorString == []:
            errorString = "Configure the 'ssh max-idle-timeout 10' and 'ssh max-login-timeout 60'"
        print "STIG:VDX_NET1645_Ssh_Session_Timeout FAIL"
        return (FAILEDTEST, "SSH timeouts are not conforming to the STIG. %s." % errorString )

def VDX_NET1646_Ssh_Max_Unsuccessful_Logins(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET1646_Ssh_Max_Unsuccessful_Logins: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    errorString=[]
    for line in lines:
        m = re.search('\s+ssh\s+server\s+(max-auth-tries)\s+(\d+)', line)
        if m:
            authTries=m.group(1)
            value=m.group(2)
            if authTries == "max-auth-tries":
                if int(value) <= 3:
                    num_matches += 1
                else:
                    errorString.append("max-idle-authTries [%s] is too high." % value)
                print "STIG:VDX_NET1646_Ssh_Max_Unsuccessful_Logins auth not using mgmt-vrf."
               
        else:
            pass
            #print "STIG:VDX_NET1646_Ssh_Max_Unsuccessful_Logins no match on %s" % line

    if num_matches != 0 :
        print "STIG:VDX_NET1646_Ssh_Max_Unsuccessful_Logins PASS"
        return (PASSEDTEST, "SSH max-auth-tries parameter is sufficient.")
    else:
        if errorString == []:
            errorString = "Configure 'ssh max-auth-tries 3'"
        print "STIG:VDX_NET1646_Ssh_Max_Unsuccessful_Logins FAIL"
        return (FAILEDTEST, "SSH authTriess are not conforming to the STIG. %s." % errorString )


def VDX_NET1660_SNMPv3_SHA_AES(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET1660_SNMPv3_SHA_AES: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    snmpv3Users=[]
    snmpv3CryptoUsers=[]
    
    # get a list of all snmpv3Users
    for line in lines:
        m = re.search('^snmp-server\s+user\s+(\S+)\s+\S+\s+\S+\s+auth\s+(\S+)\s+auth-password\s+\S+\s+priv\s+(\S+)', line)
        if m:
            #print "STIG:VDX_NET1660_SNMPv3_SHA_AES SNMPv3 matched on %s %s %s" % (m.group(1), m.group(2), m.group(3) )
            if m.group(2) == "sha" and m.group(3) == "AES128": # SNMPv3 user authenticated with AES and SHA crypto.
                snmpv3CryptoUsers.append(m.group(1) + ":" + m.group(2) + ":" + m.group(3))
            else: # SNMPv3 user not authenticated with AES and SHA
                snmpv3Users.append(m.group(1) + ":" + m.group(2) + ":" + m.group(3))

    if len(snmpv3Users) == 0 and len(snmpv3CryptoUsers) > 0: # There are 0 users using weak encryption, and at least 1 using correct 
        print "STIG:VDX_NET1660_SNMPv3_SHA_AES PASS"
        return (PASSEDTEST, "All SNMPv3 users %s are using correct crypto." % snmpv3CryptoUsers)
    else:
        print "STIG:VDX_NET1660_SNMPv3_SHA_AES FAIL"
        return (FAILEDTEST, "SNMPv3 users are not conforming to the STIG. Check SNMPv3 users %s." % (snmpv3Users))



def VDX_NET1665_SNMP_Valid_Community_Strings(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET1665_SNMP_Valid_Community_Strings: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    snmpUsers = []
    snmpWellKnownPasswords = []
    snmpUnKnownPasswords = []
    private = r'MQXihPExAN4LHrqCw/mZCg==\n'
    public = r'sgILwNPyHhTcp98+3v56zA==\n'
    wellKnownPasswords = [public, private]
    
    # get a list of all snmpWellKnownPasswords
    for line in lines:
        # snmp-server user BadPrivateUser groupname snmpadmin auth md5 auth-password "MQXihPExAN4LHrqCw/mZCg==\n" priv AES128 priv-password "MQXihPExAN4LHrqCw/mZCg==\n" encrypted
        m = re.search('^snmp-server\s+user\s+(\S+)\s+groupname\s+\S+\s+auth\s+\S+\s+\S+\s+\"(\S+)\"\spriv\s+\S+\s+\S+\s\"(\S+)\"', line)
        if m:
            user = m.group(1)
            authPass = m.group(2)
            privPass = m.group(3)
            if authPass in wellKnownPasswords or privPass in wellKnownPasswords:
                # the password is well known
                snmpWellKnownPasswords.append(user + ":" + authPass + ":" + privPass)
                snmpUsers.append(user)
                print "STIG:VDX_NET1665_SNMP_Valid_Community_Strings ___Well Known user=%s authPass=%s privPass=%s known=%s" % (user, authPass, privPass, wellKnownPasswords)
            else:
                print "STIG:VDX_NET1665_SNMP_Valid_Community_Strings _X_Not Well Known user=%s authPass=%s privPass=%s known=%s" % (user, authPass, privPass, wellKnownPasswords)
                snmpUnKnownPasswords.append(user + ":" + authPass + ":" + privPass)


    if len(snmpWellKnownPasswords) == 0 :
        print "STIG:VDX_NET1665_SNMP_Valid_Community_Strings PASS"
        return (PASSEDTEST, "All SNMPv3 users %s are using passwords that are not well known." % snmpUnKnownPasswords)
    else:
        print "STIG:VDX_NET1665_SNMP_Valid_Community_Strings FAIL"
        return (FAILEDTEST, "SNMPv3 users are not conforming to the STIG. SNMPv3 users %s, using known password." % snmpWellKnownPasswords)



def VDX_NET1675_SNMP_Diff_Names_Diff_Levels(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET1675_SNMP_Diff_Names_Diff_Levels: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    snmpLinesWithDupPasswords=[]
    private = "MQXihPExAN4LHrqCw/mZCg==\n"
    public = "sgILwNPyHhTcp98+3v56zA==\n"
    wellKnownPasswords=[public, private, "public", "private"]
    
    # TODO: Implement checks for SNMP v1

    # SNMP v2C and v3    
    # get a list of all snmpLinesWithDupPasswords
    for line in lines:
        # snmp-server user BadPrivateUser groupname snmpadmin auth md5 auth-password "MQXihPExAN4LHrqCw/mZCg==\n" priv AES128 priv-password "MQXihPExAN4LHrqCw/mZCg==\n" encrypted
        m = re.search('^snmp-server\s+user\s+(\S+)\s+groupname\s+\S+\s+auth\s+\S+\s+auth-password\s+(\S+)\spriv\s+\S+\s+priv-password\s(\S+)', line)
        if m:
            user = m.group(1)
            authPass = m.group(2)
            privPass = m.group(3)
            # evaluate the SNMPv3 auth and priv passwords to ensure they are unique.
            if authPass in wellKnownPasswords or privPass in wellKnownPasswords:
                # the password is well known
                snmpLinesWithDupPasswords.append(line)
            # Add the snmp priv and auth passwords to the list of well-known / unique passwords
            wellKnownPasswords.append(privPass)
            wellKnownPasswords.append(authPass)

    if len(snmpLinesWithDupPasswords) == 0 :
        print "STIG:VDX_NET1675_SNMP_Diff_Names_Diff_Levels PASS"
        return (PASSEDTEST, "All SNMPv3 users are using passwords that are unique.")
    else:
        print "STIG:VDX_NET1675_SNMP_Diff_Names_Diff_Levels FAIL"
        return (FAILEDTEST, "SNMPv3 users are not conforming to the STIG. Duplicates %s." % snmpLinesWithDupPasswords)


def VDX_NET_VLAN_004_Vlan_1_Not_Used(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET_VLAN_004_Vlan_1_Not_Used: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    parsed_details = None
    num_matches = 0
    inInterface = False
    interfaces = []
    # Find any instances of VLAN 1 as an access-port
    for line in lines:
        if inInterface == False:
            m = re.search('^interface\s+(\S+\s+\S+)', line)
            if m:
                inInterface = True
                interfaceName = m.group(1)
                print "STIG:VDX_NET_VLAN_004_Native_VlanTrunk_Not_Default Entered interface %s" % interfaceName

        if inInterface == True:
            # interface is access mode?    
            m = re.search('switchport\s+access\s+vlan\s+(\d+)', line)
        if m:
            vlan = int(m.group(1))
            if vlan == 1:
                # VLAN 1 is used
                num_matches += 1
                interfaces.append(interfaceName)
 
        if inInterface == True and re.search('^!', line): # look for the end of the section
            inInterface = False

               
    if num_matches == 0 :
        print "STIG:VDX_NET_VLAN_004_Vlan_1_Not_Used PASS"
        return (PASSEDTEST, "VLAN 1 is not used.")
    else:
        print "STIG:VDX_NET_VLAN_004_Vlan_1_Not_Used FAIL"
        return (FAILEDTEST, "VLAN 1 is used %s times on an access interface. Check interface: %s." % (num_matches, interfaces))


def VDX_NET_VLAN_008_Native_VlanTrunk_Not_Default(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET_VLAN_008_Native_VlanTrunk_Not_Default: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    inInterface = False
    trunkInterface = False
    num_matches = 0
    nativeVlanMatches = []
    # find the management interface
    for line in lines:
        if inInterface == False:
            m = re.search('^interface\s+(\S+\s+\S+)', line)
            if m:
                inInterface = True
                interfaceName = m.group(1)
                #print "STIG:VDX_NET_VLAN_008_Native_VlanTrunk_Not_Default Entered interface %s" % interfaceName

        if inInterface == True:
        # interface is a trunk?    
            m = re.search('switchport\s+mode\s+trunk', line)
            if m:
                trunkInterface = True

        if trunkInterface == True:
            # switchport trunk adds the native-vlan statement, which fails compliance.
            m = re.search('^\s+switchport\s+trunk\s+tag\s+native-vlan', line)
            if m:
                num_matches += 1
                nativeVlanMatches.append(interfaceName)

        if inInterface == True and re.search('^!', line): # look for the end of the section
            inInterface = False
            trunkInterface = False

    if num_matches == 0 :
        print "STIG:VDX_NET_VLAN_008_Native_VlanTrunk_Not_Default PASS"
        return (PASSEDTEST, "VLAN 1 is not used.")
    else:
        print "STIG:VDX_NET_VLAN_008_Native_VlanTrunk_Not_Default FAIL"
        return (FAILEDTEST, "VLAN 1 is used %s times on trunk a interface. Check interfaces: %s." % (num_matches, nativeVlanMatches))


def VDX_NET_VLAN_009_Native_Vlan_On_Access_Port(audit_node, lines, dev_parsed, xml_log_data, cl):
    #print "STIG:VDX_NET_VLAN_009_Native_Vlan_On_Access_Port: audit_node:%s dev_parsed:%s xml_log:%s cl:%s " % (audit_node, dev_parsed, xml_log_data, cl)
    inInterface = False
    inPortProfile = False
    modeAccess = False
    defaultVlan = 0
    num_matches = 0
    
    nativeVlanMatches = []
    # Get the default vlan from the default port-profile.
    for line in lines:
    
        if inPortProfile == False:
            m = re.search('^port-profile default', line)
            if m:
                inPortProfile = True
                print "STIG:VDX_NET_VLAN_009_Native_Vlan_On_Access_Port Entered default port-profile"

        if inPortProfile == True:
            m = re.search('switchport\s+trunk\s+native-vlan\s(\d+)', line)
            if m:
                defaultVlan = m.group(1)
                print "STIG:VDX_NET_VLAN_009_Native_Vlan_On_Access_Port default VLAN is %s" % defaultVlan
    
        if inPortProfile == True and re.search('^!', line): # look for the end of the section
            inPortProfile = False

    
    # Evaluate each interface configured as switchport access
    for line in lines:
        if inInterface == False:
            m = re.search('^interface\s+(\S+\s+\S+)', line)
            if m:
                inInterface = True
                interfaceName = m.group(1)
                #print "STIG:VDX_NET_VLAN_009_Native_Vlan_On_Access_Port Entered interface %s" % interfaceName

        if inInterface == True:
        # interface is switchport mode access?    
            m = re.search('switchport\s+mode\s+access', line)
            if m:
                modeAccess = True
                print "STIG:VDX_NET_VLAN_009_Native_Vlan_On_Access_Port Interface switchport Access %s" % interfaceName
                # switchport trunk adds the native-vlan statement, which fails compliance.
            # if the interface is set to switchport mode access then look for the access vlan id
            if modeAccess == True:
                m = re.search('switchport\s+access\s+vlan\s(\d+)', line)
                if m:
                    print "STIG:VDX_NET_VLAN_009_Native_Vlan_On_Access_Port Access VLAN is %s" % m.group(1)
                    if m.group(1) == defaultVlan:
                        num_matches += 1
                        nativeVlanMatches.append(interfaceName)

        if inInterface == True and re.search('^!', line): # look for the end of the section
            inInterface = False
            modeAccess = False

    if num_matches == 0 :
        print "STIG:VDX_NET_VLAN_009_Native_Vlan_On_Access_Port PASS"
        return (PASSEDTEST, "VLAN 1 is not used.")
    else:
        print "STIG:VDX_NET_VLAN_009_Native_Vlan_On_Access_Port FAIL"
        return (FAILEDTEST, "Default Native VLAN %s is used %s times. On these interfaces %s." % (defaultVlan, num_matches, nativeVlanMatches))


def EXOS_NET0400_IGP_Peer_Auth(audit_node, lines, dev_parsed, xml_log_data, cl):
    import xml.etree.ElementTree as ET
    root = ET.fromstring(''.join(lines))
    PeersNoAuth = []
    OspfInterfaces = 0
    BgpPeers = 0
    OspfPeersNoAuth = 0

    # Evaluate each ospf interface.
    for R in root.findall(".//ospfInterface"):
        # ospfIfAuthKey
        if R.find('ospfIfAuthKey').text == None :
             OspfPeersNoAuth += 1
             print "STIG:EXOS_NET0400_IGP_Peer_Auth: False, missing ospfIfAuthKey"
             print "STIG:EXOS_NET0400_IGP_Peer_Auth: ospfIfAuthKey on interface: [%s] " % R.find('ospfIfName').text 
             PeersNoAuth.append("OSPF: " + R.find('ospfIfName').text) 
        else:
             print "STIG:EXOS_NET0400_IGP_Peer_Auth: True, there is an ospfIfAuthKey"
             print "STIG:EXOS_NET0400_IGP_Peer_Auth: ospfIfAuthKey: [%s] " % R.find('ospfIfAuthKey').text 
        OspfInterfaces += 1
 
    # Evaluate each BGP peer.
    for R in root.findall(".//bgpPeerReadWrite"):
        if  R.find('bgpCfgPeerPasswordEncrypted') == None:
            BgpPeers += 1
            address = R.find('bgpCfgPeerRemoteAddr').text
            intName= R.find('bgpVrId').text
            debug = "Address: " + address + " intName: " + intName
            PeersNoAuth.append("BGP: " + debug) 
            print "STIG:EXOS_NET0400_IGP_Peer_Auth: No Auth for BGP: %s" % debug
 
    # FIXME: next if is probably wrong.
    if OspfPeersNoAuth + BgpPeers == 0 :
        print "STIG:EXOS_NET0400_IGP_Peer_Auth PASS"
        return (PASSEDTEST, "All configured peers are authenticated.")
    else:
        print "STIG:EXOS_NET0400_IGP_Peer_Auth FAIL"
        return (FAILEDTEST, "Missing authentication on these interfaces %s." % PeersNoAuth)



def VDX_NET0400_IGP_Peer_Auth(audit_node, lines, dev_parsed, xml_log_data, cl):
    inInterface = False
    OspfOnInterface = False    
    waitTimeFound= False    
    keyFound = False    
    OspfPeersNoAuth = []
    
    # Evaluate each interface.
    for line in lines:
        if inInterface == False:
            m = re.search('^interface\s+(\S+\s+\S+)', line)
            if m:
                inInterface = True
                interfaceName = m.group(1)
                #print "STIG:VDX_NET0400_IGP_Peer_Auth Entered interface %s" % interfaceName

        if inInterface == True:
        # interface is configured with OSPF?    
            m = re.search('^\s+ip ospf\s+\S+\s+\d+', line)
            if m:
                # OSPF is configured on this interface.
                OspfOnInterface = True
                
        if OspfOnInterface == True:
            # Check to see if md5 authentication key-activation-wait-time is applied
            waitTime = re.search('^\s+ip ospf\s+md5-authentication\s+key-activation-wait-time\s+\d+', line)
            if waitTime:
                waitTimeFound = True
            key = re.search('^\s+ip ospf\s+md5-authentication\s+key-id\s+\d+\s+\key\s+\d+\s+\S+', line)
            if key:
                keyFound = True

        if inInterface == True and re.search('^!', line): # look for the end of the section
            if OspfOnInterface == True:
                if waitTimeFound and keyFound:
                    print "STIG:VDX_NET0400_IGP_Peer_Auth ospf md5 authentication applied to interface %s" % interfaceName
                else: 
                    OspfPeersNoAuth.append(interfaceName)
                waitTimeFound = False
                keyFound = False    
                OspfOnInterface = False
            inInterface = False

    #FIXME: Implment a BGP Peer check

    if len(OspfPeersNoAuth) == 0 :
        print "STIG:VDX_NET0400_IGP_Peer_Auth PASS"
        return (PASSEDTEST, "All IGP Peers are authenticated.")
    else:
        print "STIG:VDX_NET0400_IGP_Peer_Auth FAIL"
        return (FAILEDTEST, "Missing OSPF MD5 authentication on these interfaces %s." % OspfPeersNoAuth)

def TEST(audit_node, lines, dev_parsed, xml_log_data, cl):
    import xml.etree.ElementTree as ET
    root = ET.fromstring(''.join(lines))

    print "STIG:TEST _____________________________________"
    print "xml root.tag %s " % root.tag

    for child in root:
        print("---")
        if child.tag == "xos-module-ospf":
            print(child.tag, child.attrib)
    print("xxxx")
    #result = root.findall("xos-configuration/xos-module-ospf/ospfArea")
    #for c in root.findall("xos-configuration/xos-module-cfgmgr/cliSession/afterLoginBanner") :
    result = root.iter("loginBanner")
    if result:
        print ("result -> %s" % result)
        for c in result :
            print("atrib: %s -> test: %s" % (c.attrib, c.text))

    print "STIG:TEST _____________________________________"
    return (PASSEDTEST, "TEST Passed.")


stig_function_map = {
    'VDX_NET0897_Auth_Uses_Mgmt_Vrf':VDX_NET0897_Auth_Uses_Mgmt_Vrf,
    'EXOS_NET0340_Login_Banner':EXOS_NET0340_Login_Banner,
    'VDX_NET0340_Login_Banner':VDX_NET0340_Login_Banner,
    'EXOS_NET0230_Device_Password_Protected':EXOS_NET0230_Device_Password_Protected,
    'VDX_NET0230_Device_Password_Protected':VDX_NET0230_Device_Password_Protected,
    'EXOS_NET0240_No_Default_Password':EXOS_NET0240_No_Default_Password,
    'VDX_NET0240_No_Default_Password':VDX_NET0240_No_Default_Password,
    'VDX_NET0408_All_BGP_Peers_Authenticated':VDX_NET0408_All_BGP_Peers_Authenticated,
    'EXOS_NET0440_Account_last_resort':EXOS_NET0440_Account_last_resort,
    'VDX_NET0440_Account_last_resort':VDX_NET0440_Account_last_resort,
    'EXOS_NET0441_Emergency_account':EXOS_NET0441_Emergency_account,
    'VDX_NET0441_Emergency_account':VDX_NET0441_Emergency_account,
    'VDX_NET0600_Password_Viewable':VDX_NET0600_Password_Viewable,
    'VDX_NET0740_HTTP_Server_Disabled':VDX_NET0740_HTTP_Server_Disabled,
    'VDX_NET0901_SFLOW_Uses_Mgmt_Vrf':VDX_NET0901_SFLOW_Uses_Mgmt_Vrf,
    'VDX_NET0903_iBGP_Uses_Loopback':VDX_NET0903_iBGP_Uses_Loopback,
    'VDX_NET0965_Drop_Half_Open_Tcp':VDX_NET0965_Drop_Half_Open_Tcp,
    'VDX_NET0966_Control_Plane_Protection':VDX_NET0966_Control_Plane_Protection,
    'VDX_NET0991_IpAddr_On_Mgmt':VDX_NET0991_IpAddr_On_Mgmt,
    'VDX_NET0992_device_mgmt_ACL_configured':VDX_NET0992_device_mgmt_ACL_configured,
    'VDX_NET0812_Multiple_NTP_Servers':VDX_NET0812_Multiple_NTP_Servers,
    'VDX_NET0813_NTP_Authentication':VDX_NET0813_NTP_Authentication,
    'VDX_NET0820_DNS_Resolver':VDX_NET0820_DNS_Resolver,
    'VDX_NET0899_NTP_Uses_Mgmt_Vrf':VDX_NET0899_NTP_Uses_Mgmt_Vrf,
    'EXOS_NET0433_Multiple_Auth_Servers':EXOS_NET0433_Multiple_Auth_Servers,
    'VDX_NET0433_Multiple_Auth_Servers':VDX_NET0433_Multiple_Auth_Servers,
    'VDX_NET0894_Snmp_Read_Only':VDX_NET0894_Snmp_Read_Only,
    'VDX_NET0898_Syslog_Uses_Mgmt_Vrf':VDX_NET0898_Syslog_Uses_Mgmt_Vrf,
    'VDX_NET1020_Int_ACL_Deny_Not_Logged':VDX_NET1020_Int_ACL_Deny_Not_Logged,
    'VDX_NET1021_All_Messages_Logged':VDX_NET1021_All_Messages_Logged,
    'VDX_NET1624_Console_Timeout':VDX_NET1624_Console_Timeout,
    'VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net':VDX_NET1637_Mgt_Only_From_Hosts_In_Mgt_Net,
    'VDX_NET1638_Mgt_FIPS140_Only':VDX_NET1638_Mgt_FIPS140_Only,
    'VDX_NET1645_Ssh_Session_Timeout':VDX_NET1645_Ssh_Session_Timeout,
    'VDX_NET1646_Ssh_Max_Unsuccessful_Logins':VDX_NET1646_Ssh_Max_Unsuccessful_Logins,
    'VDX_NET1660_SNMPv3_SHA_AES':VDX_NET1660_SNMPv3_SHA_AES,
    'VDX_NET1665_SNMP_Valid_Community_Strings':VDX_NET1665_SNMP_Valid_Community_Strings,
    'VDX_NET1675_SNMP_Diff_Names_Diff_Levels':VDX_NET1675_SNMP_Diff_Names_Diff_Levels,
    'VDX_NET_VLAN_004_Vlan_1_Not_Used':VDX_NET_VLAN_004_Vlan_1_Not_Used,
    'VDX_NET_VLAN_008_Native_VlanTrunk_Not_Default':VDX_NET_VLAN_008_Native_VlanTrunk_Not_Default,
    'VDX_NET_VLAN_009_Native_Vlan_On_Access_Port':VDX_NET_VLAN_009_Native_Vlan_On_Access_Port,
    'EXOS_NET0400_IGP_Peer_Auth':EXOS_NET0400_IGP_Peer_Auth,
    'VDX_NET0400_IGP_Peer_Auth':VDX_NET0400_IGP_Peer_Auth,
}
