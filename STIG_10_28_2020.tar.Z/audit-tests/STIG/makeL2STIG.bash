cp -r NET0230_Device_Password_Protected ../L2STIG/
cp -r NET0240_No_Default_Password ../L2STIG/
cp -r NET0340_Login_Banner ../L2STIG/
# not in L2 STIG
# not implemented
# not in L2 STIG
# not in L2 STIG
cp -r NET0433_MultipleAuthServers ../L2STIG/
# not implemented
cp -r NET0441_emergency_account ../L2STIG/
# not implemented
# not implemented
# not implemented
cp -r NET0600_Password_Viewable ../L2STIG/
# not implemented
# not implemented
cp -r NET0740_HTTP_Server_Disabled ../L2STIG/
# not in L2 STIG
# not implemented
# not in L2 STIG
cp -r NET0812_Multiple_NTP_Servers ../L2STIG/
cp -r NET0813_NTP_Authentication ../L2STIG/
# not implemented
# not implemented
cp -r NET0894_Snmp_Read_Only ../L2STIG/
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not implemented
# not implemented
# not in L2 STIG
# not in L2 STIG
# not implemented
# not in L2 STIG
# not implemented
# not implemented
# not implemented
# not implemented
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
cp -r NET1021_All_Messages_Logged ../L2STIG/
# not implemented
# not implemented
cp -r NET1624_Console_Timeout ../L2STIG/
# not implemented
# not implemented
cp -r NET1637_Mgt_Only_From_Hosts_In_Mgt_Net ../L2STIG/
cp -r NET1638_Mgt_FIPS140_Only ../L2STIG/
# not implemented
# not implemented
cp -r NET1645_Ssh_Session_Timeout ../L2STIG/
cp -r NET1646_Ssh_Max_Unsuccessful_Logins ../L2STIG/
# not implemented
cp -r NET1660_SNMPv3_SHA_AES ../L2STIG/
cp -r NET1665_SNMP_Valid_Community_Strings ../L2STIG/
cp -r NET1675_SNMP_Diff_Names_Diff_Levels ../L2STIG/
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not implemented
# not implemented
# not implemented
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not in L2 STIG
# not implemented
cp -r NET_VLAN_004_Vlan_1_Not_Used ../L2STIG/
# not implemented
# not implemented
# not implemented
cp -r NET_VLAN_008_Native_Vlan_Not_Default ../L2STIG/
cp -r NET_VLAN_009_Native_Vlan_On_Access_Port ../L2STIG/
# not implemented
# not in L2 STIG

