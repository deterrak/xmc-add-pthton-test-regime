cp -r NET0230_Device_Password_Protected ../L3STIG/
cp -r NET0240_No_Default_Password ../L3STIG/
cp -r NET0340_Login_Banner ../L3STIG/
cp -r NET0400_IGP_Peer_Auth ../L3STIG/
# not implemented
cp -r NET0408_All_BGP_Peers_Authenticated ../L3STIG/
cp -r - ../L3STIG/
cp -r NET0433_MultipleAuthServers ../L3STIG/
# not implemented
cp -r NET0441_emergency_account ../L3STIG/
# not implemented
# not implemented
# not implemented
cp -r NET0600_Password_Viewable ../L3STIG/
# not implemented
# not implemented
cp -r NET0740_HTTP_Server_Disabled ../L3STIG/
# not implemented
# not implemented
# not implemented
cp -r NET0812_Multiple_NTP_Servers ../L3STIG/
cp -r NET0813_NTP_Authentication ../L3STIG/
# not implemented
# not implemented
cp -r NET0894_Snmp_Read_Only ../L3STIG/
cp -r NET0897_Auth_Uses_Mgmt_Vrf ../L3STIG/
cp -r NET0898_Syslog_Uses_Mgmt_Vrf ../L3STIG/
cp -r NET0899_NTP_Uses_Mgmt_Vrf ../L3STIG/
# not implemented
cp -r NET0901_SFLOW_Uses_Mgmt_Vrf ../L3STIG/
# not implemented
# not implemented
cp -r NET0965_Drop_Half_Open_Tcp ../L3STIG/
cp -r NET0966_Control_Plane_Protection ../L3STIG/
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not in L3 STIG
# not implemented
# not implemented
# not implemented
# not implemented
# not in L3 STIG
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
cp -r NET1020_Int_ACL_Deny_Not_Logged ../L3STIG/
cp -r NET1021_All_Messages_Logged ../L3STIG/
# not implemented
# not implemented
cp -r NET1624_Console_Timeout ../L3STIG/
# not implemented
# not implemented
cp -r NET1637_Mgt_Only_From_Hosts_In_Mgt_Net ../L3STIG/
cp -r NET1638_Mgt_FIPS140_Only ../L3STIG/
# not implemented
# not implemented
cp -r NET1645_Ssh_Session_Timeout ../L3STIG/
cp -r NET1646_Ssh_Max_Unsuccessful_Logins ../L3STIG/
# not implemented
cp -r NET1660_SNMPv3_SHA_AES ../L3STIG/
cp -r NET1665_SNMP_Valid_Community_Strings ../L3STIG/
cp -r NET1675_SNMP_Diff_Names_Diff_Levels ../L3STIG/
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
# not implemented
cp -r NET_VLAN_004_Vlan_1_Not_Used ../L3STIG/
# not implemented
# not implemented
# not implemented
cp -r NET_VLAN_008_Native_Vlan_Not_Default ../L3STIG/
cp -r NET_VLAN_009_Native_Vlan_On_Access_Port ../L3STIG/
# not implemented
# not implemented

