#!/usr/bin/env python2
#  File: governance-engine.py
#
#  Version: 1.0.1
#
#  Purpose: Audit configuration files and log data for devices managed by
#           Extreme Control. The configuration files are collected by
#           InventoryMgr, and are placed within a dedicated git repository by
#           the 'InventoryMgr-to-git.py' script associated with the Governance
#           Engine.
#
#  Copyright (C) 2016-2018 Extreme Networks, Inc.
#
#  Author: Michael Rash, mrash@extremenetworks.com
#

from governance import *
import stigaudit	### STIG auditing functions
import exosaudit        ### EXOS auditing functions
import wcontrolleraudit ### Wireless Controller auditing functions
import wingaudit        ### WiNG auditing functions
from governancesyslog import GovSyslog
from datetime import datetime
from pygtail import Pygtail
from shutil import rmtree
import logging
import logging.handlers
import MySQLdb as mdb
import glob
import time
import xml.etree.ElementTree as XML
import copy
import pprint
import re
import argparse
import sys, os

try:
    import subprocess32 as subprocess
except ImportError:
    import subprocess

__version__ = '1.0.1'

logger=GovSyslog()

def main():

    score_weights = {
        'High':100,
        'Medium':10,
        'Low':1
    }

    repo_dir     = None
    gitstats_dir = None
    im_dir_re    = '(?:\d{1,3}.){3}\d{1,3}'
    function_map = {}
    stats        = {'prcnts':{}, 'counts':{}, 'scores':{},
                        'orig_prcnts':{}, 'orig_counts':{}, 'orig_scores':{},
                        'High':{}, 'Medium':{}, 'Low':{}}

    wc_elm_types = {
        'allow_no_subname':{
            'ap':'',
            'topology':'',
            'snmp':'',
            'vnsmode':'',
            'l2ports':'',
            'host':'',
            'ip':'',
            'mitigator':'',
            'lbs':'',
            'time':'',
            'web':'',
            'secureconnection':'',
            'mobility':'',
            'syslog':'',
            'schedule_backup':'',
            'maintain_cycle':'',
            'login':'',
            'availability':'',
        },
        'single_line':{
            'ftp_server'
        }
    }

    verdict_to_features = {}
    features_to_desc    = {}
    netsight_job        = {}
    conf                = {}

    ### for TEST_FUNCTION and TEST_FUNCTION_MULTIVERDICT audit variables
    # DETERRAK
    for name in stigaudit.stig_function_map:
        function_map[name] = stigaudit.stig_function_map[name]

    for name in exosaudit.exos_function_map:
        function_map[name] = exosaudit.exos_function_map[name]

    for name in wcontrolleraudit.wcontroller_function_map:
        function_map[name] = wcontrolleraudit.wcontroller_function_map[name]

    for name in wingaudit.wing_function_map:
        function_map[name] = wingaudit.wing_function_map[name]

    cl = cmdline()

    if cl.version:
        print "%s version: %s" % (__file__, __version__)
        return 0

    db_run_id = 0

    ### see if we're going to interact with the DB
    if is_db_required(cl):

        print "IGE cmdline: %s" % str(sys.argv).replace("', '", ' ')

        conf = import_config(cl)

        if cl.db_list_test:
            return not db_list_test(conf, cl)
        elif cl.db_list_all_tests:
            return not db_list_all_tests(function_map, db_new_run_id(conf, cl), conf, cl)
        elif cl.db_list_version:
            return not db_list_version(conf, cl)
        elif cl.db_list_gov_types:
            return not db_list_gov_types(conf, cl)
        elif cl.db_import_test:
            db_run_id = db_new_run_id(conf, cl)
            ### import the audit tests and see if we have a match with
            ### --db-import-test
            audit_tests = import_tests(function_map, db_run_id, cl.governance_type, cl)
            found = False
            for node in audit_tests['nodes']:
                if node['BEGIN_NODE'] == cl.db_import_test:
                    db_import_test(node, conf, cl)
                    found = True
                ### also allow a search based on directory name
                ### 'meta': {'tests_file': '/home/mbr/git/compli.git/audit-tests/HIPAA/Web_Based_Configuration/EOS.conf'
                test_dir_name = node['meta']['tests_file'].split('/')[-2]
                if cl.db_import_test == test_dir_name:
                    db_import_test(node, conf, cl)
                    found = True
            es = 0
            if not found:
                print "[*] Could not find a %s test named '%s'" \
                        % (cl.governance_type, cl.db_import_test)
                es = 1
            return db_exit(db_run_id, es, conf, cl)
        elif cl.db_import_all_tests:
            if not db_gov_type_exists(conf, cl):
                db_add_gov_type(conf, cl)
            db_run_id = db_new_run_id(conf, cl)
            db_add_requirements(conf, cl)
            audit_tests = import_tests(function_map, db_run_id, cl.governance_type, cl)
            db_audit_tests = db_query("""
            SELECT t.auditTestId, t.name, dtype.deviceType
            FROM govAuditTests t, govRegimes r, govRegimeToAuditTest m,
            govAuditTestToDeviceType s, govDeviceTypes dtype
            WHERE t.isInternal = 1
            AND t.auditTestId = m.auditTestId
            AND r.regimeId = m.regimeId
            AND r.name = '%s'
            AND s.auditTestId = t.auditTestId
            AND s.deviceTypeId = dtype.deviceTypeId
            """ %cl.governance_type, conf, cl)['fetchall']
            
            if db_audit_tests:
                db_audit_tests = list(db_audit_tests)
            node_ctr = 0
            for node in audit_tests['nodes']:
                if cl.db_print_queries:
                    print "[+] Node: %s" % node['BEGIN_NODE']
                if db_import_test(node, conf, cl):
                    node_ctr += 1
                    if db_audit_tests:
                        index = next((i for i, v in enumerate(db_audit_tests) if v[1] == node['BEGIN_NODE'] and v[2] == node['meta']['type']), None)
                        if index is not None:
                            if db_audit_tests[index]:
                                db_audit_tests.pop(index)

            if db_audit_tests:
                for row in db_audit_tests:
                    print "Deleting audit test '%s' for device type '%s'" % (row[1], row[2])
                    db_query(
                        "DELETE FROM govAuditTests WHERE auditTestId = '%s'" \
                            % row[0], conf, cl)

            ### with all tests imported, now handle REQUIRED_TESTS test chains
            ### since all auditTestId values have been assigned
            for node in audit_tests['nodes']:
                if 'REQUIRED_TESTS' not in node:
                    continue
                if cl.db_print_queries:
                    print "[+] Node '%s' importing REQUIRED_TEST sequence: '%s'" \
                            % (node['BEGIN_NODE'], node['REQUIRED_TESTS'])
                db_import_test_sequence(node, conf, cl)

            print "[+] Imported %s tests..." % node_ctr
            return db_exit(db_run_id, 0, conf, cl)
        elif cl.db_add_gov_type:
            print "[+] Added '%s' (DB key: %s)" % \
                    (cl.governance_type, db_add_gov_type(conf, cl))
            db_add_requirements(conf, cl)
            return 1
        elif cl.db_rm_gov_type:
            return not db_rm_gov_type(conf, cl)
        elif cl.db_rm_test:
            return not db_rm_test(conf, cl)
        elif cl.db_rm_all_gov_data:
            return not db_rm_all_gov_data(conf, cl)
        elif cl.import_device_identities:
            return db_import_deviceIdentities(conf,cl)
        elif cl.import_third_party_devices :
            return db_import_third_party_devices(conf,cl)
        elif cl.read_third_party_devices :
            return db_read_third_party_devices(conf,cl)
        elif cl.delete_third_party_device:
            return db_delete_third_party_device(conf,cl,None)
        elif cl.reimport_third_party_devices:
            return db_reimport_third_party_devices(conf,cl)
        elif cl.rename_third_party_os_name :
            return db_rename_third_party_os_name(conf,cl)
        elif cl.upgrade_operations:
            return db_perform_upgrade_operations(conf,cl)

    if not verify_args(cl):
        return 1

    ### default governance type selection unless --job-file is set
    regimes = {cl.governance_type:''}

    ### import the jobs file coming from NetSight
    if cl.job_file:
        regimes = {}
        netsight_job = import_netsight_job_file(cl)
        for test in netsight_job['tests']:
            if test['regime'] not in regimes:
                regimes[test['regime']] = ''

    for regime in regimes:

        ### import audit configurations
        if cl.db_audit:
            conf = import_config(cl)
            cl.governance_type = regime ### HACK
            db_run_id = db_new_run_id(conf, cl)
            audit_tests = db_read_all_tests(function_map, db_run_id, conf, cl)
            db_map_audit_tests_to_run_id(audit_tests, db_run_id, conf, cl)
        else:
            audit_tests = import_tests(function_map, db_run_id, regime, cl)

        ### make sure that the specified test exists
        if cl.job_file:
            for test in netsight_job['tests']:
                test_exists(test['test_title'], True, audit_tests)
        if cl.test_title:
            test_exists(cl.test_title, False, audit_tests)
        if cl.test_type:
            test_file_exists(cl.test_type, audit_tests)

        if cl.dump_tests or cl.dump_to_html:
            if cl.dump_to_html:
                dump_tests_to_html(audit_tests, regime, cl)
            else:
                pprint.pprint(audit_tests)
            if cl.db_audit:
                return db_exit(db_run_id, 0, conf, cl)
            else:
                return 0

        ### set top level directory paths
        if cl.git_enable or cl.db_audit:
            repo_dir, gitstats_dir = git_paths(cl)

        ### 
        log_lines = xml_log_data = None

        ### parse device directories (like 'configs/10.5.0.27/') to
        ### determine device type
        dev_results, all_devs,unknown_devices = import_devices(im_dir_re,
                    repo_dir, wc_elm_types, netsight_job, db_run_id, cl)
        
        ### Import log data only if there's at least one Wireless Controller being audited
        for devs in all_devs:
            if devs in dev_results['types'] and dev_results['types'][devs] and dev_results['types'][devs] == 'WController':
                ### import any (new) log data
                log_lines, xml_log_data = import_log_data(conf, regime, cl)
                ### promote log data from wireless controllers devices too even if there
                ### are no associated configs
                add_wcontrollers(log_lines, xml_log_data, dev_results, all_devs, cl)
                break        

        audit_results = audit_devs(audit_tests, dev_results,unknown_devices, verdict_to_features,
                repo_dir, log_lines, xml_log_data, regime, db_run_id,
                netsight_job, score_weights, conf, cl)

        if cl.db_audit and not audit_results:
            print "[*] Tried %s tests, but no applicable device/test combinations" % regime
            return db_exit(db_run_id, 1, conf, cl)

        changed_devs = 0

        ### write out the governance report for each device
        for dev in audit_results:

            verdicts = audit_results[dev]

            if cl.stdout:
                print "%s " % dev
                for pri in ['High', 'Medium', 'Low']:
                    if pri not in verdicts:
                        continue
                    for result in verdicts[pri]:
                        if not result:
                            continue
                        print "%s" % result['line']
                continue

            write_verdicts(verdicts,
                            dev, dev_results, audit_tests, stats,
                            features_to_desc, repo_dir, score_weights,
                            regime, db_run_id, conf, cl)
            
        if cl.stdout:
            print "\n[+] Audit complete in --stdout mode, not committing anything to git.\n"
            if cl.db_audit:
                return db_exit(db_run_id, 0, conf, cl)
            else:
                return 0
        else:
            results_dir = "%s/audit/%s" % (repo_dir, regime)
            if cl.audit_file or cl.audit_dir:
                results_dir = 'audit/%s' % regime
            if cl.flat_output_dir:
                results_dir = cl.flat_output_dir
            print "[+] Results available in: %s/" % results_dir

        ### write the final summary report
        if cl.db_audit:
            write_summary_results(stats, audit_results, dev_results,
                    all_devs, verdict_to_features, changed_devs,
                    audit_tests, repo_dir, score_weights, regime,
                    db_run_id, conf, cl)
        else:
            if not cl.audit_file and not cl.audit_dir:
                write_summary_results(stats, audit_results, dev_results,
                        all_devs, verdict_to_features, changed_devs,
                        audit_tests, repo_dir, score_weights, regime,
                        db_run_id, conf, cl)
        
        
        if cl.git_enable:
            curr_dir = os.getcwd()
            os.chdir(repo_dir)
            ### Adding all the records to git
            git_add("audit", "Reports for Regime %s" % (regime), cl)
            os.chdir(curr_dir)
            
            if cl.enable_gitstats:
                run_gitstats(gitstats_dir, repo_dir, cl)

        if cl.db_audit:
            ### set the end time for this run
            db_set_endtime(db_run_id, conf, cl)

    if cl.db_audit:
        sys.stdout.write("\n") ### for NetSight error parsing
        sys.stderr.write("\n")

    return 0 ### end main()

def netsight_job_match_dev(device_dir, firmware, netsight_job, cl):

    ### see if we have a matching device in the NetSight job
    found_dev = False
    for ndev in netsight_job['devices']:
        ### be generous on the matching here
        if device_dir == ndev['dev_ip'] \
                or device_dir == ndev['dev_hostname'] \
                or device_dir == ndev['id_str'] \
                or firmware == ndev['id_str']:
            found_dev = True
    if not found_dev:
        if cl.verbose:
            print "[-] Could not match dev: '%s' against --job-file 'devices' line." \
                    % (device_dir)
    return found_dev

def import_netsight_job_file(cl):

    ### jobId=20
    ### tests='PCI'/'CDP'/'S-Series','PCI'/'CDP'/'a2'
    ### devices='10.54.80.20/somehost/A4H254-8F8T','10.54.80.21/somehost/A4H124-24'

    netsight_job = {}
    with open(cl.job_file, 'r') as f:
        for line in f:
            line = line.rstrip()
            (lvar, data) = line.split('=')
            if lvar in netsight_job:
                raise NameError("[*] '%s' already defined in job file" % lvar)
            if lvar == 'jobId':
                m = re.search('(\d+)', data)
                if m:
                    netsight_job[lvar] = m.group(1)
            elif lvar == 'tests':
                netsight_job[lvar] = []
                for test in data.split("','"):
                    regime, test_title, dev_identifier = test.split("'/'")
                    regime = regime.replace("'", '')
                    test_title = test_title.replace("'", '')
                    dev_identifier = dev_identifier.replace("'", '')
                    if regime == 'UNKNOWN':
                        regime = 'PCI' ### FIXME: work around for net0044674
                    netsight_job[lvar].append({'regime':regime,
                        'test_title':test_title, 'dev_identifier':dev_identifier})
            elif lvar == 'devices':
                netsight_job[lvar] = []
                for dev in data.split(','):
                    dev = dev.replace("'", '')
                    (dev_ip, dev_hostname, id_str) = dev.split('/')
                    netsight_job[lvar].append({'dev_ip':dev_ip,
                        'dev_hostname':dev_hostname, 'id_str':id_str})

    for lvar in ['jobId', 'tests', 'devices']:
        if lvar not in netsight_job:
            raise NameError("[*] '%s' not defined in job file" % lvar)

    return netsight_job

def verdict_to_int(verdict):
    vint = 0
    if 'pass' in verdict.lower():
        vint = 1
    elif 'info' in verdict.lower():
            vint = 2
    return vint

def int_to_verdict(wint):
    if wint == 1:
        return 'pass'
    elif wint == 2:
        return 'info'
    return 'fail'

def int_to_weight(wint):
    if wint == 2:
        return 'Medium'
    elif wint == 3:
        return 'High'
    return 'Low'

def weight_to_int(node, nkey):
    wint = 1  ### 'Low' priority by default
    if nkey in node:
        if 'medium' in node[nkey].lower():
            wint = 2
        elif 'high' in node[nkey].lower():
            wint = 3
    return wint

def bool_to_key(val):
    if val:
        return 'true'
    return 'false'

def key_to_bool(node, nkey):
    val = 0
    if nkey in node:
        if 'true' in node[nkey].lower():
            val = 1
    return val

def key_to_str(node, nkey):
    val = ''
    if nkey in node:
        val = node[nkey]
    return val

def import_log_data(conf, regime, cl):
    log_lines    = False
    xml_log_data = {}

    log_file = False

    if cl.db_audit:
        if db_ignore_wireless_threats(conf, cl):
            return log_lines, xml_log_data

    if cl.skip_log_parsing:
        return log_lines, xml_log_data

    if cl.log_threats_file:
        ofile = os.path.abspath(cl.log_threats_file + '.' + regime + '.offset')
        
        if not os.path.exists(cl.log_threats_file):
            raise NameError("[*] --log-threats-file %s does not exist." \
                    % cl.log_threats_file)
        if cl.log_reset_offset and \
                os.path.exists(ofile):
            os.remove(ofile)
        remove_non_ascii_chars(cl.log_threats_file, cl.verbose)
        log_lines = Pygtail(cl.log_threats_file, offset_file=ofile)
    else:
        lfile = os.path.abspath(cl.netsight_dir + \
                os.sep + 'appdata' + os.sep + 'logs' +  os.sep + \
                os.sep + 'bk_polls' + os.sep + 'threats.txt')
        ofile = os.path.abspath(lfile + '.' + regime + '.offset')
        
        if os.path.exists(lfile):
            if cl.log_reset_offset and \
                    os.path.exists(ofile):
                os.remove(ofile)
            remove_non_ascii_chars(lfile, cl.verbose)
            log_lines = Pygtail(lfile, offset_file=ofile)
        else:
            return log_lines, xml_log_data

    ### see if the log data is XML
    is_xml = False
    if log_lines:
        for line in log_lines:
            if '<list>' in line or '<list/>' in line:
                is_xml = True
                break

    if not is_xml:
        return log_lines, xml_log_data

    current_wcontroller = ''
    xml_str = ''
    for line in log_lines:
        m = re.search('^\[.*\sEWC\((\S+?)\)', line)
        if m:
            if xml_str:
                xml_obj = XML.fromstring(xml_str)
                if len(xml_obj):
                    if current_wcontroller not in xml_log_data:
                        xml_log_data[current_wcontroller] = []
                    xml_log_data[current_wcontroller].append(xml_obj)

            current_wcontroller = m.group(1)
            xml_str = ''
            continue

        if current_wcontroller and '<' in line:
            ### parse the XML content into a string for this controller
            xml_str += line.rstrip()

    if current_wcontroller and xml_str:
        xml_obj = XML.fromstring(xml_str)
        if len(xml_obj):
            if current_wcontroller not in xml_log_data:
                xml_log_data[current_wcontroller] = []
            xml_log_data[current_wcontroller].append(xml_obj)

    return log_lines, xml_log_data

# strip non-ascii chars from Radar events before parsing threats file
def remove_non_ascii_chars(file_with_nonascii, verbose):
    do_cmd("perl -p -i -e 's|[^\x21-\x7e]||g' " + file_with_nonascii, verbose)

### Google charts header for a audit-test file tracking
def gcharts_audit_test_hdr(title, gcharts_lines, cl):
    tmp_lines = []
    tmp_lines.append('''<html>
  <head>
    <!--Load the AJAX API-->
    <!-- script type="text/javascript" src="https://www.google.com/jsapi"></script -->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">

      // Load the Visualization API and the piechart package.
      google.charts.load('current', {'packages':['corechart', 'table', 'bar', 'line']});

      // Set callbacks to run when the Google Visualization API is loaded.
      google.charts.setOnLoadCallback(tbl_devs_per_audit_test);
      google.charts.setOnLoadCallback(tbl_audit_documentation);
''')

    ### prepend
    gcharts_lines[:0] = tmp_lines
    return

### Google charts header for a specific device
def gcharts_dev_hdr(dev, title, gcharts_lines, cl):
    tmp_lines = []
    tmp_lines.append('''<html>
  <head>
    <!--Load the AJAX API-->
    <!-- script type="text/javascript" src="https://www.google.com/jsapi"></script -->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">

      // Load the Visualization API and the piechart package.
      google.charts.load('current', {'packages':['corechart', 'table', 'bar', 'line']});

      // Set callbacks to run when the Google Visualization API is loaded.
      google.charts.setOnLoadCallback(tbl_dev_summary);
      google.charts.setOnLoadCallback(pie_dev_score);
      google.charts.setOnLoadCallback(line_dev_scores);
      google.charts.setOnLoadCallback(tbl_dev_pass_fail);
      google.charts.setOnLoadCallback(tbl_dev_audit_tests);
''')

    ### prepend
    gcharts_lines[:0] = tmp_lines
    return

def gcharts_hdr(dev_type_avgs, title, gcharts_lines, cl):

    tmp_lines = []
    tmp_lines.append('''<html>
  <head>
    <!--Load the AJAX API-->
    <!-- script type="text/javascript" src="https://www.google.com/jsapi"></script -->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">

      // Load the Visualization API and the piechart package.
      google.charts.load('current', {'packages':['corechart', 'table', 'bar', 'line']});

      // Set callbacks to run when the Google Visualization API is loaded.
      google.charts.setOnLoadCallback(tbl_summary);
      google.charts.setOnLoadCallback(tbl_avg_devtype_scores);
''')

    ### pie charts for average dev type scores
    for dtype in sorted(dev_type_avgs):
        tmp_lines.append('        google.charts.setOnLoadCallback(pie_%s_avg_score);' % dtype)

    ### line chart for average dev type scores
    tmp_lines.append('        google.charts.setOnLoadCallback(line_OS_avg_scores);')

    tmp_lines.append('''
      google.charts.setOnLoadCallback(tbl_avg_pass_rates);
      google.charts.setOnLoadCallback(tbl_pass_fail_per_dev);
      google.charts.setOnLoadCallback(tbl_audit_tests_per_dev_type);
''')

    ### prepend
    gcharts_lines[:0] = tmp_lines

    ### FIXME: need to pass in the table names
    return

### Google charts footer for a audit-test file tracking
def gcharts_audit_test_footer(gcharts_lines, regime, cl):
    gcharts_lines.append('''
    </script>
    </head>

    <body>

    <br/><h3><font color="blue">%s Audit Test Device Verdicts</font></h3>
    <div id="tbl_devs_per_audit_test"></div>

    <br/><h3><font color="blue">Audit Test Specifics</font></h3>
    <div id="tbl_audit_documentation"></div>

    </body>
    </html>

''' % regime)

    return

### Google charts footer for a specific device
def gcharts_dev_footer(dev, gcharts_lines, regime, cl):
    gcharts_lines.append('''
    </script>
    </head>

    <body>

    <br/><h3><font color="blue">%s Assessment Summary</font></h3>
    <div id="tbl_dev_summary"></div>

    <br/><h4><font color="blue">Governance Assessment Score</font></h4>
    <div id="pie_dev_score"></div>

    <br/><h4><font color="blue">Device Scores Over Time</font></h4>
    <div id="line_dev_scores"></div>

    <br/><h4><font color="blue">Pass/Fail Rates</font></h4>
    <div id="tbl_dev_pass_fail"></div>

    <br/><h4><font color="blue">Device Audit Tests</font></h4>
    <div id="tbl_dev_audit_tests"></div>

    </body>
    </html>

''' % regime)

    return


def gcharts_footer(dev_type_avgs, gcharts_lines, cl):
    gcharts_lines.append('''
    </script>
    </head>

    <body>

    <br/><h3><font color="blue">%s Assessment Summary</font></h3>
    <div id="tbl_summary"></div>

    <br/><h4><font color="blue">Average Device Type Governance Assessment Weighted Scores</font></h4>
    <div id="tbl_avg_devtype_scores"></div>
''' % cl.governance_type)

    dtype_ctr = 0
    gcharts_lines.append('    <table>')
    for dtype in sorted(dev_type_avgs):
        if dtype_ctr % 3 == 0:
            gcharts_lines.append('    <tr>')

#        gcharts_lines.append('    <div id="pie_%s_avg_score" style="width: 300px; height: 300px;"></div>' % dtype)
        gcharts_lines.append('    <td><div id="pie_%s_avg_score"></div></td>' % dtype)
        if dtype_ctr+1 % 3 == 0:
            gcharts_lines.append('    </tr>')
        dtype_ctr += 1
    if dtype_ctr % 3 != 0:
        gcharts_lines.append('    </tr>')
    gcharts_lines.append('    </table>')

    gcharts_lines.append('''
    <div id="line_OS_avg_scores"></div>
    <br/><h4><font color="blue">Average Device Type Pass Rates</font></h4>
    <div id="tbl_avg_pass_rates"></div>

    <br/><h4><font color="blue">Governance Assessment Per Device</font></h4>
    <div id="tbl_pass_fail_per_dev"></div>

    <br/><h4><font color="blue">Audit Tests Per Device Type</font></h4>
    <div id="tbl_audit_tests_per_dev_type"></div>

    </body>
    </html>
''')
    return

def gcharts_line(line_data, line_title, graph_name, gcharts_lines, cl):

    gcharts_lines.append('''
    function %s() {
        var data = google.visualization.arrayToDataTable([''' % graph_name)

    ### start with column definition
    row_str = '        ['
    val_ctr = 0
    for val in line_data[0]:
        row_str += "'%s'," % val
        if val_ctr == len(line_data[0])-1:
            row_str = row_str[0:-1]
        val_ctr += 1
    row_str += '],'
    gcharts_lines.append("%s" % row_str)

    row_ctr = 1
    for row_arr in line_data[1:]:
        row_str = '        ['
        val_ctr = 0
        for val in row_arr:
            if val_ctr == 0:
                row_str += "'%s'," % val
            else:
                row_str += "%.2f," % val
            if val_ctr == len(row_arr)-1:
                row_str = row_str[0:-1]
            val_ctr += 1
        row_str += '],'
        if row_ctr == len(line_data)-1:
            row_str = row_str[0:-1]
        row_ctr += 1
        gcharts_lines.append("%s" % row_str)

    gcharts_lines.append('''
               ]);

        var options = {
            title: '%s',
            width: 1100,
            height: 600,
        };

        var chart = new google.visualization.LineChart(document.getElementById('%s'));

        chart.draw(data, options);
    }
''' % (line_title, graph_name))

    return

def gcharts_pie(pie_data, pie_title, graph_name, gcharts_lines, cl):

    gcharts_lines.append('''
    function %s() {
        var data = google.visualization.arrayToDataTable([''' % graph_name)

    row_ctr = 0
    row_str = "        ['%s', '%s']," % (pie_data[0][0], pie_data[0][1])
    gcharts_lines.append("%s" % row_str)
    for row_arr in pie_data[1:]:
        row_str = "        ['%s', %.2f]," % (row_arr[0], float(row_arr[1]))
        if row_ctr == len(pie_data)-1:
            row_str = row_str[0:-1]
        row_ctr += 1
        gcharts_lines.append("%s" % row_str)

    gcharts_lines.append('''
               ]);

        var options = {
            title: '%s',
            colors: ['green', 'red']
        };

        var chart = new google.visualization.PieChart(document.getElementById('%s'));

        chart.draw(data, options);
    }
''' % (pie_title, graph_name))

    return

def gcharts_table(data_rows, tbl_name, gcharts_lines, cl):

    gcharts_lines.append('''
    function %s() {
        var tableData = google.visualization.arrayToDataTable([''' % tbl_name)

    row_ctr = 0
    for row_arr in data_rows:
        row_str = '        ['
        val_ctr = 0
        for val in row_arr:
            row_str += "'%s'," % val
            if val_ctr == len(row_arr)-1:
                row_str = row_str[0:-1]
            val_ctr += 1
        row_str += '],'
        if row_ctr == len(data_rows)-1:
            row_str = row_str[0:-1]
        row_ctr += 1
        gcharts_lines.append("%s" % row_str)

    show_row_nums = 'true'
    if len(data_rows) < 2:
        show_row_nums = 'false'

    gcharts_lines.append('''
        ]);

        var geoView = new google.visualization.DataView(tableData);
        geoView.setColumns([0, 1]);

        var table =
            new google.visualization.Table(document.getElementById('%s'));
        table.draw(tableData, {showRowNumber: %s, allowHtml: true});

        }
''' % (tbl_name, show_row_nums))
    return

def dev_type_link(dev_type, dev_dir, cl):

    curr_dir = os.getcwd()
    os.chdir('configs')
    types_dir = 'dev-types'
    if not os.path.exists(types_dir):
        os.mkdir(types_dir)
    os.chdir(types_dir)
    if not os.path.exists(dev_type):
        os.mkdir(dev_type)
    os.chdir(dev_type)

    if not os.path.exists(dev_dir):
        os.symlink('../../%s' % dev_dir, dev_dir)

    os.chdir(curr_dir)
    return

def write_summary_results(stats, audit_results, dev_results, all_devs,
        verdict_to_features, changed_devs, audit_tests, repo_dir,
        score_weights, regime, db_run_id, conf, cl):

    curr_dir = os.getcwd()
    os.chdir(repo_dir + os.sep + 'audit' + os.sep + regime)

    ### overall summary results
    summary_file = os.path.abspath(regime + '.summary')

    ### track a few stats over time for time-series graphs
    stats_file = os.path.abspath(regime + '.stats')

    ### optional Google Charts integration
    gcharts_lines = []
    gcharts_summary_rows = []
    gcharts_file = os.path.abspath(regime + '_google_charts.html')

    dev_types   = dev_results['types']
    dev_details = dev_results['details']
    dev_type_avgs = {}

    prev_summary_stats   = {}
    prev_score_stats     = {}
    prev_matches         = {}
    prev_report_datetime = '[NA]'
    prev_changed_devices = '0'

    prev_report_datetime, prev_changed_devices = import_summary_file(prev_summary_stats,
            prev_score_stats, prev_matches, changed_devs, summary_file)

    with open(summary_file, 'w') as f:

        detected_devs       = len(dev_types)
        detected_devs_prcnt = float(detected_devs) / float(len(all_devs)) * 100
        unknown_devs        = len(all_devs) - detected_devs
        unknown_devs_prcnt  = float(len(all_devs) - detected_devs) / (float(len(all_devs)) * 100)
        audited_devs        = len(audit_results)
        audited_devs_prcnt  = float(audited_devs) / (float(len(all_devs)) * 100)

        f.write("\n%s SUMMARY RESULTS\n\n" % regime)
        f.write(" Current report generated: %s\n" % str(datetime.now()))
        f.write("Previous report generated: %s\n\n" % prev_report_datetime)
        f.write("     Detected Device Types: %d, %.2f%%\n" % \
                (detected_devs, detected_devs_prcnt))
        f.write("      Unknown Device Types: %d, %.2f%%\n" % \
                (unknown_devs, unknown_devs_prcnt))
        f.write("           Audited Devices: %d, %.2f%%\n" % \
                (audited_devs, audited_devs_prcnt))
        f.write("Devices with audit changes: %d [%s]\n" % \
                (changed_devs, prev_changed_devices))
        f.write("             Total Devices: %d\n\n" % len(all_devs))

        if cl.google_charts:
            gcharts_summary_rows.append([
                'Detected Device Types',
                'Unknown Device Types',
                'Audited Devices',
                'Changed Devices',
                'Total Devices',
                'Previous Report',
                'Current Report',
            ])
            gcharts_summary_rows.append([
                detected_devs,
                unknown_devs,
                audited_devs,
                changed_devs,
                len(all_devs),
                (prev_report_datetime)[0:-7],
                (str(datetime.now()))[0:-7],
            ])
            gcharts_table(gcharts_summary_rows, 'tbl_summary', gcharts_lines, cl)

        ### Overall average weighted scores
        dev_type_avgs = write_avg_devtype_governance_scores(dev_types,
                dev_details, audit_results, stats, prev_score_stats,
                gcharts_lines, f, stats_file, db_run_id, conf, cl)

        ### Scores per device
        write_governance_scores_per_device(dev_types, dev_details,
                audit_results, stats, gcharts_lines, f, cl)

        ### Average pass rates per device type
        dev_ctrs = write_average_pass_rates(dev_types, audit_results, stats,
                prev_summary_stats, gcharts_lines, f, cl)

        f.write("\n--- PASS/FAILURE RATES PER DEVICE ---\n\n")
        write_stats_legend(f)

        f.write("%-9s %-16s %-12s %-7s %-10s %-20s %s\n\n" % \
                ('Priority:', 'Device:', 'P/F/T/A:', 'Pass:',
                    'Delta:', 'Type:', 'AuditResults:'))

        gcharts_pass_fail_per_dev = []
        if cl.google_charts:
            gcharts_pass_fail_per_dev.append([
                'Priority',
                'Device IP/Host',
                'Type',
                'Device Details',
                'Pass',
                'Fail',
                'Total',
                'Applicable',
                'Pass %',
                '&Delta;',
                'Assessment Weighted Score',
                '&Delta;',
            ])

        ### print out a sorted list of devices for each priority listing
        for pri in ['High', 'Medium', 'Low', 'Overall']:
            for item in sorted(stats['prcnts'].items(),
                    key = lambda tup: (tup[1][pri])):

                dev   = item[0]
                prcnt = item[1][pri]

                type_str = dev_types[dev]
                prcnt_str = "%.2f%%" % prcnt
                details_str = ' '

                if dev in dev_results['details'] \
                        and dev_results['details'][dev]:
                    type_str += ' ' + dev_results['details'][dev]
                    details_str = dev_results['details'][dev]

                prev_str, delta_str = stats_delta(pri, prcnt,
                        stats['orig_prcnts'][dev], stats['orig_counts'][dev])

                f.write("%-9s %-16s %-12s %-7s %-10s %-20s %s\n" % \
                        (pri, dev, stats['counts'][dev][pri],
                        prcnt_str, delta_str,
                        type_str, dev + os.sep \
                                + dev + '.audit'))

                if cl.google_charts:
                    if pri == 'Overall':
                        continue
                    pri_pass = ' '
                    pri_fail = ' '
                    pri_tot  = ' '
                    pri_applicable = ' '
                    if pri in stats and dev in stats[pri]:
                        if 'pass' in stats[pri][dev]:
                            pri_pass = stats[pri][dev]['pass']
                        if 'fail' in stats[pri][dev]:
                            pri_fail = stats[pri][dev]['fail']
                        if 'total' in stats[pri][dev]:
                            pri_tot = stats[pri][dev]['total']
                        if 'applicable' in stats[pri][dev]:
                            pri_applicable = stats[pri][dev]['applicable']

                    gcharts_pass_fail_per_dev.append([
                        pri,
                        '<a href="%s/%s_google_charts.html">%s</a>' % (dev, dev, dev),
                        dev_types[dev],
                        details_str,
                        '<font color="green">' + str(pri_pass) + '</font>',
                        '<font color="red">' + str(pri_fail) + '</font>',
                        pri_tot,
                        pri_applicable,
                        prcnt_str,
                        colorize_delta(delta_str, True),
                        "%.2f" % stats['scores'][dev],
                        colorize_delta(val_delta_str(stats['scores'][dev],
                            stats['orig_scores'][dev]), True)
                    ])

            f.write("\n")

        if cl.google_charts:
            gcharts_table(gcharts_pass_fail_per_dev,
                    'tbl_pass_fail_per_dev', gcharts_lines, cl)

        f.write("Unaudited Devices:\n")
        for dev in all_devs:
            if dev not in audit_results:
                dev_type = '[unknown type]'
                dev_file = '[unknown details]'
                if dev in dev_results['types']:
                    dev_type = dev_results['types'][dev]
                if dev in dev_results['running_configs']:
                    dev_file = dev_results['running_configs'][dev]
                f.write("    %-16s %-12s %s\n" % \
                        (dev, dev_type, dev_file))
        f.write("\n")

        gcharts_audit_tests_per_dev_type = []
        if cl.google_charts:
            gcharts_audit_tests_per_dev_type.append([
                'Audit Test',
                'Verdict',
                'Priority',
                'Matches',
                '&Delta;',
                'Devices',
                '&Delta;',
                'Device Type',
            ])

        ### Stats on verdicts for audited features
        f.write("\n--- DEVICE MATCHES PER AUDIT TEST ---\n\n")
        for dtype in sorted(verdict_to_features):
            if dtype in dev_ctrs:
                f.write("Type: %s, Total Devices: %d\n\n" % (dtype, dev_ctrs[dtype]))
                f.write("    %-9s %-10s %-12s %-12s %s\n" % \
                    ('Verdict:', 'Priority:', 'Matches:', 'Devices:', 'AuditFeature:'))
                for pri in ['High', 'Medium', 'Low']:
                    if pri not in verdict_to_features[dtype]:
                        continue

                    features_to_verdicts = {}

                    for verdict in ['fail', 'pass']:
                        if verdict not in verdict_to_features[dtype][pri]:
                            continue

                        for feature in sorted(verdict_to_features[dtype][pri][verdict]):

                            if feature not in features_to_verdicts:
                                features_to_verdicts[feature] = {}
                            if verdict not in features_to_verdicts[feature]:
                                features_to_verdicts[feature][verdict] = []

                            feature_tracking_prefix = re.sub(r'\W','', feature)
                            gcharts_audit_test_file = '%s/' % cl.tests_dir + dtype + \
                                '/' + feature_tracking_prefix + '_google_charts.html'

                            count = verdict_to_features[dtype][pri][verdict][feature]['matches']
                            matches_delta = '0'
                            if dtype in prev_matches and feature in prev_matches[dtype]:
                                matches_delta = count_delta_str(count,
                                    prev_matches[dtype][feature]['matches'])

                            count_str = "%-4d %-7s" % (count, "[%s]" % matches_delta)

                            devices_delta = '0'

                            for dev in sorted(verdict_to_features[dtype][pri][verdict][feature]['devices']):
                                features_to_verdicts[feature][verdict].append(dev)

                            devices = len(verdict_to_features[dtype][pri][verdict][feature]['devices'].keys())
                            if dtype in prev_matches and feature in prev_matches[dtype]:
                                devices_delta = count_delta_str(devices,
                                    prev_matches[dtype][feature]['devices'])

                            devices_str = "%-4d %-7s" % (devices, "[%s]" % devices_delta)

                            f.write("    %-9s %-10s %-12s %-12s %s\n" % \
                                    (verdict, pri, count_str, devices_str, feature))

                            if cl.google_charts:
                                gcharts_audit_tests_per_dev_type.append([
                                    '<a href="%s">%s</a>' % (gcharts_audit_test_file, feature),
                                    colorize_verdict(verdict),
                                    pri,
                                    count,
                                    colorize_delta(matches_delta, True),
                                    devices,
                                    colorize_delta(devices_delta, True),
                                    dtype,
                                ])

                    ### audit test device tracking
                    if not os.path.exists(cl.tests_dir):
                        os.mkdir(cl.tests_dir)
                    if not os.path.exists(cl.tests_dir + '/' + dtype):
                        os.mkdir(cl.tests_dir + '/' + dtype)

                    for feature in features_to_verdicts:
                        prefix = re.sub(r'\W','', feature)

                        gcharts_devs_per_audit_test = []
                        gcharts_audit_documentation = []
                        gcharts_audit_test_file = '%s/%s/%s_google_charts.html' % (cl.tests_dir, dtype, prefix)
                        gcharts_devs_per_audit_test.append([
                                'Verdict',
                                'Device',
                                'Score',
                            ])
                        gcharts_audit_documentation.append([
                                'Audit Test',
                                'Priority',
                                'Advisory',
                                'Audit Criteria',
                                'Example',
                            ])

                        gcharts_printed_node_doc = {dtype:{}}
                        with open('%s/%s/%s.devs' % (cl.tests_dir, dtype, prefix), 'w') as devfh:
                            for verdict in features_to_verdicts[feature]:
                                for dev in sorted(features_to_verdicts[feature][verdict]):
                                    devfh.write("%s %s\n" % (verdict, dev))

                                    gcharts_devs_per_audit_test.append([
                                            colorize_verdict(verdict),
                                            '<a href="../../%s/%s_google_charts.html">%s</a>' % \
                                                    (dev, dev, dev),
                                            "%.2f" % stats['scores'][dev]
                                    ])

                                    if feature in gcharts_printed_node_doc[dtype]:
                                        continue

                                    weight         = 'NA'
                                    advisory       = 'NA'
                                    audit_criteria = 'NA'
                                    example        = 'NA'
                                    if feature in audit_tests['name_to_vars']:
                                        if 'WEIGHT' in audit_tests['name_to_vars'][feature]:
                                            weight = audit_tests['name_to_vars'][feature]['WEIGHT']
                                        if 'AUDIT_CRITERIA_EXPANDED' in audit_tests['name_to_vars'][feature]:
                                            audit_criteria = audit_tests['name_to_vars'][feature]['AUDIT_CRITERIA_EXPANDED']
                                        if 'ADVISORY' in audit_tests['name_to_vars'][feature]:
                                            advisory = ''
                                            for line in audit_tests['name_to_vars'][feature]['ADVISORY']:
                                                advisory += line
                                        if 'EXAMPLE' in audit_tests['name_to_vars'][feature]:
                                            example = ''
                                            for line in audit_tests['name_to_vars'][feature]['EXAMPLE']:
                                                example += line

                                    gcharts_audit_documentation.append([
                                        feature,
                                        weight,
                                        advisory,
                                        audit_criteria,
                                        example,
                                    ])

                                    gcharts_printed_node_doc[dtype][feature] = ''

                        if cl.google_charts:
                            glines = []
                            gcharts_audit_test_hdr("%s Governance - Audit Test Device Tracking" % \
                                    regime, glines, cl)
                            gcharts_table(gcharts_devs_per_audit_test,
                                    'tbl_devs_per_audit_test', glines, cl)
                            gcharts_table(gcharts_audit_documentation,
                                    'tbl_audit_documentation', glines, cl)
                            gcharts_audit_test_footer(glines, regime, cl)
                            with open(gcharts_audit_test_file, 'w') as gcf:
                                for line in glines:
                                    gcf.write("%s\n" % line)

                    f.write("\n")

        if cl.google_charts:
            gcharts_table(gcharts_audit_tests_per_dev_type,
                    'tbl_audit_tests_per_dev_type', gcharts_lines, cl)

        ### write out the individual devices for each failed test
        if dtype in dev_ctrs:
            write_device_failure_listings(dtype, dev_ctrs[dtype], verdict_to_features, f, cl)

        if regime == 'PCI':
            write_PCI_requirements_summary(f)

    ### write out Google charts .html file
    if cl.google_charts:
        gcharts_hdr(dev_type_avgs,
                "%s Governance Summary" % regime,
                gcharts_lines, cl)
        gcharts_footer(dev_type_avgs, gcharts_lines, cl)
        with open(gcharts_file, 'w') as f:
            for line in gcharts_lines:
                f.write("%s\n" % line)

    os.chdir(curr_dir)

    print "[+] Summary report available here: %s/audit/%s/%s.summary" % \
            (repo_dir, regime, regime)
    return

def import_summary_file(prev_summary_stats, prev_score_stats,
        prev_matches, changed_devs, summary_file):

    prev_report_datetime = '[NA]'
    prev_changed_devices = '0'

    if not os.path.exists(summary_file):
        return '[NA]', '0'

    with open(summary_file, 'r') as f:
        current_type = None

        for line in f:

            m = re.search('^\s+Current report generated\:\s+(.*)', line)
            if m:
                prev_report_datetime = m.group(1)
                continue

            m = re.search('^Devices with audit changes:\s+(\d+)', line)
            if m:
                prev_changed_devices = count_delta_str(changed_devs, int(m.group(1)))
                continue

            ### EOS    1     50.00%  +12.50% 30.00%  [0]    43.75%  [0]    41.18%   [0]
            m = re.search('^(\S+)\s+\d+\s+(\d{1,3}\.\d{2})\%\s+\S+\s+' \
                    + '(\d{1,3}\.\d{2})\%\s+\S+\s+(\d{1,3}\.\d{2})\%\s+\S+\s+' \
                    + '(\d{1,3}\.\d{2})\%', line)
            if m:
                dtype = m.group(1)
                prev_summary_stats[dtype] = {}
                prev_summary_stats[dtype]['High']    = m.group(2)
                prev_summary_stats[dtype]['Medium']  = m.group(3)
                prev_summary_stats[dtype]['Low']     = m.group(4)
                prev_summary_stats[dtype]['Overall'] = m.group(5)
                continue

            m = re.search('^(\S+)\s+\d+\s+(\d{1,3}\.\d{2})\s+/\s100', line)
            if m:
                prev_score_stats[m.group(1)] = m.group(2)
                continue

            m = re.search('^Type:\s(\S+)\,', line)
            if m:
                current_type = m.group(1)
                continue

            if current_type:
                ###     pass   High    1 [0]  1 [0] Host Access Authentication with RADIUS
                m = re.search('^\s{4}\w{4}\s+\w+\s+(\d+)\s+\S+\s+(\d+)\s+\S+\s+(.*)', line)
                if m:
                    matches = int(m.group(1))
                    devices = int(m.group(2))
                    feature = m.group(3)

                    if current_type not in prev_matches:
                        prev_matches[current_type] = {}
                    if feature not in prev_matches[current_type]:
                        prev_matches[current_type][feature] = {}
                    prev_matches[current_type][feature]['matches'] = matches
                    prev_matches[current_type][feature]['devices'] = devices

    return prev_report_datetime, prev_changed_devices

def write_device_failure_listings(dtype, tot_devs, verdict_to_features, f, cl):

    f.write("\n--- DEVICE FAILURE LISTINGS ---\n")
    for dtype in sorted(verdict_to_features):
        f.write("\nType: %s, Total Devices: %d\n\n" % (dtype, tot_devs))
        f.write("    %-s / %s / %s / %s\n" % \
                ('Verdict', 'Priority', 'AuditFeature', 'Criteria'))
        for pri in ['High', 'Medium', 'Low']:
            if pri not in verdict_to_features[dtype]:
                continue

            # DETERRAK-> 
            if 'fail' not in verdict_to_features[dtype][pri]:
                continue
                #pass

            for feature in sorted(verdict_to_features[dtype][pri]['fail']):

                criteria = verdict_to_features[dtype][pri]['fail'][feature]['criteria']
                f.write("\n    %s / %s / '%s' / '%s'\n\n" % \
                        ('fail', pri, feature, criteria))

                for dev in verdict_to_features[dtype][pri]['fail'][feature]['devices']:
                    matches = verdict_to_features[dtype][pri]['fail'][feature]['devices'][dev]
                    f.write("        (matches: %d) %-17s %s\n" % \
                            (matches, dev, dev + os.sep + dev + '.audit'))

    return

def write_governance_scores_per_device(dev_types, dev_details, audit_results, stats,
        gcharts_lines, f, cl):

    f.write("\n--- COMPLIANCE SCORE PER DEVICE ---\n\n")
    f.write("%-16s %-13s %-10s %s\n\n" % \
        ('Device:', 'Score:', 'Delta:', 'Type:'))

    for dev in sorted(stats['scores'], key=stats['scores'].get):
        if dev not in audit_results:
            continue
        if dev not in dev_types:
            continue

        score       = "%.2f / 100" % stats['scores'][dev]
        delta_score = val_delta_str(stats['scores'][dev],
                stats['orig_scores'][dev])

        f.write("%-16s %-13s %-10s %s\n" % (dev, score,
            delta_score, dev_types[dev]))

    f.write("\n")

    return

def write_avg_devtype_governance_scores(dev_types, dev_details, audit_results,
        stats, prev_score_stats, gcharts_lines, f, stats_file, db_run_id,
        conf, cl):

    gcharts_avg_devtype_scores = []

    f.write("\n--- AVERAGE DEVICE TYPE COMPLIANCE SCORES ---\n\n")
    f.write("%-12s %-9s %s\n" % ('Type:', 'Devices:',
        '[Average Score]:'))

    if cl.google_charts:
        gcharts_avg_devtype_scores.append([
            'Device Type',
            'Average Assessment Weighted Score',
            '&Delta;',
            'Number of Devices',
        ])

    avgs = {}
    dev_ctrs = {}
    overall_score = 0
    overall_dev_ctr = 0
    for dev in dev_types:
        if dev not in audit_results:
            continue
        if dev_types[dev] in dev_ctrs:
            dev_ctrs[dev_types[dev]] += 1
        else:
            dev_ctrs[dev_types[dev]] = 1
        overall_dev_ctr += 1
        overall_score   += stats['scores'][dev]

        if dev_types[dev] not in avgs:
            avgs[dev_types[dev]] = []
        avgs[dev_types[dev]].append(stats['scores'][dev])

    overall_avg = overall_score / overall_dev_ctr

    if cl.db_audit:
        ### set the average score for this run
        db_query("UPDATE govRuns SET avgScore = %s WHERE runId = %s" \
                % ("%.2f" % overall_avg, db_run_id), conf, cl)

    stats_fh = open(stats_file, 'a')

    for dtype in sorted(avgs):

        avg_score = round(sum(avgs[dtype]) / float(len(avgs[dtype])), 2)

        avg_score_delta = summary_score_delta(avg_score, dtype,
                prev_score_stats)

        stat_str = "%-12s %-9s %-12s %-10s" % \
                (dtype, str(dev_ctrs[dtype]),
                ("%.2f / 100" % avg_score), avg_score_delta)

        f.write("%s\n" % stat_str)

        ov_dev_type = dtype
        if ov_dev_type == 'WController':
            ov_dev_type = 'Wireless Controller' ### for OneView

        stats_fh.write("%s, %s, %s|%s|%.2f\n" % (str(datetime.now())[0:-7],
                int(time.time()), 'DeviceTypeAvgScore', dtype, avg_score))

        if cl.google_charts:
            gcharts_avg_devtype_scores.append([
                ov_dev_type,
                avg_score,
                colorize_delta(avg_score_delta, True),
                str(dev_ctrs[dtype]),
            ])
            gcharts_pie_data = []
            gcharts_pie_data.append([
                'Device Type',
                'Average Score'
            ])
            gcharts_pie_data.append([
                'pass',
                avg_score,
            ])
            gcharts_pie_data.append([
                'fail',
                100 - avg_score,
            ])
            gcharts_pie(gcharts_pie_data, '%s Average Score' % dtype,
                    'pie_%s_avg_score' % dtype, gcharts_lines, cl)

    stats_fh.close()

    if cl.google_charts:
        gcharts_table(gcharts_avg_devtype_scores,
                'tbl_avg_devtype_scores', gcharts_lines, cl)

    f.write("\n")

    ### generate time-series area charts in OneView
    ov_area_avg_charts(stats_file, gcharts_lines, cl)

    return avgs

def ov_area_avg_charts(stats_file, gcharts_lines, cl):

    daily_dev_type_avg_score = {}

    import_field_from_stats_file('DeviceTypeAvgScore',
            daily_dev_type_avg_score, 0, stats_file)

    ### generate OneView 'areachart' graphs
    num_graphs = len(daily_dev_type_avg_score)
    if num_graphs > 5:
        num_graphs = 5

    i = 0
    for dtype in ['WController', 'EXOS', 'EOS']:
        if dtype not in daily_dev_type_avg_score:
            continue

        ov_dtype = dtype
        if ov_dtype == 'WController':
            ov_dtype = 'Wireless'

        if i == num_graphs - 1:
            break
        i += 1

    if cl.google_charts:
        gcharts_line_data = []

        complete_avg_score_data = {}

        import_field_from_stats_file('DeviceTypeAvgScore',
                complete_avg_score_data, 0, stats_file)

        ### build up the multi-line data rows
        row = ['Date']
        for dtype in complete_avg_score_data:
            row.append(dtype)
        gcharts_line_data.append(row)

        timeslices = {}
        for dtype in complete_avg_score_data:
            for ts in complete_avg_score_data[dtype]:
                if ts not in timeslices:
                    timeslices[ts] = {}
                timeslices[ts][dtype] = float(complete_avg_score_data[dtype][ts])

        for ts in sorted(timeslices):
            row = [time.strftime('%m-%d-%Y', time.localtime(float(ts)))]
            for dtype in timeslices[ts]:
                row.append(timeslices[ts][dtype])
            gcharts_line_data.append(row)

        gcharts_line(gcharts_line_data, 'Device Type Average Scores Over Time',
                'line_OS_avg_scores', gcharts_lines, cl)

    return

def import_field_from_stats_file(field, data, num_days, stats_file):

    cutoff_timestamp = 0

    ### add in the data from the stats file read in reverse so we get the
    ### latest data for each day (for each field value, only one data point
    ### is allowed per day).
    for line in reversed(open(stats_file).readlines()):

        ### 2016-06-29 15:35:18, 1467228918, DeviceTypeAvgScore|WController|68.42
        m = re.search('^(\S+)\s\S+,\s(\d+),\s%s\|(\S+?)\|(\S+)' % field,
                line.rstrip())
        if m:
            day            = m.group(1)
            timestamp      = m.group(2)
            field_type_val = m.group(3)
            field_val      = m.group(4)

            ### calculate the cutoff timestamp as the number of allowable
            ### days previous to the first timestamp we see
            if num_days:
                if not cutoff_timestamp:
                    cutoff_timestamp = int(timestamp) - (int(num_days) * 60 * 60 * 24)

                if int(timestamp) < int(cutoff_timestamp):
                    break

            if field_type_val not in data:
                data[field_type_val] = {}
            data[field_type_val][timestamp] = field_val

    return

def write_average_pass_rates(dev_types, audit_results,
        stats, prev_summary_stats, gcharts_lines, f, cl):

    gcharts_avg_pass_rates = []

    f.write("\n--- AVERAGE DEVICE TYPE PASS RATES ---\n\n")
    f.write("%-12s %-9s %s\n" % ('Type:', 'Devices:',
        '[Average Pass Rates]:'))
    f.write("%-12s %-9s %-8s %-10s %-8s %-10s %-8s %-10s %-8s %-10s\n" % ('', '',
        'High:', '[Delta]', 'Medium:', '[Delta]', 'Low:',
        '[Delta]', 'Overall:', '[Delta]'))

    if cl.google_charts:
        gcharts_avg_pass_rates.append([
            'Device Type',
            'Number of Devices',
            'High',
            '&Delta;',
            'Medium',
            '&Delta;',
            'Low',
            '&Delta;',
            'Overall',
            '&Delta;'
        ])

    avgs = {}
    dev_ctrs = {}
    for dev in dev_types:
        if dev not in audit_results:
            continue
        if dev_types[dev] in dev_ctrs:
            dev_ctrs[dev_types[dev]] += 1
        else:
            dev_ctrs[dev_types[dev]] = 1
        if dev_types[dev] not in avgs:
            avgs[dev_types[dev]] = {}
        for pri in ['High', 'Medium', 'Low', 'Overall']:
            if pri not in avgs[dev_types[dev]]:
                avgs[dev_types[dev]][pri] = []
            if dev in stats['prcnts']:
                avgs[dev_types[dev]][pri].append(stats['prcnts'][dev][pri])

    for dtype in avgs:

        hp = mp = lp = op = 0
        if float(len(avgs[dtype]['High'])) > 0:
            hp = round(sum(avgs[dtype]['High']) / float(len(avgs[dtype]['High'])), 2)

        if float(len(avgs[dtype]['Medium'])) > 0:
            mp = round(sum(avgs[dtype]['Medium']) / float(len(avgs[dtype]['Medium'])), 2)

        if float(len(avgs[dtype]['Low'])) > 0:
            lp = round(sum(avgs[dtype]['Low']) / float(len(avgs[dtype]['Low'])), 2)

        if float(len(avgs[dtype]['Overall'])) > 0:
            op = round(sum(avgs[dtype]['Overall']) / float(len(avgs[dtype]['Overall'])), 2)

        hdelta, mdelta, ldelta, odelta = summary_stats_delta(hp,
                mp, lp, op, dtype, prev_summary_stats)

        stat_str = "%-12s %-9s %-8s %-10s %-8s %-10s %-8s %-10s %-8s %-10s" % \
                (dtype, str(dev_ctrs[dtype]),
                ("%.2f%%" % hp), hdelta,
                ("%.2f%%" % mp), mdelta,
                ("%.2f%%" % lp), ldelta,
                ("%.2f%%" % op), odelta)

        f.write("%s\n" % stat_str)

        ov_dev_type = dtype
        if ov_dev_type == 'WController':
            ov_dev_type = 'Wireless Controller' ### for OneView

        if cl.google_charts:
            gcharts_avg_pass_rates.append([
                ov_dev_type,
                str(dev_ctrs[dtype]),
                "%.2f%%" % hp,
                colorize_delta(hdelta, True),
                "%.2f%%" % mp,
                colorize_delta(mdelta, True),
                "%.2f%%" % lp,
                colorize_delta(ldelta, True),
                "%.2f%%" % op,
                colorize_delta(odelta, True),
            ])

    if cl.google_charts:
        gcharts_table(gcharts_avg_pass_rates,
                'tbl_avg_pass_rates', gcharts_lines, cl)

    f.write("\n")

    return dev_ctrs

def dev_score(verdicts, score_weights):

    score = 0
    tot_weight = 0
    for pri in score_weights:
        pass_ctr = 0
        fail_ctr = 0
        if pri not in verdicts:
            continue

        for result in verdicts[pri]:
            if not result:
                continue
            if result['verdict'] == 'pass':
                pass_ctr += 1
            elif result['verdict'] == 'fail':
                fail_ctr += 1

        prcnt = 1
        if pass_ctr > 0 or fail_ctr > 0:
            prcnt = float(pass_ctr) / float(pass_ctr + fail_ctr)

            score += score_weights[pri] * prcnt
            tot_weight += score_weights[pri]

    if tot_weight > 0:
        score = score / tot_weight * 100

    return score

def gauge_health(dev, dev_results, audit_tests, stats, audit_file,
        stats_file, verdicts, score_weights, gcharts_lines, db_run_id,
        conf, cl):

    prcnts      = {}
    counts      = {}
    orig_prcnts = {}
    orig_counts = {}
    orig_score  = 0

    tot_nodes = 0
    pass_ctr  = 0
    score     = 0

    if cl.db_audit:
        regime_id = db_get_regime_id(conf, cl)
        ### map the runId to this device
        db_map_run_id_to_dev(db_run_id, dev, conf, cl)

    ### if the .audit file already exists, then extract the previous results
    if os.path.exists(audit_file):
        with open(audit_file, 'r') as f:
            for line in f:
                for pri in ['High', 'Medium', 'Low', 'Overall']:
                    m = re.search('^' + pri + \
                            '\s+(\d+\/\d+\/\d+\/\d+)\s+(\d{1,3}\.\d{2})\%', line)
                    if m:
                        orig_counts[pri] = m.group(1)
                        orig_prcnts[pri] = round(float(m.group(2)), 2)
                        break
                m = re.search('^Score\:\s(\d\S+)\s/\s100', line)
                if m:
                    orig_score = float(m.group(1))

    stats_fh = open(stats_file, 'a')

    ### rewrite the .audit file with the current results
    with open(audit_file, 'w') as f:

        f.write("\nDevice:     %s\nType:       %s\n" % \
                (dev, dev_results['types'][dev]))

        dev_details = ' '
        if dev in dev_results['details'] \
                and dev_results['details'][dev]:
            dev_details = dev_results['details'][dev]
            f.write("Details:    %s\n" % dev_results['details'][dev])
        f.write("ConfigFile: %s\n\n" % dev_results['running_configs'][dev])

        score = dev_score(verdicts, score_weights)

        if cl.db_audit:
            tot_tests = 0
            dev_id = db_get_dev_id(dev, conf, cl)
            for pri in ['High', 'Medium', 'Low']:
                if pri in verdicts:
                    tot_tests += len(verdicts[pri])
                    for result in verdicts[pri]:
                        if not result:
                            continue
                        db_add_dev_result(result, dev_id, db_run_id, conf, cl)

            ### update the govDeviceResults table for each test, and set
            ### the score in the govDeviceScores table. We always add new
            ### scores to keep the old ones around
            db_add_dev_score(tot_tests, dev_id, regime_id,
                    score, db_run_id, conf, cl)

        stats_fh.write("%s, %s, %s|%s|%.2f\n" % (str(datetime.now())[0:-7],
                int(time.time()), 'DeviceWeightedScore', dev, score))

        if cl.google_charts:
            gcharts_summary_rows = []
            gcharts_summary_rows.append([
                'Device IP/Host',
                'Type',
                'Details',
                'Assessment Weighted Score',
                '&Delta;',
                'ConfigFile',
            ])
            config_link = 'NA'
            if dev_results['running_configs'][dev]:
                if dev_results['running_configs'][dev] == '<XML_log_data>':
                    config_link = '&lt;XML_log_data&gt;'
                else:
                    config_link = '<a href="../../../%s">%s</a>' % \
                            (dev_results['running_configs'][dev],
                            dev_results['running_configs'][dev])
            gcharts_summary_rows.append([
                dev,
                dev_results['types'][dev],
                dev_details,
                "%.2f" % score,
                colorize_delta(val_delta_str(score, orig_score), True),
                config_link,
            ])
            gcharts_table(gcharts_summary_rows, 'tbl_dev_summary',
                    gcharts_lines, cl)

            gcharts_pie_data = []
            gcharts_pie_data.append([
                'Device',
                'Assessment Weighted Score'
            ])
            gcharts_pie_data.append([
                'pass',
                score,
            ])
            gcharts_pie_data.append([
                'fail',
                100 - score,
            ])
            gcharts_pie(gcharts_pie_data, '%s Assessment Weighted Score' % dev,
                    'pie_dev_score', gcharts_lines, cl)

        f.write("Score: %.2f / 100\n\n" % score)

        write_prevmetrics_legend(f)

        f.write("%-10s %-12s %-7s %-23s %s\n" % ('Priority:', 'P/F/T/A:',
            'Pass:', 'PrevMetrics:', 'Delta:'))

        gcharts_dev_pass_fail   = []
        gcharts_dev_audit_tests = []
        if cl.google_charts:
            gcharts_dev_pass_fail.append([
                'Priority',
                'Pass',
                'Fail',
                'Total',
                'Applicable',
                'Pass %',
                '&Delta;',
            ])
            gcharts_dev_audit_tests.append([
                'Verdict',
                'Priority',
                'Matches',
                'Audit Test',
                'Guidance',
            ])

        tot_applicable = 0
        for pri in ['High', 'Medium', 'Low']:
            if pri not in verdicts:
                continue
            pri_ctr = 0
            tot_nodes += len(verdicts[pri])
            pri_tot = len(verdicts[pri])

            pri_applicable = applicable_tests(pri,
                    dev_results['types'][dev], audit_tests)
            tot_applicable += pri_applicable

            for result in verdicts[pri]:
                if not result:
                    continue
                line = result['line']
                if result['verdict'] == 'pass':
                    pass_ctr += 1
                    pri_ctr += 1 ### FIXME, should this not be indented here?

                if cl.google_charts:
                    m = re.search('(\w{4})\s+(\w+)\s+(\d+)\s+(\S.*?)\s\-\-\s+(\S.*)', line)
                    if m:
                        gcharts_dev_audit_tests.append([
                            colorize_verdict(m.group(1)),
                            m.group(2),
                            m.group(3),
                            '<a href="../%s/%s/%s_google_charts.html">%s</a>' % \
                                    (cl.tests_dir, dev_results['types'][dev],
                                    re.sub(r'\W','', m.group(4)),
                                    m.group(4).replace("'", '')),
                            m.group(5).replace("'", ''),
                        ])

            prcnt = 0
            if pri_tot > 0:
                prcnt = float(pri_ctr) / float(pri_tot) * 100
            pass_fail_str = "%d/%d/%d/%d" % \
                    (pri_ctr, (pri_tot-pri_ctr), pri_tot, pri_applicable)
            prcnt_str = "%.2f%%" % prcnt

            prev_str, delta_str = stats_delta(pri, prcnt,
                    orig_prcnts, orig_counts)

            line = "%-10s %-12s %-7s %-23s %s" % \
                    (pri, pass_fail_str, prcnt_str, prev_str, delta_str)

            f.write("%s\n" % line)

            prcnts[pri] = prcnt
            counts[pri] = pass_fail_str

            if dev not in stats[pri]:
                stats[pri][dev] = {}
            stats[pri][dev]['pass']       = pri_ctr
            stats[pri][dev]['fail']       = pri_tot-pri_ctr
            stats[pri][dev]['total']      = pri_tot
            stats[pri][dev]['applicable'] = pri_applicable

            cdate = str(datetime.now())[0:-7]
            ctime = int(time.time())

            stats_fh.write("%s, %s, Priority%sPass|%s|%d\n" % (cdate, ctime, pri, dev, pri_ctr))
            stats_fh.write("%s, %s, Priority%sFail|%s|%d\n" % (cdate, ctime, pri, dev, pri_tot-pri_ctr))
            stats_fh.write("%s, %s, Priority%sTot|%s|%d\n" % (cdate, ctime, pri, dev, pri_tot))
            stats_fh.write("%s, %s, Priority%sApplicable|%s|%d\n" % (cdate, ctime, pri, dev, pri_applicable))

            if cl.google_charts:
                gcharts_dev_pass_fail.append([
                    pri,
                    '<font color="green">' + str(pri_ctr) + '</font>',
                    '<font color="red">' + str(pri_tot-pri_ctr) + '</font>',
                    pri_tot,
                    pri_applicable,
                    prcnt_str,
                    colorize_delta(delta_str, True),
                ])

        stats_fh.close()

        ### build up the multi-line data rows
        gcharts_line_data = []
        row = ['Date']
        for field in ['DeviceWeightedScore', 'PriorityHighPass',
                'PriorityHighFail', 'PriorityMediumPass',
                'PriorityMediumFail', 'PriorityLowPass',
                'PriorityLowFail']:
            row.append(field)
        gcharts_line_data.append(row)

        timeslices = {}
        for field in ['DeviceWeightedScore', 'PriorityHighPass',
                'PriorityHighFail', 'PriorityMediumPass',
                'PriorityMediumFail', 'PriorityLowPass',
                'PriorityLowFail']:

            data = {}
            import_field_from_stats_file(field, data, 0, stats_file)

            for f_type in data:
                for ts in data[f_type]:
                    if ts not in timeslices:
                        timeslices[ts] = {}
                    timeslices[ts][field] = float(data[f_type][ts])

        for ts in sorted(timeslices):
            row = [time.strftime('%m-%d-%Y', time.localtime(float(ts)))]
            valid_row = True
            for field in ['DeviceWeightedScore', 'PriorityHighPass',
                    'PriorityHighFail', 'PriorityMediumPass',
                    'PriorityMediumFail', 'PriorityLowPass',
                    'PriorityLowFail']:
                if field not in timeslices[ts]:
                    valid_row = False
                    break
                row.append(timeslices[ts][field])
            if valid_row:
                gcharts_line_data.append(row)

        gcharts_line(gcharts_line_data, 'Device Scores Over Time',
                'line_dev_scores', gcharts_lines, cl)
        gcharts_table(gcharts_dev_pass_fail,
                'tbl_dev_pass_fail', gcharts_lines, cl)
        gcharts_table(gcharts_dev_audit_tests,
                'tbl_dev_audit_tests', gcharts_lines, cl)

        prcnt = 0
        if tot_nodes > 0:
            prcnt = round(float(pass_ctr) / float(tot_nodes) * 100, 2)
        prcnt_str = "%.2f%%" % prcnt
        pass_fail_str = "%d/%d/%d/%d" % \
                (pass_ctr, (tot_nodes-pass_ctr),
                        tot_nodes, tot_applicable)

        prev_str, delta_str = stats_delta('Overall', prcnt,
                orig_prcnts, orig_counts)

        line = "%-10s %-12s %-7s %-23s %s" % \
                ('Overall', pass_fail_str, prcnt_str, prev_str, delta_str)

        f.write("%s\n\n" % line)

        prcnts['Overall'] = prcnt
        counts['Overall'] = pass_fail_str

    stats['prcnts'][dev] = prcnts
    stats['counts'][dev] = counts
    stats['scores'][dev] = score
    stats['orig_prcnts'][dev] = orig_prcnts
    stats['orig_counts'][dev] = orig_counts
    stats['orig_scores'][dev] = orig_score

    return

def colorize_verdict(verdict):
    color = 'green'
    if verdict == 'fail':
        color = 'red'

    return '<font color="' + color + '">' + verdict + '</font>'

def colorize_delta(val, pos_flag):
    color    = 'green'
    add_plus = '+'

    raw_delta = val
    m = re.search('(-?\d+\.\d+)', val)
    if m:
        raw_delta = float(m.group(1))
        if raw_delta == 0:
            raw_delta = int(raw_delta)
    else:
        m = re.search('(-?\d+)', val)
        if m:
            raw_delta = int(m.group(1))

    if pos_flag:
        if raw_delta < 0:
            color = 'red'
    else:
        if raw_delta > 0:
            color = 'red'
    if raw_delta < 0:
        add_plus = ''

    return '<font color="' + color + '">%s' % (add_plus) + str(raw_delta) + '</font>'

def summary_score_delta(avg_score, dtype, prev_score_stats):
    sdelta = '[0]'
    if prev_score_stats and dtype in prev_score_stats:
        if float(avg_score) != float(prev_score_stats[dtype]):
            sdelta = val_delta_str(avg_score, prev_score_stats[dtype])
    return sdelta

def summary_stats_delta(hp, mp, lp, op, dtype, prev_summary_stats):

    hdelta = mdelta = ldelta = odelta = '[0]'

    if prev_summary_stats and dtype in prev_summary_stats:
        if float(hp) != float(prev_summary_stats[dtype]['High']):
            hdelta = prcnt_delta_str(hp, prev_summary_stats[dtype]['High'])

        if float(mp) != float(prev_summary_stats[dtype]['Medium']):
            mdelta = prcnt_delta_str(mp, prev_summary_stats[dtype]['Medium'])

        if float(lp) != float(prev_summary_stats[dtype]['Low']):
            ldelta = prcnt_delta_str(lp, prev_summary_stats[dtype]['Low'])

        if float(op) != float(prev_summary_stats[dtype]['Overall']):
            odelta = prcnt_delta_str(op, prev_summary_stats[dtype]['Overall'])

    return hdelta, mdelta, ldelta, odelta

def count_delta_str(new, old):
    delta = new - old
    delta_str = str(delta)
    if delta > 0:
        delta_str = '+' + delta_str
    return delta_str

def prcnt_delta_str(new, old):
    delta_prcnt = float(new) - float(old)
    delta_str = "[%.2f%%]" % delta_prcnt
    if delta_prcnt > 0:
        delta_str = "[+%.2f%%]" % delta_prcnt
    elif delta_prcnt == 0:
        delta_str = "[%.2f%%]" % delta_prcnt
    return delta_str

def val_delta_str(new, old):

    delta_val = float(new) - float(old)

    delta_str = "[%.2f]" % delta_val

    if delta_val > 0:
        delta_str = "[+%.2f]" % delta_val
    elif delta_val == 0:
        delta_str = '[0]'

    return delta_str

def stats_delta(pri, prcnt, orig_prcnts, orig_counts):
    prev_str  = '[0]'
    delta_str = '[0]'

    tprcnt = round(prcnt, 2)
    if orig_prcnts and pri in orig_prcnts:
        if float(orig_prcnts[pri]) == float(tprcnt):
            prev_str = '[0]'
        else:
            if orig_counts and pri in orig_counts:
                prev_str = "%s [%s%%]" % (orig_counts[pri],
                        orig_prcnts[pri])
            else:
                prev_str = "[0] [%s%%]" % orig_prcnts[pri]
            delta_str = prcnt_delta_str(prcnt, orig_prcnts[pri])

    return prev_str, delta_str

def applicable_tests(pri, dtype, audit_tests):
    ctr = 0
    for node in audit_tests['nodes']:
        if dtype.lower() not in node['meta']['type'].lower():
            continue
        if pri == node['WEIGHT']:
            ctr += 1
    return ctr

def audit_devs(audit_tests, dev_results, unknown_devices, verdict_to_features, repo_dir, log_lines,
        xml_log_data, regime, db_run_id, netsight_job, score_weights, conf, cl):

    audit_results = {}
    audit_tests_to_dtype = {}

    ### calculate how many tests we're going to run so we can print the
    ### percent complete status
    total_tests, total_devs = total_tests_to_run(dev_results, repo_dir,
            audit_tests, audit_tests_to_dtype, netsight_job, cl)

    print "[+] Will execute a total of %s audit tests against %s devices." \
            % (total_tests, total_devs)
    
    executed_tests = 0
    passed_tests   = 0
    failed_tests   = 0

    if total_tests == 0:
        
        if len(unknown_devices) and total_devs==0:
            err_str="Selected Devices could not be fingerprinted thus No applicable tests."
        elif len(unknown_devices) :
            #Mixture of devices with no applicable tests andunknow device type
            err_str="Selected devices could either not be fingerprinted or no applicable tests exists"
        else :
            err_str = "Zero applicable tests for the selected devices."
        if cl.db_audit:
            print_job_error(err_str, db_run_id, cl)
            sys.exit(0)
        else:
            raise NameError(err_str)

    ### now run the tests
    if cl.db_audit:
        print_job_status(executed_tests, passed_tests, \
            failed_tests, total_tests, db_run_id, cl)
        #print all the devices that couldn't be fingerprinted. The message format is parsed and added GovernanceOperations in the Governance job file
        display_str="Cannot Fingerprint Device."
        for unknown_device in unknown_devices :
            print "###%d###  &%s - %s&  @%s@  %%%.2f%%  !%s!  $%s$" % (db_run_id, \
                cl.governance_type, " ",unknown_device, 100.0, " ", display_str)

    for dev in dev_results['types']:

        if cl.job_file:
            if not job_file_dev_match(dev, netsight_job):
                continue
 
        dtype = dev_results['types'][dev]
                   
        if dev not in dev_results['running_configs']:
            continue

        dev_details = None
        if dev in dev_results['details']:
            dev_details = dev_results['details'][dev]

        dev_parsed = None
        if dev in dev_results['parsed']:
            dev_parsed = dev_results['parsed'][dev]

        if dtype not in verdict_to_features:
            verdict_to_features[dtype] = {}
        
        default_cf_file = None
        if cl.db_audit:
            cf_file = os.path.abspath(repo_dir + os.sep + dev_results['running_configs'][dev])
            if 'default_configs' in dev_results and dev in dev_results['default_configs']:
                default_cf_file = os.path.abspath(repo_dir + os.sep + dev_results['default_configs'][dev])
        else:
            if cl.audit_file:
                cf_file = cl.audit_file
            elif cl.audit_dir:
                cf_file = dev_results['running_configs'][dev]
                if 'default_configs' in dev_results and dev in dev_results['default_configs']:
                    default_cf_file = dev_results['default_configs'][dev]
            else:
                cf_file = os.path.abspath(repo_dir + os.sep + dev_results['running_configs'][dev])
                if 'default_configs' in dev_results and dev in dev_results['default_configs']:
                    default_cf_file = os.path.abspath(repo_dir + os.sep + dev_results['default_configs'][dev]) 

        print "[+] Auditing %s device: %s (running config file: %s) (default config file: %s)" % \
                (dtype, dev, cf_file, default_cf_file)

        if cl.db_audit:
            dev_id = db_add_device(dtype, dev, conf, cl)

        ### test the configuration against every feature audit node
        verdicts = {'High':[], 'Medium':[], 'Low':[]}

        lines = []
        default_cf_lines = []
        match_line_offset = 0

        if 'log' not in cf_file: ### FIXME, need a better test than this
            if cl.db_audit:
                ### make sure this file is in the govDeviceToConfigs table
                db_add_dev_config(dev_id, cf_file, conf, cl)

        if os.path.exists(cf_file):
            with open(cf_file) as f:
                lines = f.read().splitlines()
        
        if default_cf_file is not None and os.path.exists(default_cf_file):
            with open(default_cf_file) as f:
                default_cf_lines = f.read().splitlines()

        print_status = True
        dev_exec_tests = 0
        dev_tot_tests  = 0
        
        ### see how many tests we're going to run for this device
        dev_tot_tests = tally_dev_tests(audit_tests, audit_tests_to_dtype, dev, dtype, dev_details,
                lines, default_cf_lines, netsight_job, cl)
        
        if cl.db_audit:
            
            if dev_tot_tests == 0:
                msg_string = "No audit tests found for the device."
                print "###%d###  &%s - %s&  @%s@  %%%.2f%%  !%s!  $%s$" % (db_run_id, \
                    cl.governance_type, " ", dev, 100.0, " ", msg_string)
                continue

        for node in audit_tests_to_dtype[dtype]:

            parse_lines = lines
            if parse_log_data(node):
                parse_lines = log_lines

            if not initial_checks(node, dev, dev_details, parse_lines, default_cf_lines, netsight_job, cl):
                continue

            if cl.verbose:
                print "    Running test: '%s'" % node['BEGIN_NODE']

            executed_tests += 1
            dev_exec_tests += 1

            if (print_status and (int((float(executed_tests) / float(total_tests) * 100)) % 25) < 10):
                print "[+] Executed %s / %s tests (%%%.2f%% complete)..." % (executed_tests, \
                    total_tests, (float(executed_tests) / float(total_tests) * 100))
                print_status = False

                if cl.db_audit:
                    print_job_status(executed_tests, passed_tests,
                            failed_tests, total_tests, db_run_id, cl)

            is_pass, result, prev_re_match_objs = match_required_tests(node,
                    dev, audit_tests_to_dtype[dtype], verdict_to_features[dtype],
                    parse_lines, default_cf_lines, regime, cl, dtype.lower())
                
            if 'REGEX_GROUP_ANCHOR' in node \
                    and node['REGEX_GROUP_ANCHOR'] == 'true':
                verdicts[node['WEIGHT']].append(result)
                if 'verdict' in result:
                    if result['verdict'] == 'pass':
                        if cl.verbose:
                            print "...pass"
                        passed_tests += 1
                    else:
                        if cl.verbose:
                            print "...fail"
                        failed_tests += 1
                    logger.send_syslog_msg("audit test: %s, status: %s, device: %s, device type: %s, file: %s" % (node['BEGIN_NODE'], result['verdict'], dev, dtype, cf_file), cl, node, result['verdict'])
                continue

            if not is_pass:
                continue

            if 'REGEX' in node and node['REGEX']:
                result, matches, match_lines, re_match_objs = \
                        regex_audit(match_line_offset, dev, node,
                            verdict_to_features[dtype], parse_lines,
                            prev_re_match_objs, regime, cl)
                if result:
                    if result['verdict'] != 'pass' and 'CHECK_DEFAULT_CONFIG_FILE' in node and node['CHECK_DEFAULT_CONFIG_FILE'] == 'true':
                        result, matches, match_lines, re_match_objs = \
                        regex_audit(0, dev, node,
                            verdict_to_features[dtype], default_cf_lines,
                            prev_re_match_objs, regime, cl)
                    
                    if result:
                        verdicts[node['WEIGHT']].append(result)
                        if result['verdict'] == 'pass':
                            if cl.verbose:
                                print "...pass"
                            passed_tests += 1
                        else:
                            if cl.verbose:
                                print "...fail"
                            failed_tests += 1
                        logger.send_syslog_msg("audit test: %s, status: %s, device: %s, device type: %s, file: %s" % (node['BEGIN_NODE'], result['verdict'], dev, dtype, cf_file), cl, node, result['verdict'])
                        if cl.db_audit:
                            print_dev_status(dev_exec_tests, dev_tot_tests,
                                    dev, result, node, db_run_id, cl)

            elif 'TEST_FUNCTION' in node and node['TEST_FUNCTION']:
                ### function-based test
                result = function_audit(dev, node,
                            verdict_to_features[dtype],
                            parse_lines, dev_parsed, xml_log_data,
                            regime, cl)
                
                if result:
                    if result['verdict'] != 'pass' and 'CHECK_DEFAULT_CONFIG_FILE' in node and node['CHECK_DEFAULT_CONFIG_FILE'] == 'true':
                        result = function_audit(dev, node,
                            verdict_to_features[dtype],
                            default_cf_lines, dev_parsed, xml_log_data,
                            regime, cl)
                
                if result:
                    verdicts[node['WEIGHT']].append(result)
                    if result['verdict'] == 'pass':
                        if cl.verbose:
                            print "...pass"
                        passed_tests += 1
                    else:
                        if cl.verbose:
                            print "...fail"
                        failed_tests += 1
                    logger.send_syslog_msg("audit test: %s, status: %s, device: %s, device type: %s, file: %s" % (node['BEGIN_NODE'], result['verdict'], dev, dtype, cf_file), cl, node, result['verdict'])
                    if cl.db_audit:
                        print_dev_status(dev_exec_tests, dev_tot_tests,
                                dev, result, node, db_run_id, cl)

            elif 'TEST_FUNCTION_MULTIVERDICT' in node and node['TEST_FUNCTION_MULTIVERDICT']:
                ### multi-line function test
                passed, failed = function_audit_multiverdict(dev, dtype, verdicts, node,
                        verdict_to_features[dtype], parse_lines,
                        dev_parsed, xml_log_data, regime, dev_exec_tests,
                        dev_tot_tests, db_run_id, cf_file, cl)
                passed_tests += passed
                failed_tests += failed

        audit_results[dev] = verdicts
        score = dev_score(verdicts, score_weights)
        print_dev_score(dev_exec_tests, dev_tot_tests, score, dev, dtype, db_run_id, cl)

    print "[+] Executed %s / %s tests (%%%.2f%% complete)..." % (executed_tests, \
        total_tests, (float(executed_tests) / float(total_tests) * 100))

    if cl.db_audit:
        print_job_status(executed_tests, passed_tests,
                failed_tests, total_tests, db_run_id, cl)

    if not passed_tests and not failed_tests:
        return {}

    return audit_results

def tally_dev_tests(audit_tests, audit_tests_to_dtype, dev, dtype, dev_details, lines, default_cf_file_lines, netsight_job, cl):

    tests = 0
    dev_audit_tests = []
    #if audit_tests_to_dtype.has_key(dtype):
    for node in audit_tests_to_dtype[dtype]:
            
        parse_lines = lines
        if parse_log_data(node):
            parse_lines = log_lines
                
        if not initial_checks(node, dev, dev_details, parse_lines, default_cf_file_lines, netsight_job, cl):
            continue
            
        tests += 1
        
    return tests

def print_job_error(err_str, db_run_id, cl):
    ### ---<job#>---  !<error string>!
    sys.stderr.write("---%d--- !%s!\n" % (db_run_id, err_str))
    return

def print_job_status(exec_tests, passed_tests, failed_tests, tot_tests, db_run_id, cl):
    ### ***<job#>***    %<overall progress percentage>%     !<overall status --- In progress / Success / Failure>!
    print "***%d***  %%%.2f%%  !%s: Passed: %s / Failed: %s!" % (db_run_id,
            (float(exec_tests) / float(tot_tests) * 100), cl.governance_type, passed_tests,
            failed_tests)
    return

def print_dev_status(dev_exec_tests, dev_tot_tests, dev, result, node, db_run_id, cl):
    ### for NetSight operations panel
    ### ###<job#>###    &<audit test name>&  @<device ip>@   %<progress percentage>%    !<specific status --- 'Success / Failure'>!  $<Details Message>$
    details = 'NA'
    if 'db_details' in result and result['db_details']:
        details = result['db_details']
    print "###%d###  &%s - %s&  @%s@  %%%.2f%%  !%s!  $%s$" % (db_run_id,
            cl.governance_type, node['BEGIN_NODE'], dev,
            (float(dev_exec_tests) / float(dev_tot_tests) * 100),
            result['verdict'], details)
    return

def print_dev_score(dev_exec_tests, dev_tot_tests, dev_score, dev, dtype, db_run_id, c1):
    verdict = "PASS" if dev_score > 50 else "FAIL"
    print "###%d###  &%s - %s&  @%s@  %%%.2f%%  ^%.2f^  !%s!" % (db_run_id, c1.governance_type,
            dtype, dev, (float(dev_exec_tests) / float(dev_tot_tests) * 100),
            dev_score, verdict )

def total_tests_to_run(dev_results, repo_dir, audit_tests, audit_tests_to_dtype, netsight_job, cl):
    total_tests = 0
    total_devs  = 0

    for dev in dev_results['types']:

        if cl.job_file:
            if not job_file_dev_match(dev, netsight_job):
                continue
        
        dtype = dev_results['types'][dev]
        if dev not in dev_results['running_configs']:
            continue

        dev_details = None
        if dev in dev_results['details']:
            dev_details = dev_results['details'][dev]

        default_cf_file = None
        if cl.db_audit:
            cf_file = os.path.abspath(repo_dir + os.sep + dev_results['running_configs'][dev])
            if 'default_configs' in dev_results and dev in dev_results['default_configs']:
                default_cf_file = os.path.abspath(repo_dir + os.sep + dev_results['default_configs'][dev] )
        else:
            if cl.audit_file:
                cf_file = cl.audit_file
            elif cl.audit_dir:
                cf_file = dev_results['running_configs'][dev]
                if 'default_configs' in dev_results and dev in dev_results['default_configs']:
                    default_cf_file = dev_results['default_configs'][dev]
            else:
                cf_file = os.path.abspath(repo_dir + os.sep + dev_results['running_configs'][dev])
                if 'default_configs' in dev_results and dev in dev_results['default_configs']:
                    default_cf_file = os.path.abspath(repo_dir + os.sep + dev_results['default_configs'][dev] )

        lines = []
        match_line_offset = 0

        if 'log' not in cf_file and os.path.exists(cf_file): ### FIXME, need a better test than this
            with open(cf_file) as f:
                lines = f.read().splitlines()
                
        default_cf_lines = []
        if default_cf_file is not None and os.path.exists(default_cf_file):
            with open(default_cf_file) as f:
                default_cf_lines = f.read().splitlines()

        total_devs += 1
        
        dev_audit_tests = []
        for node in audit_tests['nodes']:
            
            ### See if the audit test is disabled 
            if node['IS_DISABLED'] == 'true':
                continue

            ### see if the device type matches the type expected by this test
            if dtype.lower() not in node['meta']['type'].lower():
                continue
            
            dev_audit_tests.append(node)
            parse_lines = lines
            if parse_log_data(node):
                parse_lines = log_lines

            if not initial_checks(node, dev, dev_details, parse_lines, default_cf_lines, netsight_job, cl):
                continue

            total_tests += 1
        
        audit_tests_to_dtype[dtype] = dev_audit_tests
        
    return total_tests, total_devs

def match_required_tests(node, dev, nodes,
        features, parse_lines, default_cf_lines, regime, cl, dev_type):

    is_pass     = True
    main_result = {}
    prev_re_match_objs = []

    if 'REQUIRED_TESTS' in node:
        if cl.print_regex_matches:
            print "    Start REQUIRED_TESTS matching for node: '%s'" \
                    % node['BEGIN_NODE']

        match_line_offset = 0
        prev_offset = 0

        while True:

            prev_re_match_objs = []

            if 'REGEX_GROUP_ANCHOR' in node \
                    and node['REGEX_GROUP_ANCHOR'] == 'true':

                result, matches, match_lines, re_match_objs = \
                        regex_audit(match_line_offset, dev, node, features,
                            parse_lines, prev_re_match_objs, regime, cl)

                prev_re_match_objs = re_match_objs
                
                if result and 'pass' != result['verdict']:
                    if 'CHECK_DEFAULT_CONFIG_FILE' in node and node['CHECK_DEFAULT_CONFIG_FILE'] == 'true':
                        result, matches, match_lines_ignore, re_match_objs = \
                            regex_audit(0, dev, node, features,
                                default_cf_lines, prev_re_match_objs, regime, cl)

                if 'LOOP_ALL' in node and node['LOOP_ALL'] == 'true':
                    if 'pass' != result['verdict']:
                        break
                    else:
                        if match_lines:
                            match_line_offset = match_lines[0] + prev_offset + 1
                            prev_offset = match_line_offset

                if not main_result:
                    main_result = result

            is_pass = True

            ### we must match all prerequisite tests before this audit
            ### test is allowed to proceed
            for test in node['REQUIRED_TESTS'].split(','):
                name    = test
                verdict = 'pass'
                if ':' in test:
                    name, verdict = test.split(':')

                for node in nodes:
                    if name == node['BEGIN_NODE'] and dev_type == node['meta']['type'].lower():
                        if 'REGEX' in node:

                            result, matches, match_lines_ignore, re_match_objs = \
                                    regex_audit(0, dev, node, features,
                                        parse_lines, prev_re_match_objs, regime, cl)

                            prev_re_match_objs = re_match_objs

                            if verdict != result['verdict']:
                                if 'CHECK_DEFAULT_CONFIG_FILE' in node and node['CHECK_DEFAULT_CONFIG_FILE'] == 'true':
                                    result, matches, match_lines_ignore, re_match_objs = \
                                            regex_audit(0, dev, node, features,
                                                    default_cf_lines, prev_re_match_objs, regime, cl)
                                    if verdict == result['verdict']:
                                        continue
                                is_pass = False
                                break
                if not is_pass:
                    break

            if 'MATCH_ALL' in node and \
                    node['MATCH_ALL'] == 'true':
                if not is_pass:
                    main_result['verdict'] = 'fail'
                    main_result['line']    = main_result['line'].replace('pass', 'fail')
                    break

            if 'LOOP_ALL' not in node or \
                    node['LOOP_ALL'] == 'false':
                break

    return is_pass, main_result, prev_re_match_objs

def initial_checks(node, dev, dev_details, parse_lines, default_cf_file_lines, netsight_job, cl):

    ### see if this tests is part of the netsight job
    if netsight_job:
        found = False
        for test in netsight_job['tests']:
            if test['test_title'] == node['BEGIN_NODE']:
                found = True
                break
        if not found:
            return False

    if not check_version(node, dev_details):
        if cl.verbose:
            print "[-] check_version() failed for test: '%s', against device '%s'" \
                % (node['BEGIN_NODE'], dev)
        return False

    if not check_prerequisites(node, parse_lines, cl):
        # check for prerequisite in default config file
        if 'CHECK_DEFAULT_CONFIG_FILE' in node and node['CHECK_DEFAULT_CONFIG_FILE'] == 'true':
            if check_prerequisites(node, default_cf_file_lines, cl):
                return True
        
        if cl.verbose:
            print "[-] check_prerequisites() failed for test: '%s', against device: '%s', excluding test." \
                % (node['BEGIN_NODE'], dev)
        return False

    if check_suppress_alert(node):
        if cl.verbose:
            print "[-] check_suppress_alert() failed for test: '%s' against device: '%s'" \
                % (node['BEGIN_NODE'], dev)
        return False

    if cl.test_title:
        if cl.test_title.lower() not in node['BEGIN_NODE'].lower():
            return False

    if cl.test_type:
        if cl.test_type not in node['meta']['tests_file']:
            return False

    return True

def git_paths(cl):

    repo_dir = ''
    gitstats_dir = ''

    if cl.git_repo:
        repo_dir = os.path.abspath(cl.git_repo)
    else:
        repo_dir = os.path.abspath(cl.netsight_dir + os.sep + \
            'git' + os.sep + 'governance.git')

    validate_git_dir(repo_dir)

    if cl.enable_gitstats:
        if cl.gitstats_dir:
            gitstats_dir = cl.gitstats_dir
        else:
            gitstats_dir = repo_dir + 'stats'
        if not os.path.exists(gitstats_dir):
            os.mkdir(gitstats_dir)

    return repo_dir, gitstats_dir

def test_exists(test_title, exact_match, audit_tests):
    is_found = False
    for node in audit_tests['nodes']:
        if exact_match:
            if test_title == node['BEGIN_NODE']:
                is_found = True
                break
        else:
            if test_title.lower() in node['BEGIN_NODE'].lower():
                is_found = True
                break
    if not is_found:
        raise NameError("[*] Audit test not found: '%s'" % test_title)
    return

def test_file_exists(test_file, audit_tests):
    is_found = False
    for node in audit_tests['nodes']:
        if test_file:
            if test_file in node['meta']['tests_file']:
                is_found = True
                break
    if not is_found:
        raise NameError("[*] Audit test file not found: '%s'" % test_file)
    return

def check_prerequisites(node, lines, cl):
    if 'PREREQUISITE' in node and node['PREREQUISITE']:
        matches, match_lines, re_match_objs = \
                file_regex_matches(node['BEGIN_NODE'],
                        node['PREREQUISITE'], lines, cl)
        if matches:
            if 'PREREQUISITE_MATCH' in node \
                    and node['PREREQUISITE_MATCH'] == 'false':
                return False
        else:
            if 'PREREQUISITE_MATCH' in node \
                    and node['PREREQUISITE_MATCH'] == 'true':
                return False
    return True

def check_suppress_alert(node):
    if 'SUPPRESS_ALERT' in node and node['SUPPRESS_ALERT'] == 'true':
        return True
    return False

def parse_log_data(node):
    if 'LOG_DATA' in node and node['LOG_DATA'] == 'true':
        return True
    return False

def check_version(node, dev_details):
    ### see if we need to restrict this node to a particular
    ### version/details string associated with the device
    if 'VERSION' in node and dev_details:
        if node['VERSION'] not in dev_details:
            return False
    return True

def function_audit_multiverdict(dev, dtype, verdicts, node, vmap,
        lines, dev_parsed, xml_log_data, regime, dev_exec_tests,
        dev_tot_tests, db_run_id, cf_file, cl):

    passed = 0
    failed = 0

    match_ar, parsed_details_ar = \
            node['TEST_FUNCTION_MULTIVERDICT'](node, lines,
                    dev_parsed, xml_log_data, cl)

    results = {'pass':{}, 'fail':{}}
    idx     = 0
    found_node = False
    for matches in match_ar:

        verdict = matches_result(matches, node)
        if not verdict:
            if parsed_details_ar[idx]:
                print "[-] %s: %s" % (node['BEGIN_NODE'], parsed_details_ar[idx])
            continue

        if verdict not in results:
            err_str = "verdict: '%s' not defined for node: '%s'" \
                    % (verdict, node['BEGIN_NODE'])
            if cl.db_audit:
                print_job_error(err_str, db_run_id, cl)
                sys.exit(0)
            else:
                raise NameError("[*] %s" % err_str)

        details = parsed_details_ar[idx]
        if (xml_log_data and 'XML_DATA' in node and node['XML_DATA'] == 'true' and dtype != 'XCA') \
                or ('LOG_DATA' in node and node['LOG_DATA'] == 'true'):
            ### make sure we're only including threat data for the current controller
            if re.search("Controller\:\s%s[,\s\b]" % dev, details):
                found_node = True
            else:
                continue
        if details not in results[verdict]:
            results[verdict][details] = 1
        else:
            results[verdict][details] += 1
        idx += 1

    if (xml_log_data and 'XML_DATA' in node and node['XML_DATA'] == 'true' and dtype != 'XCA') \
            or ('LOG_DATA' in node and node['LOG_DATA'] == 'true'):
        if 'TRACK_OPPOSITE_MATCH' in node and node['TRACK_OPPOSITE_MATCH'] == 'true':
            if not found_node:
                verdict = matches_result(0, node)
                details = "Controller: %s" % dev
                if verdict not in results:
                    results[verdict] = {}
                if details not in results[verdict]:
                    results[verdict][details] = 1
                else:
                    results[verdict][details] += 1

    for verdict in sorted(results):
        if verdict == 'pass':
            passed += len(results[verdict])
        elif verdict == 'fail':
            failed += len(results[verdict])
        if len(results[verdict]) > 0 and dtype.lower() != 'wing':
            logger.send_syslog_msg("audit test: %s, status: %s, device: %s, device type: %s, file: %s" % (node['BEGIN_NODE'], verdict, dev, dtype, cf_file), cl, node, verdict)
        detailsSet = set()
        for details in sorted(results[verdict], key=results[verdict].get, reverse=True):
            count = results[verdict][details]
            add_feature_verdict(dev, vmap, verdict, count, node)
            ap_name = ''
            
            if dtype.lower() == 'wing':
               detailList = details.split(" ")
               if(len(detailList) == 6):
                   ap_name = ' '.join(detailList[0:2])
                   details = ' '.join(detailList[2:])
                   policy = ' '.join(detailList[4:]) 
                   if policy not in detailsSet:
                        logger.send_syslog_msg("audit test: %s, status: %s, device: %s, %s, device type: %s, file: %s" % (node['BEGIN_NODE'], verdict, dev, policy, dtype, cf_file), cl, node, verdict)
                        detailsSet.add(policy)

            result = {'verdict':verdict,
                'weight':node['WEIGHT'],
                'matches':count,
                'test_name':node['BEGIN_NODE'],
                'line':"%-9s %-10s %-12s %s -- %s" % \
                    (verdict, node['WEIGHT'], count,
                    node['BEGIN_NODE'], details),
                'ap_name':ap_name,
                'db_details':details}

            result['auditTestId'] = 0

            if 'auditTestId' in node and node['auditTestId']:
                result['auditTestId'] = node['auditTestId']

            if regime != 'INFO':
                result['line'] += " -- %s" % node['AUDIT_CRITERIA_EXPANDED']

            verdicts[node['WEIGHT']].append(result)

            if cl.db_audit:
                print_dev_status(dev_exec_tests, dev_tot_tests,
                        dev, result, node, db_run_id, cl)

    return (passed, failed)

def function_audit(dev, node, vmap, lines, dev_parsed, xml_log_data, regime, cl):
    # DETERRAK -- added the print statement
    print("FUNCTION_AUDIT: dev=%s") % dev
    (matches, parsed_details) = \
            node['TEST_FUNCTION'](node, lines, dev_parsed,
                    xml_log_data, cl)

    verdict = matches_result(matches, node)

    if not verdict:
        if parsed_details:
            ### FIXME syslog
            print "[-] %s: %s" % (node['BEGIN_NODE'], parsed_details)
        return False

    add_feature_verdict(dev, vmap, verdict, matches, node)

    result = {'verdict':verdict,
        'weight':node['WEIGHT'],
        'matches':matches,
        'test_name':node['BEGIN_NODE'],
        'line':"%-9s %-10s %-12s %s -- %s" % \
                (verdict, node['WEIGHT'], matches,
                node['BEGIN_NODE'], parsed_details),
        'db_details':parsed_details}

    result['auditTestId'] = 0
    if 'auditTestId' in node and node['auditTestId']:
        result['auditTestId'] = node['auditTestId']

    if regime != 'INFO':
        result['line'] += " -- %s" % node['AUDIT_CRITERIA_EXPANDED']

    return result

def regex_audit(match_line_offset, dev, node, vmap,
        lines, prev_re_match_objs, regime, cl):

    for var in ['REGEX', 'ALT_REGEX', 'ALT_REGEX2', 'ALT_REGEX3']:
        if var not in node:
            break
        if not node[var]:
            break

        regex = node[var]

        ### should be more than enough
        max_groups = 20

        ### if we have previous regex match objects with associated capture
        ### groups, then see if the current node regex requires any of
        ### them to match. We substitute the previous capture group contents
        ### into '%1', '%2', ... '%n' if they exist
        required_groups = 0
        ctr = 1
        while ctr <= max_groups:
            if '%' + '%d' % ctr in regex:
                if ctr > required_groups:
                    required_groups = ctr
            ctr += 1

        ### FIXME we're only looking at the first regex object here
        if required_groups > 0 and len(prev_re_match_objs) \
                and required_groups <= len(prev_re_match_objs[0].groups())+1:

            if cl.print_regex_matches:
                print "    NODE: '%s'" % node['BEGIN_NODE']
                print "            Regex before substitutions: '%s'" % regex

            i = 1
            while (i <= required_groups):
                ### allow multiple substitutions of the same capture group
                while '%' + '%d' % i in regex:
                    regex = regex.replace('%' + "%d" % i, prev_re_match_objs[0].group(i))
                i += 1

            if cl.print_regex_matches:
                print "    NODE: '%s'" % node['BEGIN_NODE']
                print "            Regex after substitutions:  '%s'" % regex

        matches, match_lines, re_match_objs = file_regex_matches(node['BEGIN_NODE'],
                regex, lines[match_line_offset:], cl)
        verdict = matches_result(matches, node)

        if verdict == 'pass':
            break

    if not check_suppress_alert(node):
        add_feature_verdict(dev, vmap, verdict, matches, node)

    result = {'verdict':verdict,
        'weight':node['WEIGHT'],
        'matches':matches,
        'test_name':node['BEGIN_NODE'],
        'line':"%-9s %-10s %-12s %s" % \
                (verdict, node['WEIGHT'], matches,
                node['BEGIN_NODE'])}
    result['auditTestId'] = 0
    if 'auditTestId' in node and node['auditTestId']:
        result['auditTestId'] = node['auditTestId']

    if regime != 'INFO':
        result['line'] += " -- %s" % node['AUDIT_CRITERIA_EXPANDED']

    return result, matches, match_lines, re_match_objs

def add_feature_verdict(dev, vmap, verdict, matches, node):

    pri     = node['WEIGHT']
    feature = node['BEGIN_NODE']

    if node['WEIGHT'] not in vmap:
        vmap[pri] = {}

    if verdict not in vmap[pri]:
        vmap[pri][verdict] = {}

    if feature not in vmap[pri][verdict]:
        vmap[pri][verdict][feature] = {}
        vmap[pri][verdict][feature]['matches'] = 0
        vmap[pri][verdict][feature]['criteria'] = node['AUDIT_CRITERIA_EXPANDED']
        vmap[pri][verdict][feature]['devices'] = {}

    vmap[pri][verdict][feature]['matches'] += matches

    if dev in vmap[pri][verdict][feature]['devices']:
        vmap[pri][verdict][feature]['devices'][dev] += matches
    else:
        vmap[pri][verdict][feature]['devices'][dev] = matches

    return

def matches_result(matches, node):

    if matches == -1:
        return False

    verdict = 'pass'
    if matches:
        if 'MATCH' in node and node['MATCH'] == 'false':
            verdict = 'fail'
    else:
        if 'MATCH' in node:
            if node['MATCH'] == 'true':
                verdict = 'fail'
        else:
            verdict = 'fail'
    return verdict

def wc_matches_result(matches, node):

    if matches == -1:
        return False
    
    if 'MATCH' in node and node['MATCH'] == 'true':
        if matches:
            verdict = 'pass'
        else:
            verdict = 'fail'

    if 'TRACK_OPPOSITE_MATCH' in node and node['TRACK_OPPOSITE_MATCH'] == 'true':
        if matches:
            verdict = 'fail'
        else:
            verdict = 'pass'
    return verdict

def write_verdicts(verdicts, dev, dev_results, audit_tests,
        stats, features_to_desc, repo_dir, score_weights,
        regime, db_run_id, conf, cl):

    curr_dir = os.getcwd()

    if cl.db_audit:
        os.chdir(os.path.abspath(repo_dir + os.sep + 'audit'))
    else:
        if cl.flat_output_dir:
            if not os.path.exists(os.path.abspath(cl.flat_output_dir)):
                os.mkdir(os.path.abspath(cl.flat_output_dir))
            os.chdir(os.path.abspath(cl.flat_output_dir))
        elif cl.audit_file or cl.audit_dir:
            if not os.path.exists(os.path.abspath('audit')):
                os.mkdir(os.path.abspath('audit'))
            os.chdir(os.path.abspath('audit'))
        else:
            os.chdir(os.path.abspath(repo_dir + os.sep + 'audit'))

    if not cl.flat_output_dir:
        if not os.path.exists(os.path.abspath(regime)):
            os.mkdir(os.path.abspath(regime))
        os.chdir(regime)
        if not os.path.exists(dev):
            os.mkdir(dev)
        os.chdir(dev)

    audit_file = dev + '.audit'

    ### track a few stats over time for time-series graphs
    stats_file = dev + '.stats'

    ### optional Google Charts integration
    gcharts_lines = []
    gcharts_summary_rows = []
    gcharts_dev_file = dev + '_google_charts.html'

    gauge_health(dev, dev_results, audit_tests, stats, audit_file,
            stats_file, verdicts, score_weights, gcharts_lines,
            db_run_id, conf, cl)

    dtype = dev_results['types'][dev]
    if dtype not in features_to_desc:
        features_to_desc[dtype] = {}

    with open(audit_file, 'a') as f:
        f.write("\n--- MATCHES PER AUDIT TEST ---\n\n")
        f.write("%-9s %-10s %-12s %s\n" % \
                    ('Verdict:', 'Priority:', 'Matches:', 'AuditFeature:'))
        for pri in ['High', 'Medium', 'Low']:
            if pri not in verdicts:
                continue
            for result in verdicts[pri]:
                if not result:
                    continue
                f.write("%s\n" % result['line'])
            f.write("\n")

        if regime == 'PCI':
            write_PCI_requirements_summary(f)

        write_device_advisories(features_to_desc, dtype,
                verdicts, audit_tests, f)

    ### write out Google charts .html file for this device
    if cl.google_charts:
        gcharts_dev_hdr(dev, "%s Governance Summary" % regime,
                gcharts_lines, cl)
        gcharts_dev_footer(dev, gcharts_lines, regime, cl)
        with open(gcharts_dev_file, 'w') as f:
            for line in gcharts_lines:
                f.write("%s\n" % line)

    os.chdir(curr_dir)

    return

def write_device_advisories(features_to_desc, dtype,
        verdicts, audit_tests, f):

    ### now write out the full descriptions
    f.write("\n--- ADVISORY and REMEDIATION EXAMPLES ---\n\n")
    for pri in ['High', 'Medium', 'Low']:
        for result in verdicts[pri]:
            if not result:
                continue
            line = result['line']
            feature = ''
            ### Only print advisory information for audit failures
            ###     fail      Low        5            SNMP v1/v2 Community Strings -- NA
            ###     fail High  0 [0]   Secure Shell (SSH)
            if '--' in line:
                m = re.search('^fail(?:\s+\S+){2}\s+(\S.*?)\s+\-\-', line)
            else:
                m = re.search('^fail(?:\s+\S+){2}\s+(\S.*)', line)
            if m:
                feature = m.group(1)
                if feature in features_to_desc[dtype]:
                    if 'ADVISORY' in features_to_desc[dtype][feature]:
                        for adv_line in features_to_desc[dtype][feature]['ADVISORY']:
                            f.write("   %s\n" % adv_line)
                    if 'EXAMPLE' in features_to_desc[dtype][feature]:
                        for ex_line in features_to_desc[dtype][feature]['EXAMPLE']:
                            f.write("   %s\n" % ex_line)
                else:
                    for node in audit_tests['nodes']:
                        if dtype.lower() not in node['meta']['type'].lower():
                            continue
                        if feature == node['BEGIN_NODE']:
                            features_to_desc[dtype][feature] = {}
                            features_to_desc[dtype][feature]['ADVISORY'] = []
                            features_to_desc[dtype][feature]['EXAMPLE']  = []
                            if 'ADVISORY' in node:
                                for adv_line in node['ADVISORY']:
                                    features_to_desc[dtype][feature]['ADVISORY'].append(adv_line)
                                    f.write("   %s\n" % adv_line)
                            if 'EXAMPLE' in node:
                                for ex_line in node['EXAMPLE']:
                                    features_to_desc[dtype][feature]['EXAMPLE'].append(ex_line)
                                    f.write("   %s\n" % ex_line)
                f.write("%s\n\n" % line)
    return

def file_regex_matches(node_name, regex, lines, cl):
    num_matches = 0
    re_match_objs = []
    match_lines   = []
    line_ctr = 0
    if not lines:
        return num_matches, match_lines, re_match_objs
    for line in lines:
        m = re.search(regex, line)
        if m:
            re_match_objs.append(m)
            match_lines.append(line_ctr)
            num_matches += 1
            if cl.print_regex_matches:
                print "    NODE: '%s'" % node_name
                print "        Match (regex: '%s'): '%s'" % (regex, line.rstrip())
                n = 1
                while (n <= len(m.groups())):
                    print "            m.group(%d): '%s'" % (n, m.group(n))
                    n += 1
        line_ctr += 1
    return num_matches, match_lines, re_match_objs

def import_requirements_file(tests_dir, regime):
    requirements = {}
    with open("%s/%s/Requirements" % (tests_dir, regime), 'r') as f:
        for line in f:
            ### 4.1.e: Examine system configurations to verify usage of secure configurations
            m = re.search('(.*)\s*\:\s*(.*)', line.rstrip())
            if m:
                requirements[m.group(1)] = m.group(2)
    return requirements

def expand_audit_requirements(node_name, audit_criteria, requirements):
    criteria = ''
    if audit_criteria == 'NA':
        return 'NA'
    audit_criteria = audit_criteria.replace(' ', '')
    for rname in audit_criteria.split(','):
        if rname in requirements:
            criteria +="%s: %s, " % (rname, requirements[rname])
        else:
            print "[-] Missing: requirement identifier '%s' for test: '%s'" \
                    % (rname, node_name)
    if criteria:
        return criteria[0:-2]
    return criteria

def import_tests(function_map, db_run_id, regime, cl):

    audit_tests = {'nodes':[], 'name_to_vars':{}, 'paths':{}}

    requirements = import_requirements_file(cl.tests_dir, regime)

    print "[+] Importing audit tests from: %s/%s/" % (cl.tests_dir, regime)
    
    dev_types=set()
    for node_dir in glob.glob('%s/%s/*' % (cl.tests_dir, regime)):

        ### audit-tests/INFO/Syslog_Event_Logging/
        if not is_directory(node_dir):
            continue
        
        for cfile in glob.glob('%s/*conf' % node_dir):

            found_first_node = False
            skip_node        = False

            audit_tests['paths'][cfile] = ''

            ### derive the device type (or device identifier like 'Summit')
            ### from the config file name - e.g. 'EOS' in the file:
            ### /home/mbr/git/compli.git/audit-tests/INFO/Syslog_Event_Logging/EOS.conf
            dev_type = cfile.split('/')[-1].split('.conf')[0]
            dev_types.add(dev_type)
            
            with open(cfile, 'r') as f:

                ### the audit node will contain the search regex's, remediation
                ### language, etc.
                node = {'meta':{'type':dev_type, 'tests_file':cfile},
                            'IS_DISABLED':'false', 'IS_INTERNAL':'true'}

                text_elm = None
                for line in f:
                    ### allow for comments
                    if line[0] == '#':
                        continue
                    ### remove all non-ascii chars
                    line = re.sub(r'[^\x00-\x7f]',r'', line.rstrip())
                    m = re.search('^(\S+)=(.*)', line)
                    if m:
                        audit_var = m.group(1)
                        audit_val = m.group(2)
                        if audit_var == 'EXAMPLE' or audit_var == 'ADVISORY':
                            text_elm = audit_var
                            node[audit_var] = []
                            node[audit_var].append(audit_val)
                        else:
                            if audit_var == 'BEGIN_NODE':
                                if found_first_node:
                                    if 'AUDIT_CRITERIA' in node:
                                        node['AUDIT_CRITERIA_EXPANDED'] = \
                                                expand_audit_requirements(
                                                        node['BEGIN_NODE'],
                                                        node['AUDIT_CRITERIA'],
                                                        requirements)
                                    else:
                                        node['AUDIT_CRITERIA'] = 'NA'
                                        node['AUDIT_CRITERIA_EXPANDED'] = 'NA'
                                    if skip_node:
                                        node = {'meta':{'type':dev_type, 'tests_file':cfile}}
                                        skip_node = False
                                    else:
                                        strip_dangling_newlines(node)
                                        rv, err_str = validate_node(node)
                                        if rv:
                                            audit_tests['nodes'].append(node)
                                            audit_tests['name_to_vars'][node['BEGIN_NODE']] = {}
                                            for field in node:
                                                val = node[field]
                                                audit_tests['name_to_vars'][node['BEGIN_NODE']][field] = val
                                        else:
                                            if cl.db_audit:
                                                print_job_error(err_str, db_run_id, cl)
                                            else:
                                                sys.stderr.write("%s\n" % err_str)

                                    node = {'meta':{'type':dev_type, 'tests_file':cfile}}
                                else:
                                    found_first_node = True

                            if audit_var == 'TEST_FUNCTION' or \
                                    audit_var == 'TEST_FUNCTION_MULTIVERDICT':
                                node[audit_var] = function_map[audit_val]
                                ### keep the original value too for DB import routines
                                node["%s_ORIGVAL" % audit_var] = audit_val
                            elif audit_var == 'REQUIRE_CMD':
                                found_cmd = False
                                if 'cracklib-check' == audit_val:
                                    if cl.cracklib_check_cmd and os.path.exists(cl.cracklib_check_cmd):
                                        node[audit_var] = cl.cracklib_check_cmd
                                        found_cmd = True
                                if os.path.exists(audit_val):
                                    node[audit_var] = audit_val
                                    found_cmd = True
                                ### keep the original value too for DB import routines
                                node["%s_ORIGVAL" % audit_var] = audit_val

                                if not found_cmd:
                                    print "[-] Could not find REQUIRE_CMD '%s', excluding '%s' test" % \
                                        (audit_val, node['BEGIN_NODE'])
                                    node[audit_var] = 'NA'
                                    skip_node = True
                            else:
                                node[audit_var] = audit_val

                            text_elm = None
                    elif text_elm:
                        ### this is multi-line text
                        node[audit_var].append(line.rstrip())

                if 'AUDIT_CRITERIA' in node:
                    node['AUDIT_CRITERIA_EXPANDED'] = \
                        expand_audit_requirements(
                            node['BEGIN_NODE'],
                            node['AUDIT_CRITERIA'],
                            requirements)
                else:
                    node['AUDIT_CRITERIA'] = 'NA'
                    node['AUDIT_CRITERIA_EXPANDED'] = 'NA'

                if not skip_node:
                    strip_dangling_newlines(node)
                    rv, err_str = validate_node(node)
                    if rv:
                        ### add the last node
                        audit_tests['nodes'].append(node)
                        audit_tests['name_to_vars'][node['BEGIN_NODE']] = {}
                        for field in node:
                            val = node[field]
                            audit_tests['name_to_vars'][node['BEGIN_NODE']][field] = val
                    else:
                        if cl.db_audit:
                            print_job_error(err_str, db_run_id, cl)
                        else:
                            sys.stderr.write("%s\n" % err_str)

    ### validate REQUIRED_TESTS variables
    for node in audit_tests['nodes']:
        if 'REQUIRED_TESTS' in node:
            tests = node['REQUIRED_TESTS'].split(',')
            for test in tests:
                name    = test
                verdict = 'pass'
                if ':' in test:
                    name, verdict = test.split(':')
                if verdict != 'pass' and verdict != 'fail':
                    err_str = "[*] Invalid verdict '%s' referenced in '%s' REQUIRED_TESTS." \
                            % (verdict, node['BEGIN_NODE'])
                    if cl.db_audit:
                        print_job_error(err_str, db_run_id, cl)
                        sys.exit(0)
                    else:
                        raise NameError("[*] %s" % err_str)
                found_name = False
                ### make sure this test is defined
                for node in audit_tests['nodes']:
                    if name == node['BEGIN_NODE']:
                        found_name = True
                        break
                if not found_name:
                    err_str = "[*] Could not find test '%s' referenced in '%s' REQUIRED_TESTS." \
                            % (name, node['BEGIN_NODE'])
                    if cl.db_audit:
                        print_job_error(err_str, db_run_id, cl)
                        sys.exit(0)
                    else:
                        raise NameError("[*] %s" % err_str)

    print "    Imported %d audit tests across %d test directories." % \
            (len(audit_tests['nodes']), len(audit_tests['paths']))
    
    #Adding Device Types preconfigured in the deviceIdentities file
    conf=import_config(cl)
    #Devices parsed from the conf files are all internal devices so while adding the devices we send 1
    db_add_deviceTypes(conf,cl,1,dev_types)
        
    if not audit_tests:
        err_str = "[*] No audit tests imported, exiting."
        if cl.db_audit:
            print_job_error(err_str, db_run_id, cl)
            sys.exit(0)
        else:
            raise NameError("[*] %s" % err_str)

    return audit_tests

### Takes a list of OS types and inserts into govdevicetypes
### Input: set of device Types
### output:
def db_add_deviceTypes(conf,cl,isInternal,dev_types=set()):
    
    dev_type_ids=[]
    
    for devType in dev_types:
        dev_type_ids.append(db_add_dev_type(devType,conf,cl,isInternal))
    if len(dev_type_ids)==len(dev_types):
        print "[+] Device Types imported successfully" 
    else:
        err_str= "[*] Error Importing Device Types"
        if cl.db_audit:
            print_job_error(err_str, db_run_id, cl)
            sys.exit(0)
        else:
            raise NameError("[*] %s" % err_str)
    return 1

### generic method to insert/update the govsysoidtoostype table
def db_import_properties(mapSysoidOstype,dev_types,isInternal,conf,cl):
    for sysoid in mapSysoidOstype.keys() :
        deviceId=db_get_id("SELECT DEVICEID FROM netsight.govsysoidtodevicetype WHERE SYSOID= '%s' " \
                           %sysoid,conf,cl)
        if not deviceId:
            db_query("""INSERT INTO netsight.govsysoidtodevicetype (SYSOID,OSTYPE,ISINTERNAL) VALUES ('%s','%s','%d')""" % (sysoid,mapSysoidOstype[sysoid],isInternal),conf,cl)
        else :
            db_query("""UPDATE netsight.govsysoidtodevicetype SET OSTYPE='%s' WHERE DEVICEID='%s'""" % (mapSysoidOstype[sysoid],deviceId),conf,cl)
    db_add_deviceTypes(conf, cl,isInternal, dev_types)
    return 1
### Reads the Internal DeviceIdentities file and Modifies/Inserts into the DB
def db_import_deviceIdentities(conf,cl):
    mapSysoidOstype,dev_types=read_deviceIdentities_properties(cl)
    return db_import_properties(mapSysoidOstype, dev_types,1,conf, cl)

### Reads the third party devices from the properties file and Inserts/Modifies entries into DB
def db_import_third_party_devices(conf,cl):
    mapSysoidOstype,dev_types=read_thirdPartyDevices_properties(cl)
    return db_import_properties(mapSysoidOstype, dev_types,0,conf, cl)

### Wrapper To display the SYSOID->OSTYPE customer inserted into db 
def db_read_third_party_devices(conf,cl):
    q_result=db_query("""SELECT SYSOID,OSTYPE FROM netsight.govsysoidtodevicetype WHERE ISINTERNAL='%d' """ % (0),conf,cl)
    for result in q_result['fetchall'] :
        print "SYSOID: "+result[0]+" OSTYPE: "+result[1]
    return 1

### Deletes A particular SYSOID->OSType the user entered from the DB
def db_delete_third_party_device(conf,cl,sysoid):
    if not sysoid :
        sysoid=cl.device_sysoid
    if sysoid :
        deviceId=db_get_id("SELECT DEVICEID FROM netsight.govsysoidtodevicetype WHERE SYSOID= '%s' " \
                           %sysoid,conf,cl)
        if deviceId:
            db_query("DELETE FROM netsight.govsysoidtodevicetype WHERE DEVICEID='%s' " %deviceId,conf,cl)
            print "DELETED %s from Third Party Devices" %sysoid
        else :
            err_str= "[*] Could not find SYSOID %s please check the sysoid entered" %sysoid
            print err_str
            return 0
    return 1

### Deletes All SYSOIDs->OS type mapping and reimports from properties file
def db_reimport_third_party_devices(conf,cl) :
    q_result=db_query("""SELECT SYSOID,OSTYPE FROM netsight.govsysoidtodevicetype WHERE ISINTERNAL='%d' """ % (0),conf,cl)
    for result in q_result['fetchall']:
        sysoid=result[0] 
        if not db_delete_third_party_device(conf, cl,sysoid) :
            print "[*] An error occured during deletion, Aborting import"
            return 0
    db_import_third_party_devices(conf, cl)
    return 1

### renames the OS Type Added By the user
def db_rename_third_party_os_name(conf,cl) :
    old_os_name=cl.old_os_name
    new_os_name=cl.new_os_name
    if old_os_name and new_os_name :
        #check if it Exists
        deviceId=db_get_id("SELECT DEVICETYPEID FROM netsight.govdevicetypes WHERE DEVICETYPE= '%s' " \
                           %old_os_name,conf,cl)
        if deviceId :
            #Now Update in govsysoidtodevicetype
            gov_device_osmap_deviceIds=db_query("SELECT DEVICEID FROM netsight.govsysoidtodevicetype WHERE OSTYPE= '%s' " \
                           %old_os_name,conf,cl)['fetchall']
            for idtuple in gov_device_osmap_deviceIds :
                if idtuple[0]:
                    db_query("""UPDATE netsight.govsysoidtodevicetype SET OSTYPE='%s' WHERE DEVICEID='%d'""" %(new_os_name,idtuple[0]),conf,cl)
            #Then update in govdevicetypes
            db_query("""UPDATE netsight.govdevicetypes SET DEVICETYPE='%s' WHERE DEVICETYPEID='%d'""" %(new_os_name,deviceId),conf,cl)
        else :
                print "Could not find DEVICE TYPE %s" %old_os_name
    
    return 1
def db_perform_upgrade_operations(conf,cl):
    return internal_column_handler(conf, cl)

def internal_column_handler(conf,cl):
    #During an upgrade ensure old Device Types are mapped to 1 for new column Isinternal
    #Fetch All Existing Device Types that do not have a mapping for the ISINTERNAL column
    gov_old_device_types=db_query("SELECT DEVICETYPEID,ISINTERNAL FROM netsight.govdevicetypes",conf,cl)['fetchall']
    for results in gov_old_device_types :
        if results[1]==None and results[0]:
            db_query("""UPDATE netsight.govdevicetypes SET ISINTERNAL='%d' WHERE DEVICETYPEID='%d'""" %(1,results[0]),conf,cl)
    return 1
def strip_dangling_newlines(node):

    for key in ['EXAMPLE', 'AUDIT_CRITERIA', 'ADVISORY']:
        if key not in node:
            continue
        while not re.search('\S', node[key][-1]):
            node[key] = node[key][0:-1]

    return

def validate_node(node):
    for key in ['BEGIN_NODE', 'WEIGHT']:
        if key not in node:
            return False, "%s missing from audit node." % key

    if 'REGEX' not in node \
            and 'TEST_FUNCTION' not in node \
            and 'TEST_FUNCTION_MULTIVERDICT' not in node:
        return False, "Must have REGEX, TEST_FUNCTION, or " \
                + "TEST_FUNCTION_MULTIVERDICT is required in audit node."

    if 'ADVISORY' not in node and 'EXAMPLE' not in node:
        return False, "Could not find ADVISORY or EXAMPLE key in: %s" % \
                node['BEGIN_NODE']

    if 'REQUIRE_CMD' in node and node['REQUIRE_CMD'] == 'NA':
        return False, "Invalid command in: %s" % node['BEGIN_NODE']

    ### make sure any regex's compile
    for key in ['REGEX', 'ALT_REGEX', 'ALT_REGEX2', 'ALT_REGEX3', 'PREREQUISITE']:
        if key in node and node[key]:
            try:
                re.compile(node[key], flags=0)
            except:
                return False, "Audit test: '%s' has invalid regex in '%s' variable" % \
                        (node['BEGIN_NODE'], key)
    return True, ''

def add_wcontrollers(log_lines, xml_log_data, dev_results, all_devs, cl):
    for wcontroller in xml_log_data:
        if wcontroller not in all_devs:
            if cl.device_ip:
                if wcontroller != cl.device_ip:
                    continue
            all_devs.append(wcontroller)
            dev_results['types'][wcontroller] = 'WController'
            dev_results['running_configs'][wcontroller] = '<XML_log_data>'
    return

def import_devices(im_dir_re, repo_dir, wc_elm_types, netsight_job, db_run_id, cl):

    curr_dir = os.getcwd()
    unknown_devices=[]
    dev_types_dir = 'configs/dev-types'

    ### FIXME: net0044638 - temporary fix to ignore these args in --db-audit mode
    if cl.db_audit:
        os.chdir(repo_dir)
    else:
        if not cl.audit_file and not cl.audit_dir:
            os.chdir(repo_dir)

    devices     = []
    dev_results = {
        'types':{},
        'running_configs':{},
        'all_configs':{},
        'default_configs':{},
        'details':{},
        'parsed':{},
        'type_counts':{}
    }

    if not cl.db_audit and (cl.audit_file or cl.audit_dir):
        config_files = []
        if cl.audit_file:
            config_files.append(cl.audit_file)
        else:
            for config_file in glob.glob('%s/*' % cl.audit_dir):
                if config_file.endswith('info.txt'):
                    config_file = os.path.dirname(config_file) + os.sep + fetch_config_file(config_file)
                    del config_files[:]
                    if os.path.exists(config_file):
                        config_files.append(config_file)
                        break
                    else:
                        break
                    
                if not is_directory(config_file):
                    config_files.append(config_file)

        for config_file in config_files:
            device_dir = detect_management_ip(config_file, cl)
            if not device_dir:
                device_dir = config_file.split(os.sep)[1]
                
            dev_type, firmware = detect_dev_type(config_file,device_dir, cl)
            if dev_type:
                ### try to extract the IP, and if not set default to
                ### the filename
                device_dir = detect_management_ip(config_file, cl)

                if netsight_job:
                    if not netsight_job_match_dev(device_dir,
                            firmware, netsight_job, cl):
                        continue

                dev_results['types'][device_dir] = dev_type
                dev_results['running_configs'][device_dir] = config_file
                dev_results['all_configs'][device_dir] = []
                conf_dir = os.path.dirname(config_file)
                if conf_dir:
                    for f in os.listdir(conf_dir):
                        default_conf_files = get_default_conf_files()
                        if f in default_conf_files:
                            dev_results['default_configs'][device_dir] = conf_dir + os.sep + f
                            break

                if dev_type in dev_results['type_counts']:
                    dev_results['type_counts'][dev_type] += 1
                else:
                    dev_results['type_counts'][dev_type] = 1

                if firmware:
                    dev_results['details'][device_dir] = firmware

                if dev_type == 'WController':
                    dev_results['parsed'][device_dir] = \
                            parse_wcontroller_config(wc_elm_types, config_file)
                elif dev_type == 'XCA':
                    dev_results['parsed'][device_dir] = \
                            parse_wcontroller_config(wc_elm_types, config_file)                
                elif dev_type == 'WiNG':
                    dev_results['parsed'][device_dir] = \
                            parse_wing_config(config_file)

                devices.append(device_dir)

            else:
                print "[-] Warning: unknown device type for file: %s" % config_file
                unknown_devices.append(device_dir)

        if cl.audit_file:
            print "\n[+] Imported %d devices from file: %s" % \
                    (len(devices), cl.audit_file)
        else:
            print "[+] Imported %d devices from directory: %s" % \
                    (len(devices), cl.audit_dir)

        for dtype in dev_results['type_counts']:
            print "    %20s: %d" % (dtype, dev_results['type_counts'][dtype])

        if not devices:
            err_str = 'No devices imported, exiting.'
            if cl.db_audit:
                print_job_error(err_str, db_run_id, cl)
            sys.exit(0)
        return dev_results, devices,unknown_devices

    else:
        for config_file in get_cmd_output([cl.git_cmd,
                'ls-files', 'configs'], cl.verbose).splitlines():

            device_dir = config_file.split(os.sep)[1]

            if device_dir not in devices and re.search(im_dir_re, device_dir):

                if netsight_job:
                    if not netsight_job_match_dev(device_dir, '', netsight_job, cl):
                        continue

                if cl.db_audit and cl.archive_date:
                    ### match on a particular archive timestamp from InventoryMgr
                    if not db_match_dev_to_archive(device_dir, conf, cl):
                        continue

                if cl.device_ip:
                    if device_dir == cl.device_ip:
                        devices.append(device_dir)
                else:
                    devices.append(device_dir)

    if not devices:
        err_str = 'No devices imported, exiting.'
        if cl.db_audit:
            print_job_error(err_str, db_run_id, cl)
            sys.exit(0)
        else:
            raise NameError(err_str)

    ### now figure out what type of device this is. For devices imported by
    ### InventoryMgr, the filenames are known up front, but we double check
    ### with detect_dev_type()
    for device_dir in devices:

        conf_dir = 'configs' + os.sep + device_dir
        print "[+] Fingerprinting device: %s" % device_dir
        
        for cf_file in [conf_dir + os.sep + 'info.txt',
                conf_dir + os.sep + 'controller_config.cli',
                conf_dir + os.sep + 'primary.cfg',
                conf_dir + os.sep + device_dir + '.cfg',
                conf_dir + os.sep + 'nms.xsf']:
            if not os.path.exists(cf_file):
                continue
            
            if cf_file.endswith('info.txt'):
                cf_file = os.path.dirname(cf_file) + os.sep + fetch_config_file(cf_file)
                
                if not os.path.exists(cf_file):
                    print "Config file is missing for device: %s" % device_dir
                    break

            dev_type, firmware = detect_dev_type(cf_file, device_dir, cl)

            if dev_type:
                print "    %s" % dev_type
                dev_results['types'][device_dir] = dev_type
                dev_results['running_configs'][device_dir] = cf_file
                dev_results['all_configs'][device_dir] = []
                for f in os.listdir(conf_dir):
                        dev_results['all_configs'][device_dir].append(conf_dir + os.sep + f)
                        default_conf_files = get_default_conf_files()
                        if f in default_conf_files:
                            dev_results['default_configs'][device_dir] = conf_dir + os.sep + f
                            break
                if firmware:
                    dev_results['details'][device_dir] = firmware

                if dev_type == 'WController':
                    ### parse the controller configuration file
                    dev_results['parsed'][device_dir] = \
                            parse_wcontroller_config(wc_elm_types, cf_file)
                elif dev_type == 'XCA':
                    dev_results['parsed'][device_dir] = \
                            parse_wcontroller_config(wc_elm_types, cf_file)
                elif dev_type == 'WiNG':
                    dev_results['parsed'][device_dir] = \
                            parse_wing_config(cf_file)

                ### create the types/WController/<ip> link 
                dev_type_link(dev_results['types'][device_dir], device_dir, cl)
                break
            
        if not dev_type:
            print "    Could not fingerprint device: %s" % device_dir
            unknown_devices.append(device_dir)
    
    if cl.git_enable:
        print os.getcwd()
        if os.path.exists(dev_types_dir):
            for dir in os.listdir(dev_types_dir):
                git_add(dev_types_dir+"/"+dir+"/", "%s link -> devices" % (dir), cl)
            
            
    os.chdir(curr_dir)

    print "[+] Imported %d devices." % len(devices)

    return dev_results, devices,unknown_devices

def get_default_conf_files():
    return ['nms.xsf']

def detect_management_ip(conf_file, cl):

    ### default to the config file itself
    ip = conf_file

    if conf_file and '/' in conf_file:
        ### extract the filename
        ip = conf_file.split('/')[-1]

    if not ip:
        return False

    ### chop any existing extension
    m = re.search('(\S+)\.', ip)
    if m:
        ip = m.group(1)

    ip_regexs = [
        ### (EXOS) ### configure vlan Mgmt ipaddress 10.88.12.128 255.255.252.0
        '^configure\svlan\sMgmt\sipaddress\s(\S+)\s\d',
        ### (EXOS) ### configure tacacs primary server 10.87.231.233 49 client-ip 10.88.12.128 vr VR-Mgmt
        ### FIXME: add this one

        ### EOS ### ip address 10.56.4.2 255.255.255.255 primary management
        '^\s*ip\saddress\s(\S+)\s\S+\sprimary\smanagement',
        ### EOS ### ip address 10.56.4.2 255.255.255.255 primary
        '^\s*ip\saddress\s(\S+)\s\S+\sprimary',
        ### Wcontroller ### ip 10.54.165.16/24
        '^\s*ip\s(\S+)\/\d+'
    ]
    found_ip = False
    for regex in ip_regexs:
        re_match = file_has_regex(regex, conf_file)
        if re_match:
            ip = re_match.group(1)
            found_ip = True
            break

    if cl.verbose:
        if found_ip:
            print "[+] Found management ip: '%s' for file: '%s'" % (ip, conf_file)
        else:
            print "[-] Could not find management ip for file: '%s', setting to: '%s'" \
                    % (conf_file, ip)
    return ip

def parse_wing_config(cf_file):

    ### dictionary representation of a WiNG configuration
    config = {'profiles':[], 'rfdomains':[], 'management-policies':[], 'wips-policies':[], 'firewall-policies':[]}

    ### parse manage policies first, which get used by profiles
    wingaudit.wing_parse_management_policies(config, cf_file)
    
    ## parse wips policies first, which get used by rf-domain
    wingaudit.wing_parse_wips_policies(config, cf_file)
    
    ### parse firewall policies first, which get used by profiles
    wingaudit.wing_parse_firewall_policies(config, cf_file)

    ### parse profiles next, which get used by AP's
    wingaudit.wing_parse_profiles(config, cf_file)
    
    ### parse rf-domains next, which get used by AP's
    wingaudit.wing_parse_rfdomains(config, cf_file)

    ### parse AP's
    ap_list = wingaudit.wing_parse_aps(config, cf_file)

    return ap_list

def parse_wcontroller_config(wc_elm_types, cf_file):

    config = {'subnames':{}, 'no_subnames':{}, 'single_line':{}}

    ### Example wireless controller stanza:

#    #
#    # VNS
#    vnsmode
#        create "Prod Guest" wlans "Prod Guest" pol "Prod Guest"
#        "Prod Guest"
#            wlans-name "Prod Guest"
#            non-auth "Prod Guest"
#            auth "Prod Guest"
#            status enable
#            sync enable
#            name "Prod Guest"
#            sync-timestamp 1342708501
#            apply
#            exit
#        end

    ### ^^^ in the above:
    ###         etype = vnsmode
    ###         ename = "Prod Guest"

    line_ctr = 0
    with open(cf_file) as f:
        etype = ''
        ename = ''
        elm   = {}
        for line in f:
            line_ctr += 1

            ### allow for comments
            if line[0] == '#':
                continue

            ### look for the start of an element (etype)
            m = re.search('^(\w+)', line)
            if m:
                etype = m.group(1)
                if etype and etype in wc_elm_types['single_line']:
                    if etype not in config['single_line']:
                        config['single_line'][etype] = []
                    config['single_line'][etype].append(line.rstrip())
                    etype = ''
                ename = ''
                continue

            ### organize the config hash by element name ('subname')
            m = re.search('^\s{4}\"(.*?)\"', line)
            if m:
                ename = m.group(1)
                continue

            ### look for the end of the current element
            m = re.search('^\s{4}end', line)
            if m:
                if not ename and etype not in wc_elm_types['allow_no_subname'] \
                        and etype not in wc_elm_types['single_line']:

                    ### example stanzas like this:

                    # ap
                    #     access 0500010033050672    sensor
                    #     access 0500010033050682    sensor
                    #     access 10200897235H0000    sensor
                    #     end

                    # secureconnection
                    #     weak-ciphers enable
                    #     apply
                    #     end
                    print "[-] Could not find subname for '%s' at line: %d" \
                            % (etype, line_ctr)
                    etype = ''
                    ename = ''
                    elm   = {}
                    continue

                if ename:
                    if ename not in config['subnames']:
                        config['subnames'][ename] = {}
                    if etype in config['subnames'][ename]:
                        print "[-] Wireless controller config collision on '%s'->'%s' (line: %d)" \
                                % (etype, ename, line_ctr)
                        continue
                    else:
                        config['subnames'][ename][etype] = elm
                else:
                    if etype not in config['no_subnames']:
                        config['no_subnames'][etype] = []
                    config['no_subnames'][etype].append(elm)

                etype = ''
                ename = ''
                elm   = {}
                continue

            if etype:
                if 'lines' not in elm:
                    elm['lines'] = []
                elm['lines'].append(line.rstrip())

    # pprint.pprint(config)
    return config

def verify_args(cl):

    rv = True

    if cl.job_file:
        if cl.governance_type:
            raise NameError("[*] Cannot set --governance-type in --job-file mode" )

    if not cl.governance_type:
        if cl.tests_file:
            cl.governance_type = 'INFO'
        else:
            cl.governance_type = 'PCI'

    if cl.git_disable:
        cl.git_enable = False

    if not cl.dump_to_html and not cl.dump_tests:
        if cl.git_enable:
            if not os.path.exists(cl.git_cmd):
                print "[*] Please set the path to git, exiting."
                rv = False
            if cl.enable_gitstats:
                if not os.path.exists(cl.gitstats_cmd):
                    print "[*] gitstats path '%s' does not exist" % cl.gitstats_cmd
                    rv = False
        else:
            if not cl.audit_file and not cl.audit_dir:
                if not cl.db_audit:
                    print "[*] In --git-disable mode, must set either --audit-file or --audit-dir"
                    rv = False

    if not cl.netsight_dir:
        cl.netsight_dir = get_netsight_path(cl.dotnetsight_file, cl.verbose)

    if not cl.jboss_properties_file:
        cl.jboss_properties_file = "%s/appdata/NSJBoss.properties" % cl.netsight_dir

    if not cl.db_audit:
        if not os.path.exists(cl.tests_dir):
            print "[*] Please set the path to the audit-tests/ directory, exiting."
            rv = False

        if not os.path.exists(os.path.abspath(cl.tests_dir + \
                os.sep + cl.governance_type)):
            print "[*] Governance type directory does not exist: %s" % \
                    (cl.audit_dir) + os.sep + "%s" % (cl.governance_type)
            rv = False

    if cl.audit_file:
        if not os.path.exists(cl.audit_file):
            print "[*] File does not exist: '%s'" % cl.audit_file
            rv = False
    elif cl.audit_dir:
        if not os.path.exists(cl.audit_dir):
            print "[*] Directory does not exist: '%s'" % cl.audit_dir
            rv = False

    return rv

def validate_git_dir(repo_dir):
    if not os.path.exists(repo_dir):
        raise NameError("[*] Device governance.git " \
                "repository does not exist: %s" % repo_dir)
    for gdir in ['configs', 'audit', 'state']:
        if not os.path.exists(repo_dir + os.sep + gdir):
            raise NameError("[*] %s subdir does not exist in: %s" % (gdir, repo_dir))
    return

def write_stats_legend(f):
    f.write("Legend:\n" \
            "    'P/F/T/A'     = 'Pass/Fail/Total/Applicable'\n" \
            "    'Pass:'       = 'Percentage of passed audit tests'\n" \
            "    'Delta'       = 'Change from previous audit'\n\n")

def write_prevmetrics_legend(f):
    f.write("Legend:\n" \
            "    'P/F/T/A'     = 'Pass/Fail/Total/Applicable'\n" \
            "    'Pass:'       = 'Percentage of passed audit tests'\n" \
            "    'PrevMetrics' = 'Metrics from previous audit'\n" \
            "    'Delta'       = 'Change from previous audit'\n\n")
    return

def write_PCI_requirements_summary(f):
    f.write("\n\n--- PCI REQUIREMENTS SUMMARY ---\n\n" \
            "1:  Install and maintain a firewall configuration to protect cardholder data.\n" \
            "2:  Do not use vendor-supplied defaults for system passwords and other security parameters.\n" \
            "3:  Protect stored cardholder data.\n" \
            "4:  Encrypt transmission of cardholder data across open, public networks.\n" \
            "5:  Use and regularly update anti-virus software or programs.\n" \
            "6:  Develop and maintain secure systems and applications.\n" \
            "7:  Restrict access to cardholder data by business need to know.\n" \
            "8:  Assign a unique ID to each person with computer access.\n" \
            "9:  Restrict physical access to cardholder data.\n" \
            "10: Track and monitor all access to network resources and cardholder data.\n" \
            "11: Regularly test security systems and processes.\n" \
            "12: Maintain a policy that addresses information security for all personnel.\n\n")
    return

def run_gitstats(gitstats_dir, repo_dir, cl):
    print "[+] Running gitstats, output in: %s" % gitstats_dir
    do_cmd("%s %s %s" % (cl.gitstats_cmd, repo_dir,
        gitstats_dir), cl.verbose)
    if not os.path.exists(gitstats_dir + os.sep + 'gitstats.css'):
        if os.path.exists('misc' + os.sep + 'gitstats.css'):
            copy('misc' + os.sep + 'gitstats.css',
                    gitstats_dir + os.sep + 'gitstats.css')
    return

def dump_tests_to_html(audit_tests, regime, cl):
    print "[+] Writing audit configs to HTML files..."

    html_dir = 'html'

    curr_dir = os.getcwd()
    if os.path.exists(html_dir):
        rmtree(html_dir)
    if not os.path.exists(html_dir):
        os.mkdir(html_dir)
    os.chdir(html_dir)

    by_os = {}
    titles = []
    index_html_lines = []
    uniq_index = {}

    ### write all tests to the 'PCI.html' file
    test_ctr = 0
    with open(regime + '.html', 'w') as f:
        f.write("<html>\n<body>\n")
        for node in audit_tests['nodes']:
            dev_type = node['meta']['type']

            if os not in by_os:
                by_os[dev_type] = []

            by_os[dev_type].append(node)

            ### force upper case for the first character
            title = node['BEGIN_NODE']
            chars = list(title)
            chars[0] = chars[0].upper()
            node['BEGIN_NODE'] = ''.join(chars)
            titles.append(node['BEGIN_NODE'])

            f.write("<h1>%s</h1><br/>\n" % node['BEGIN_NODE'])
            for elm in ['ADVISORY', 'EXAMPLE']:
                if elm in node:
                    f.write('<b>%s</b><br/><br/>\n' % elm)
                    for line in node[elm]:
                        f.write('%s<br/>\n' % line)
                    f.write("<br/><br/>\n")
            f.write("<br/><br/>\n")
            test_ctr += 1

            cname = node['meta']['tests_file'].split('/')[-2]
            with open(cname + '.html', 'w') as t:
                t.write("<html>\n<body>\n")
                ### write a dedicated .html file for this test
                t.write("<h1>%s</h1><br/>\n" % node['BEGIN_NODE'])
                for elm in ['ADVISORY', 'EXAMPLE']:
                    if elm in node:
                        t.write('<b>%s</b><br/><br/>\n' % elm)
                        for line in node[elm]:
                            t.write('%s<br/>\n' % line)
                        t.write("<br/><br/>\n")
                t.write("<br/><br/>\n")
                t.write("</body>\n</html>\n")
                print "    Wrote 1 test to html/%s file" % \
                        (cname + '.html')

            ### add a link to this test file to index.html
            if cname not in uniq_index:
                dtypes = get_dev_types(cname, audit_tests)
                index_html_lines.append('<tr/><td><a href="%s.html">%s</a></td>' \
                        % (regime, regime) \
                        + '<td><a href="%s.html">%s</a></td><td>%s</td></tr>' \
                        % (cname, cname, dtypes))
                uniq_index[cname] = ''

        f.write("</body>\n</html>\n")
        print "    Wrote %s tests to html/%s file" % \
                (test_ctr, regime + '.html')

    ### write out the index.html file
    with open('index.html', 'w') as f:
        f.write("<html>\n<body>\n")
        f.write("<table>\n")
        for line in index_html_lines:
            f.write("%s\n" % line)
        f.write("</table>\n</body>\n</html>\n")

    ### write out tests for each OS type
    for dev_type in by_os:
        html_file = dev_type + '.html'
        test_ctr = 0
        with open(html_file, 'w') as f:
            f.write("<html>\n<body>\n")
            for title in sorted(titles):
                for node in by_os[dev_type]:
                    if title == node['BEGIN_NODE']:
                        f.write("<h1>%s</h1><br/>\n" % node['BEGIN_NODE'])
                        for elm in ['ADVISORY', 'EXAMPLE']:
                            if elm in node:
                                f.write('<b>%s</b><br/><br/>\n' % elm)
                                for line in node[elm]:
                                    f.write('%s<br/>\n' % line)
                                f.write("<br/><br/>\n")
                        f.write("<br/><br/>\n")
                        test_ctr += 1
                        break
            f.write("</body>\n</html>\n")
        print "    Wrote %s tests to html/%s file" % (test_ctr, html_file)

    os.chdir(curr_dir)
    return

def get_dev_types(cname, audit_tests):
    dtypes = ''
    for node in audit_tests['nodes']:
        if cname == node['meta']['tests_file'].split('/')[-2]:
            fname = node['meta']['tests_file'].split('/')[-1].split('.conf')[0]
            dtypes += '<a href="%s.html">%s</a> / ' % (fname, fname)
    return dtypes[:-3]

def is_directory(cdir):
    return os.path.exists(cdir) and os.path.isdir(cdir)

def db_exit(db_run_id, es, conf, cl):
    db_set_endtime(db_run_id, conf, cl)
    sys.stdout.write("\n") ### for NetSight error parsing
    sys.stderr.write("\n")
    return es

def db_match_dev_to_archive(device_dir, conf, cl):
    if not db_get_id("""
SELECT m.id
FROM govDeviceToInventoryMgrArchive m, govDevices d
WHERE d.deviceIpv4 = '%s' AND d.deviceId = m.deviceId AND m.archiveStr = '%s'
""" % (device_dir, cl.archive_date), conf, cl):
        return False
    return True

def db_set_endtime(db_run_id, conf, cl):
    ### set the endTime for this audit run
    db_query("UPDATE govRuns SET endTime = (UNIX_TIMESTAMP()*1000) WHERE runId = %s" \
        % db_run_id, conf, cl)
    return

def db_rm_gov_type(conf, cl):
    if not db_query("SELECT name FROM govRegimes WHERE name = '%s'" \
            % cl.governance_type, conf, cl)['fetchall']:
        raise NameError("[*] --governance-type %s does not exist" % cl.governance_type)

    db_query("DELETE FROM govRegimes WHERE name = '%s'" \
            % (cl.governance_type), conf, cl)

    return 1

def db_gov_type_exists(conf, cl):
    if db_query("SELECT name FROM govRegimes WHERE name = '%s'" \
            % cl.governance_type, conf, cl)['fetchall']:
        return True
    return False

def db_ignore_wireless_threats(conf, cl):
    return db_get_boolean(
            "SELECT ignoreWirelessThreats FROM govRegimes WHERE name = '%s'" \
            % cl.governance_type, conf, cl)

def db_new_run_id(conf, cl):
    avgscore = -1 ### default to -1 avg score
    db_run_id = db_query("""
INSERT INTO govRuns
(regimeId, avgScore, startTime)
VALUES(%s, %s, (UNIX_TIMESTAMP()*1000))
""" % (db_get_regime_id(conf, cl), avgscore), conf, cl)['lastrowid']
    ### set the end time to make sure there are no NULL entries, and
    ### this will get updated before exit()
    db_set_endtime(db_run_id, conf, cl)
    return db_run_id

def db_map_audit_tests_to_run_id(audit_tests, db_run_id, conf, cl):
    for node in audit_tests['nodes']:
        ### map the runId to this audit test
        db_map_run_id_to_test(db_run_id, node['auditTestId'], conf, cl)
    return

def db_get_regime_id(conf, cl):
    regime_id = db_get_id("SELECT regimeId FROM govRegimes WHERE name = '%s'" \
            % cl.governance_type, conf, cl)
    if not regime_id:
        ### if we're importing a single test with --db-import-test, then add this regime
        if cl.db_import_test:
            db_add_gov_type(conf, cl)
            regime_id = db_get_id("SELECT regimeId FROM govRegimes WHERE name = '%s'" \
                    % cl.governance_type, conf, cl)
            db_add_requirements(conf, cl)
    if not regime_id:
            sys.stderr.write("***0*** !%s %s!\n\n" % ('No matching regime:', cl.governance_type))
            raise NameError("[*] Could not get regimeId field for gov type '%s'" \
                % cl.governance_type)
    return regime_id

def db_add_requirements(conf, cl):
    requirements = import_requirements_file(cl.tests_dir, cl.governance_type)

    regime_id = db_get_regime_id(conf, cl)

    for rname in requirements:
        if not db_get_id("""
SELECT requirementId
FROM govRequirements
WHERE name = '%s' AND regimeId = %s
""" % (rname, regime_id), conf, cl):
            db_query("""
INSERT INTO govRequirements
(name, description, regimeId)
VALUES('%s', '%s', '%s')
""" % (rname, requirements[rname], regime_id), conf, cl)

    return

def db_add_dev_result(result, dev_id, db_run_id, conf, cl):
    
    detailsmap = {'db_details':'','ap_name':''}
    
    for detail in detailsmap:
        if detail in result and result[detail]:
            detailsmap[detail] = result[detail].replace("'", '')

    db_query("""
INSERT INTO govDeviceResults
(deviceId, auditTestId, runId, verdict, apname, details)
VALUES(%s, %s, %s, %s, '%s', '%s')
""" % (dev_id, result['auditTestId'],
            db_run_id, verdict_to_int(result['verdict']), detailsmap['ap_name'], detailsmap['db_details']),
            conf, cl)
    return

def db_get_dev_id(dev, conf, cl):
    dev_id = db_get_id(
        "SELECT deviceId FROM govDevices WHERE deviceIpv4 = '%s'" \
                % dev, conf, cl)
    if not dev_id:
        raise NameError("[*] Could not get deviceId for '%s'" % dev)
    return dev_id

def db_map_run_id_to_test(db_run_id, audit_test_id, conf, cl):
    db_query("""
INSERT INTO govRunToAuditTest
(runId, auditTestId)
VALUES(%s, %s)
""" % (db_run_id, audit_test_id), conf, cl)
    return

def db_map_run_id_to_dev(db_run_id, dev, conf, cl):
    db_query("""
INSERT INTO govRunToDevice
(runId, deviceId)
VALUES(%s, %s)
""" % (db_run_id, db_get_dev_id(dev, conf, cl)), conf, cl)
    return

def db_add_dev_score(tot_tests, dev_id, regime_id, score, db_run_id, conf, cl):
    #dev_id = db_get_dev_id(dev, conf, cl)

    db_query("""
INSERT INTO govDeviceScores
(deviceId, regimeId, score, runId, numTests)
VALUES(%s, %s, %s, %s, %s)
""" % (dev_id, regime_id, score, db_run_id, tot_tests), conf, cl)
    return

def db_add_dev_config(dev_id, cf_file, conf, cl):
    if not db_get_id("""
SELECT deviceConfigId
FROM govDeviceToConfigs
WHERE deviceId = %s AND configFilePath = '%s'
""" % (dev_id, cf_file), conf, cl):
        db_query(
            "INSERT INTO govDeviceToConfigs (deviceId, configFilePath) VALUES (%s, '%s')" \
            % (dev_id, cf_file), conf, cl)
    return

def db_add_gov_type(conf, cl):
    if not cl.governance_type:
        raise NameError("[*] Must set --governance-type")

    if db_gov_type_exists(conf, cl):
        raise NameError("[*] --governance-type %s already exists" % cl.governance_type)

    if not os.path.exists('%s/%s' % (cl.tests_dir, cl.governance_type)):
        raise NameError("No such directory: %s/%s" % (cl.tests_dir, cl.governance_type))
    ### import the 'Description' file
    description = ''
    desc_file = '%s/%s/Description' % (cl.tests_dir, cl.governance_type)
    if os.path.exists(desc_file):
        with open(desc_file, 'r') as f:
            for line in f:
                description = line.rstrip()
                if description:
                    break
    else:
        raise NameError("Description file not found: %s" % desc_file)

    return db_query("INSERT INTO govRegimes (name, description, isInternal, isSystem, ignoreWirelessThreats) " \
            + "VALUES('%s', '%s', %s, %s, %s)" \
            % (cl.governance_type, description, cl.db_gov_is_internal, cl.db_gov_is_system, 0),
                conf, cl)['lastrowid']

### convert an audit test node into a dictionary suitable for DB interactions
def node_to_dbnode(node):
    db_node = {}

    ### these keys can just be copied directly if they exist
    for key in ['BEGIN_NODE',
            'REGEX',
            'ALT_REGEX',
            'ALT_REGEX2',
            'ALT_REGEX3',
            'PREREQUISITE',
            'XML_ELM',
            'XML_INFO_ELMS',
            'REQUIRE_CMD_ORIGVAL',
            'TEST_FUNCTION_ORIGVAL',
            'TEST_FUNCTION_MULTIVERDICT_ORIGVAL']:
        db_node[key] = key_to_str(node, key)

    ### these keys need to be converted to boolean values
    for key in ['MATCH',
            'PREREQUISITE_MATCH',
            'SUPPRESS_ALERT',
            'LOOP_ALL',
            'MATCH_ALL',
            'REGEX_GROUP_ANCHOR',
            'XML_DATA',
            'TRACK_OPPOSITE_MATCH',
            'CHECK_DEFAULT_CONFIG_FILE']:
        db_node[key] = key_to_bool(node, key)

    ### for all tests imported from the filesystem we define these as
    ### 'internal' so they cannot be modified by the user
    db_node['IS_INTERNAL'] = 1
    db_node['IS_DISABLED'] = 0  ### enable tests by default

    ### special keys
    db_node['WEIGHT'] = weight_to_int(node, 'WEIGHT')
    for key in ['EXAMPLE', 'ADVISORY']:
        if key in node:
            db_node[key] = '\n'.join(node[key])
        else:
            db_node[key] = 'NA'

    return db_node

def db_get_test_id(name, gov_type, dev_type, conf, cl):
    return db_get_id("""
SELECT t.auditTestId
FROM govAuditTests t, govRegimes r, govRegimeToAuditTest m,
govAuditTestToDeviceType s, govDeviceTypes dtype
WHERE t.name = '%s'
AND t.auditTestId = m.auditTestId
AND r.regimeId = m.regimeId
AND r.name = '%s'
AND s.auditTestId = t.auditTestId
AND s.deviceTypeId = dtype.deviceTypeId
AND dtype.deviceType = '%s'
""" % (name, gov_type, dev_type), conf, cl)

def db_import_test_sequence(node, conf, cl):
    sequence = node['REQUIRED_TESTS'].split(',')
    top_audit_id = db_get_test_id(node['BEGIN_NODE'], cl.governance_type,
                node['meta']['type'], conf, cl)

    ### delete the sequence if it already exists and then recreate it
    if db_get_id("""
SELECT sequenceId
FROM govAuditTestSequences
WHERE topAuditTestId = %s
""" % (top_audit_id), conf, cl):
        db_query("""
DELETE FROM govAuditTestSequences
WHERE topAuditTestId = '%s'
""" % (top_audit_id), conf, cl)

    for test in sequence:
        name    = test
        verdict = 'pass'
        if ':' in test:
            name, verdict = test.split(':')

        test_id = db_get_test_id(name, cl.governance_type,
                node['meta']['type'], conf, cl)

        if test_id:
            if not db_get_id("""
SELECT sequenceId
FROM govAuditTestSequences
WHERE topAuditTestId = %s
AND dependentAuditTestId = %s
""" % (top_audit_id, test_id), conf, cl):
                db_query("""
INSERT INTO govAuditTestSequences
(topAuditTestId, dependentAuditTestId, verdict)
VALUES(%s, %s, %s)
""" % (top_audit_id, test_id, verdict_to_int(verdict)), conf, cl)
        else:
            raise NameError("[*] Could not find auditTestId for REQUIRED_TEST '%s' in node: '%s'" \
                    % (name, node['BEGIN_NODE']))
    return

def db_import_test(node, conf, cl):

    ### check to see if the --governance-type exists
    if not db_gov_type_exists(conf, cl):
        raise NameError("[*] --governance-type '%s' does not exist, run --db-add-gov-type" \
                % cl.governance_type)

    ### see if this test already exists in the DB, and update vs. insert if so
    test_id = db_get_test_id(node['BEGIN_NODE'], cl.governance_type,
            node['meta']['type'], conf, cl)

    # mysql> desc govAuditTests;
    # +--------------------------+---------------+------+-----+---------+----------------+
    # | Field                    | Type          | Null | Key | Default | Extra          |
    # +--------------------------+---------------+------+-----+---------+----------------+
    # | AUDITTESTID              | bigint(20)    | NO   | PRI | NULL    | auto_increment |
    # | NAME                     | varchar(256)  | YES  |     | NULL    |                |
    # | ADVISORY                 | text          | YES  |     | NULL    |                |
    # | EXAMPLE                  | varchar(4096) | YES  |     | NULL    |                |
    # | WEIGHT                   | int(11)       | YES  |     | NULL    |                |
    # | ISMATCH                  | int(11)       | YES  |     | NULL    |                |
    # | REGEX                    | varchar(512)  | YES  |     | NULL    |                |
    # | ALTREGEX                 | varchar(512)  | YES  |     | NULL    |                |
    # | ALTREGEX2                | varchar(512)  | YES  |     | NULL    |                |
    # | ALTREGEX3                | varchar(512)  | YES  |     | NULL    |                |
    # | PREREQUISITEREGEX        | varchar(512)  | YES  |     | NULL    |                |
    # | PREREQUISITEMATCH        | int(11)       | YES  |     | NULL    |                |
    # | SUPPRESSALERT            | int(11)       | YES  |     | NULL    |                |
    # | LASTRUN                  | bigint(20)    | YES  |     | NULL    |                |
    # | NEXTRUN                  | bigint(20)    | YES  |     | NULL    |                |
    # | XMLMATCH                 | int(11)       | YES  |     | NULL    |                |
    # | XMLELM                   | varchar(4096) | YES  |     | NULL    |                |
    # | XMLINFOELMS              | varchar(4096) | YES  |     | NULL    |                |
    # | TRACKOPPOSITEMATCH       | int(11)       | YES  |     | NULL    |                |
    # | REQUIRECMD               | varchar(4096) | YES  |     | NULL    |                |
    # | LOOPALL                  | int(11)       | YES  |     | NULL    |                |
    # | MATCHALL                 | int(11)       | YES  |     | NULL    |                |
    # | REGEXGROUPANCHOR         | int(11)       | YES  |     | NULL    |                |
    # | TESTFUNCTION             | varchar(4096) | YES  |     | NULL    |                |
    # | TESTFUNCTIONMULTIVERDICT | varchar(4096) | YES  |     | NULL    |                |
    # | ISINTERNAL               | int(11)       | YES  |     | NULL    |                |
    # | ISDISABLED               | int(11)       | YES  |     | NULL    |                |
    # | CHECKDEFAULTCONFIGFILE   | int(11)       | YES  |     | NULL    |                |
    # +--------------------------+---------------+------+-----+---------+----------------+
    # 28 rows in set (0.00 sec)


    ### get the DB-ready equivalent of the audit test node
    db_node = node_to_dbnode(node)

    ### get the regime_id
    regime_id = db_get_regime_id(conf, cl)

    if test_id:
        ### update the test
        query = """
UPDATE govAuditTests
SET name=%(BEGIN_NODE)s, advisory=%(ADVISORY)s, example=%(EXAMPLE)s, weight=%(WEIGHT)s, isMatch=%(MATCH)s,
regex=%(REGEX)s, altRegex=%(ALT_REGEX)s, altRegex2=%(ALT_REGEX2)s, altRegex3=%(ALT_REGEX3)s, prerequisiteRegex=%(PREREQUISITE)s,
prerequisiteMatch=%(PREREQUISITE_MATCH)s, suppressAlert=%(SUPPRESS_ALERT)s, loopAll=%(LOOP_ALL)s, matchAll=%(MATCH_ALL)s,
regexGroupAnchor=%(REGEX_GROUP_ANCHOR)s, xmlMatch=%(XML_DATA)s, xmlElm=%(XML_ELM)s, xmlInfoElms=%(XML_INFO_ELMS)s,
trackOppositeMatch=%(TRACK_OPPOSITE_MATCH)s, requireCmd=%(REQUIRE_CMD_ORIGVAL)s, testFunction=%(TEST_FUNCTION_ORIGVAL)s,
testFunctionMultiVerdict=%(TEST_FUNCTION_MULTIVERDICT_ORIGVAL)s, isInternal=%(IS_INTERNAL)s, isDisabled=%(IS_DISABLED)s,
checkDefaultConfigFile=%(CHECK_DEFAULT_CONFIG_FILE)s
"""
        query += "WHERE auditTestId = " + str(test_id)
        db_query_param(query, db_node, conf, cl)

        ### delete any existing mapping (the code below creates it again
        ### with the correct - potentially updated - values)
        if db_get_id("""
SELECT auditTestId FROM govRegimeToAuditTest
WHERE auditTestId = %s AND regimeId = %s
""" % (test_id, regime_id), conf, cl):
            db_query(
                "DELETE FROM govRegimeToAuditTest WHERE auditTestId = '%s'" \
                        % test_id, conf, cl)

        if db_get_id("""
SELECT auditTestId
FROM govAuditTestToDeviceType
WHERE auditTestId = %s
""" % (test_id), conf, cl):
            db_query(
                "DELETE FROM govAuditTestToDeviceType WHERE auditTestId = '%s'" \
                        % test_id, conf, cl)

        if db_get_id("""
SELECT auditTestId FROM govAuditTestToRequirements
WHERE auditTestId = %s
""" % (test_id), conf, cl):
            db_query(
                "DELETE FROM govAuditTestToRequirements WHERE auditTestId = '%s'" \
                        % test_id, conf, cl)

    else:

        ### new test so insert it into the DB
        query = """
INSERT INTO govAuditTests
(name, advisory, example, weight, isMatch, regex, altRegex,
altRegex2, altRegex3, prerequisiteRegex, prerequisiteMatch,
suppressAlert, loopAll, matchAll, regexGroupAnchor,
xmlMatch, xmlElm, xmlInfoElms, trackOppositeMatch, requireCmd,
testFunction, testFunctionMultiVerdict, isInternal, isDisabled, checkDefaultConfigFile)
VALUES
(%(BEGIN_NODE)s, %(ADVISORY)s, %(EXAMPLE)s, %(WEIGHT)s, %(MATCH)s,
%(REGEX)s, %(ALT_REGEX)s, %(ALT_REGEX2)s, %(ALT_REGEX3)s, %(PREREQUISITE)s,
%(PREREQUISITE_MATCH)s, %(SUPPRESS_ALERT)s, %(LOOP_ALL)s, %(MATCH_ALL)s,
%(REGEX_GROUP_ANCHOR)s, %(XML_DATA)s, %(XML_ELM)s, %(XML_INFO_ELMS)s,
%(TRACK_OPPOSITE_MATCH)s, %(REQUIRE_CMD_ORIGVAL)s, %(TEST_FUNCTION_ORIGVAL)s,
%(TEST_FUNCTION_MULTIVERDICT_ORIGVAL)s, %(IS_INTERNAL)s, %(IS_DISABLED)s, %(CHECK_DEFAULT_CONFIG_FILE)s)
"""
        test_id = db_query_param(query, db_node, conf, cl)['lastrowid']

    if not db_get_id("""
SELECT auditTestId FROM govRegimeToAuditTest
WHERE auditTestId = %s AND regimeId = %s
""" % (test_id, regime_id), conf, cl):
        db_query(
            "INSERT INTO govRegimeToAuditTest (auditTestId, regimeId) " \
            + "VALUES (%s, %s)" % (test_id, regime_id), conf, cl)

        ### also map the test into the govAuditTestToDeviceType table for this
        ### device type
        ### FIX ME: db_add_dev_type(DB call) is called 224*3 times( for every audit Test for every regime)
        ### govAuditTestToDeviceType should be removed and Devicetype column can be added to govAudit Test(possible fix)
        ### govdeviceTypes table can be inserted into only once while reading from import_tests(see db_add_devicetypes)
        ### Requires change in DB design optimization will reduce 600+ db calls to 8
    if not db_get_id("""
SELECT a.auditTestId
FROM govAuditTestToDeviceType a, govDeviceTypes t
WHERE a.auditTestId = %s
AND a.deviceTypeId = t.deviceTypeId
AND deviceType = '%s'
""" % (test_id, node['meta']['type']), conf, cl):
         dev_type_id = db_add_dev_type(node['meta']['type'], conf, cl)
         db_query(
                "INSERT INTO govAuditTestToDeviceType (auditTestId, deviceTypeId) " \
                + "VALUES (%s, %s)" % (test_id, dev_type_id),
                conf, cl)

    ### handle the --governance-type requirements for this audit test
    if db_get_id("""
SELECT auditTestId FROM govAuditTestToRequirements
WHERE auditTestId = %s
""" % (test_id), conf, cl):
        db_query(
                "DELETE FROM govAuditTestToRequirements WHERE auditTestId = '%s'" \
                        % test_id, conf, cl)

    if node['AUDIT_CRITERIA'] != 'NA':
        criteria = node['AUDIT_CRITERIA'].replace(' ', '')
        for rname in criteria.split(','):
            requirement_id = db_get_id("""
SELECT requirementId
FROM govRequirements
WHERE name = '%s' AND regimeId = %s
""" % (rname, regime_id), conf, cl)
            if not requirement_id:
                print "[-] Warning: Could not get requirementId for '%s' in test: '%s'" \
                        % (rname, node['BEGIN_NODE'])
                continue
            if not db_get_id("""
SELECT auditTestId FROM govAuditTestToRequirements
WHERE auditTestId = %s AND requirementId = %s
""" % (test_id, requirement_id), conf, cl):
                db_query("""
INSERT INTO govAuditTestToRequirements
(auditTestId, requirementId)
VALUES (%s, %s)
""" % (test_id, requirement_id), conf, cl)

    return 1

def db_rm_all_gov_data(conf, cl):

    if not cl.db_rm_all_gov_data_force:
        raise NameError("[*] If you really want to remove all data, must also use --db-rm-all-data-force")

    # mysql> show tables;
    # +---------------------------------+
    # | Tables_in_governance            |
    # +---------------------------------+
    # | govAuditTestSequences           |
    # | govAuditTestToCategories        |
    # | govAuditTestToDeviceType        |
    # | govAuditTestToRequirements      |
    # | govAuditTests                   |
    # | govCategories                   |
    # | govDeviceResults                |
    # | govDeviceScores                 |
    # | govDeviceToConfigs              |
    # | govDeviceToInventoryMgrArchive  |
    # | govDeviceTypes                  |
    # | govDevices                      |
    # | govInventoryMgrArchiveToVersion |
    # | govRegimeToAuditTest            |
    # | govRegimes                      |
    # | govRequiredTests                |
    # | govRequirements                 |
    # | govRunToAuditTest               |
    # | govRunToDevice                  |
    # | govRuns                         |
    # +---------------------------------+
    # 20 rows in set (0.00 sec)

    for row in db_query("SHOW TABLES", conf, cl)['fetchall']:
        table_name = row[0]
        if table_name[0:3] == 'gov':
            ### all Governance Engine tables begin with 'gov'
            print "[+] Removing all data from table: '%s'" % table_name
            db_query("DELETE FROM %s" % table_name, conf, cl)

    return 1

def db_rm_test(conf, cl):

    return 1

def db_list_gov_types(conf, cl):

    return 1

def db_list_test(conf, cl):

    return 1

def db_read_all_tests(function_map, db_run_id, conf, cl):

    db_audit_tests = {'nodes':[], 'name_to_vars':{}, 'paths':{'<DB>':''}}

    print "[+] Importing audit tests from the '%s' database..." % conf['DB_NAME']

    # mysql> desc govAuditTests;
    # +--------------------------+---------------+------+-----+---------+----------------+
    # | Field                    | Type          | Null | Key | Default | Extra          |
    # +--------------------------+---------------+------+-----+---------+----------------+
    # | AUDITTESTID              | bigint(20)    | NO   | PRI | NULL    | auto_increment |
    # | NAME                     | varchar(256)  | YES  |     | NULL    |                |
    # | ADVISORY                 | text          | YES  |     | NULL    |                |
    # | EXAMPLE                  | varchar(4096) | YES  |     | NULL    |                |
    # | WEIGHT                   | int(11)       | YES  |     | NULL    |                |
    # | ISMATCH                  | int(11)       | YES  |     | NULL    |                |
    # | REGEX                    | varchar(512)  | YES  |     | NULL    |                |
    # | ALTREGEX                 | varchar(512)  | YES  |     | NULL    |                |
    # | ALTREGEX2                | varchar(512)  | YES  |     | NULL    |                |
    # | ALTREGEX3                | varchar(512)  | YES  |     | NULL    |                |
    # | PREREQUISITEREGEX        | varchar(512)  | YES  |     | NULL    |                |
    # | PREREQUISITEMATCH        | int(11)       | YES  |     | NULL    |                |
    # | SUPPRESSALERT            | int(11)       | YES  |     | NULL    |                |
    # | LASTRUN                  | bigint(20)    | YES  |     | NULL    |                |
    # | NEXTRUN                  | bigint(20)    | YES  |     | NULL    |                |
    # | XMLMATCH                 | int(11)       | YES  |     | NULL    |                |
    # | XMLELM                   | varchar(4096) | YES  |     | NULL    |                |
    # | XMLINFOELMS              | varchar(4096) | YES  |     | NULL    |                |
    # | TRACKOPPOSITEMATCH       | int(11)       | YES  |     | NULL    |                |
    # | REQUIRECMD               | varchar(4096) | YES  |     | NULL    |                |
    # | LOOPALL                  | int(11)       | YES  |     | NULL    |                |
    # | MATCHALL                 | int(11)       | YES  |     | NULL    |                |
    # | REGEXGROUPANCHOR         | int(11)       | YES  |     | NULL    |                |
    # | TESTFUNCTION             | varchar(4096) | YES  |     | NULL    |                |
    # | TESTFUNCTIONMULTIVERDICT | varchar(4096) | YES  |     | NULL    |                |
    # | ISINTERNAL               | int(11)       | YES  |     | NULL    |                |
    # | ISDISABLED               | int(11)       | YES  |     | NULL    |                |
    # | CHECKDEFAULTCONFIGFILE   | int(11)       | YES  |     | NULL    |                |
    # +--------------------------+---------------+------+-----+---------+----------------+
    # 28 rows in set (0.00 sec)

    db_fields = [
        'auditTestId',
        'name',
        'advisory',
        'example',
        'weight',
        'isMatch',
        'regex',
        'altRegex',
        'altRegex2',
        'altRegex3',
        'prerequisiteRegex',
        'prerequisiteMatch',
        'suppressAlert',
        'lastRun',
        'nextRun',
        'loopAll',
        'matchAll',
        'regexGroupAnchor',
        'xmlMatch',
        'xmlElm',
        'xmlInfoElms',
        'trackOppositeMatch',
        'requireCmd',
        'testFunction',
        'testFunctionMultiVerdict',
        'isDisabled',
        'isInternal',
        'checkDefaultConfigFile'
    ]

    node_key_map = {
        'auditTestId':'',
        'name':'BEGIN_NODE',
        'advisory':'ADVISORY',
        'example':'EXAMPLE',
        'weight':'WEIGHT',
        'isMatch':'MATCH',
        'regex':'REGEX',
        'altRegex':'ALT_REGEX',
        'altRegex2':'ALT_REGEX2',
        'altRegex3':'ALT_REGEX3',
        'prerequisiteRegex':'PREREQUISITE',
        'prerequisiteMatch':'PREREQUISITE_MATCH',
        'suppressAlert':'SUPPRESS_ALERT',
        'lastRun':'',
        'nextRun':'',
        'loopAll':'LOOP_ALL',
        'matchAll':'MATCH_ALL',
        'regexGroupAnchor':'REGEX_GROUP_ANCHOR',
        'xmlMatch':'XML_DATA',
        'xmlElm':'XML_ELM',
        'xmlInfoElms':'XML_INFO_ELMS',
        'trackOppositeMatch':'TRACK_OPPOSITE_MATCH',
        'requireCmd':'REQUIRE_CMD',
        'testFunction':'TEST_FUNCTION',
        'testFunctionMultiVerdict':'TEST_FUNCTION_MULTIVERDICT',
        'isDisabled':'IS_DISABLED',
        'isInternal':'IS_INTERNAL',
        'checkDefaultConfigFile':'CHECK_DEFAULT_CONFIG_FILE'
    }

    query = 'SELECT '
    for key in db_fields[0:-1]:
        query += "t.%s, " % key
    query += "t.%s" % db_fields[-1]
    query += """
FROM govAuditTests t, govRegimes r, govRegimeToAuditTest m
WHERE t.auditTestId = m.auditTestId
AND r.regimeId = m.regimeId
AND r.name = '%s'
""" % cl.governance_type

    db_audit_nodes = []

    ### now build a new audit test node from each row
    for row in db_query(query, conf, cl)['fetchall']:
        node = {'meta':{}}
        ctr = 0
        for db_val in row:
            db_field = db_fields[ctr]
            if node_key_map[db_field]:
                ### account for mappings from DB representation back to the values
                ### defined in the audit config files
                if db_field == 'weight':
                    node[node_key_map[db_field]] = int_to_weight(db_val)
                elif db_field in [
                        'isMatch', 'prerequisiteMatch', 'suppressAlert',
                        'loopAll', 'matchAll', 'regexGroupAnchor',
                        'xmlMatch', 'trackOppositeMatch', 'isDisabled', 'isInternal', 'checkDefaultConfigFile'
                    ]:
                    node[node_key_map[db_field]] = bool_to_key(db_val)
                elif db_field == 'example' or db_field == 'advisory':
                    if db_val:
                        node[node_key_map[db_field]] = db_val.splitlines()
                    else:
                        node[node_key_map[db_field]] = 'NA'
                elif db_field == 'testFunction' or db_field == 'testFunctionMultiVerdict':
                    if db_val:
                        node[node_key_map[db_field]] = function_map[db_val]
                        ### also set the _ORIGVAL key here
                        node["%s_ORIGVAL" % node_key_map[db_field]] = db_val
                elif db_field == 'requireCmd':
                    if db_val:
                        if 'cracklib-check' == db_val:
                            if cl.cracklib_check_cmd and os.path.exists(cl.cracklib_check_cmd):
                                node[node_key_map[db_field]] = cl.cracklib_check_cmd
                        if os.path.exists(db_val):
                            node[node_key_map[db_field]] = db_val
                        ### also set the _ORIGVAL key here
                        node["%s_ORIGVAL" % node_key_map[db_field]] = db_val
                else:
                    node[node_key_map[db_field]] = db_val
            else:
                node[db_field] = db_val
            ctr += 1
        node['auditTestId'] = "%d" % row[0] ### overwrite auditTestId format

        ### handle REQUIRED_TESTS audit chains
        required_tests = ''
        t_result = db_query("""
SELECT s.sequenceId, a.name, s.verdict
FROM govAuditTestSequences s, govAuditTests a
WHERE s.topAuditTestId = %s
AND s.dependentAuditTestId = a.auditTestId
ORDER BY s.sequenceId
""" % node['auditTestId'], conf, cl)['fetchall']
        if t_result:
            for dep_row in t_result:
                required_tests += "%s:%s," % (dep_row[1], int_to_verdict(dep_row[2]))
            if required_tests:
                node['REQUIRED_TESTS'] = required_tests[0:-1]

        ### Handle AUDIT_CRITERIA
        criteria = ''
        expanded_criteria = ''
        r_result = db_query(
                "SELECT requirementId FROM govAuditTestToRequirements WHERE auditTestId = %s" \
                        % node['auditTestId'], conf, cl)['fetchall']
        if r_result:
            for req_row in r_result:
                req_id = "%d" % req_row[0]
                for rrow in db_query(
                        "SELECT name, description FROM govRequirements WHERE requirementId = %s" \
                                % req_id, conf, cl)['fetchall']:
                    criteria += '%s, ' % rrow[0]
                    expanded_criteria += '%s: %s, ' % (rrow[0], rrow[1])
            if criteria:
                node['AUDIT_CRITERIA'] = criteria[0:-2]
                node['AUDIT_CRITERIA_EXPANDED'] = expanded_criteria[0:-2]
        if not criteria:
            node['AUDIT_CRITERIA'] = 'NA'
            node['AUDIT_CRITERIA_EXPANDED'] = 'NA'

        ### Get device type this test applies to
        node['meta']['type'] = db_query("""
SELECT t.deviceType
FROM govDeviceTypes t, govAuditTestToDeviceType m
WHERE m.auditTestId = %s
AND t.deviceTypeId = m.deviceTypeId
""" % node['auditTestId'], conf, cl)['fetchall'][0][0]

        node['meta']['tests_file'] = '<DB>'
        strip_dangling_newlines(node)
        rv, err_str = validate_node(node)
        if rv:
            db_audit_tests['nodes'].append(node)
            db_audit_tests['name_to_vars'][node['BEGIN_NODE']] = {}
            for field in node:
                val = node[field]
                db_audit_tests['name_to_vars'][node['BEGIN_NODE']][field] = val
        else:
            print_job_error(err_str, db_run_id, cl)

    print "    Imported %d audit tests from the '%s' database." % \
            (len(db_audit_tests['nodes']), conf['DB_NAME'])
    if not len(db_audit_tests['nodes']):
        print_job_error("Did not import any tests, exiting", db_run_id, cl)
        sys.exit(0)

    return db_audit_tests

def db_list_all_tests(function_map, db_run_id, conf, cl):

    db_audit_tests = db_read_all_tests(function_map, 0, conf, cl)

    db_audit_nodes = db_audit_tests['nodes']

    if cl.db_list_compare:
        ### now import from the filesystem and then compare
        fs_audit_tests = import_tests(function_map, db_run_id, cl.governance_type, cl)

        for fs_node in fs_audit_tests['nodes']:
            name = fs_node['BEGIN_NODE']
            found = True
            for db_node in db_audit_nodes:
                if db_node['BEGIN_NODE'] == name \
                        and db_node['meta']['type'] == fs_node['meta']['type']:
                    found = True
                    for fs_key in fs_node:

                        if fs_key not in db_node:
                            print "[-] audit test '%s': fs_key '%s' not in db_node" \
                                    % (name, fs_key)
                            continue

                        if fs_key == 'meta':
                            if fs_key in db_node:
                                for fs_sub_key in fs_node[fs_key]:
                                    if fs_sub_key in db_node[fs_key]:
                                        if fs_sub_key == 'tests_file':
                                            ### these are expected to be different - '<DB>' vs. a filesystem path
                                            continue
                                        if db_node[fs_key][fs_sub_key] != fs_node[fs_key][fs_sub_key]:
                                            print "[-] audit test '%s': db_node['%s']['%s'](%s) != fs_node['%s']['%s'](%s)" \
                                                    % (name, fs_key, fs_sub_key, db_node[fs_key], fs_key, fs_sub_key, fs_node[fs_key])
                                    else:
                                        print "[-] audit test '%s': meta fs_key '%s' not in db_node['meta']" \
                                            % (name, fs_sub_key)
                        else:
                            if fs_key in db_node:
                                if fs_key == 'REQUIRED_TESTS':
                                    if db_node[fs_key].replace(' ', '') != fs_node[fs_key].replace(' ', ''):
                                        print "[-] audit test '%s': db_node['%s'](%s) != fs_node['%s'](%s)" \
                                                % (name, fs_key, db_node[fs_key], fs_key, fs_node[fs_key])
                                else:
                                    if db_node[fs_key] != fs_node[fs_key]:
                                        print "[-] audit test '%s': db_node['%s'](%s) != fs_node['%s'](%s)" \
                                                % (name, fs_key, db_node[fs_key], fs_key, fs_node[fs_key])
            if not found:
                print "[-] Missing db_node '%s'" % name
    else:
        pprint.pprint(db_audit_nodes)

    return 1

def is_db_required(cl):
    if cl.db_list_test \
            or cl.db_list_all_tests \
            or cl.db_list_gov_types \
            or cl.db_list_version \
            or cl.db_import_test \
            or cl.db_import_all_tests \
            or cl.db_add_gov_type \
            or cl.db_rm_gov_type \
            or cl.db_rm_test \
            or cl.db_rm_all_gov_data \
            or cl.import_device_identities \
            or cl.import_third_party_devices \
            or cl.read_third_party_devices \
            or cl.delete_third_party_device \
            or cl.reimport_third_party_devices \
            or cl.rename_third_party_os_name \
            or cl.upgrade_operations \
            or cl.db_audit:
        return True
    return False

def job_file_dev_match(dev, netsight_job):
    for ndev in netsight_job['devices']:
        if dev == ndev['dev_ip']:
            return True
    return False

def cmdline():

    cl = argparse.ArgumentParser()

    ### path to main config file
    cl.add_argument("-c", "--config-file", type=str,
            help="path to configuration file", default="gov.conf")

    ### dump all DB queries to stdout for debugging
    cl.add_argument("--db-print-queries", action='store_true',
            help="print all DB queries to stdout",
            default=False)

    ### DB list flags
    cl.add_argument("--db-list-test", type=str,
            help="query the DB for the specified test in --governance-type",
            default=False)
    cl.add_argument("--db-list-all-tests", action='store_true',
            help="query the DB and list all tests from --governance-type",
            default=False)
    cl.add_argument("--db-list-compare", action='store_true',
            help="compare the DB and filesystem --governance-type audit tests",
            default=False)
    cl.add_argument("--db-list-gov-types", type=str,
            help="query the DB and list all --governance-type values",
            default=False)
    cl.add_argument("--db-list-version", action='store_true',
            help="print the DB version",
            default=False)

    ### DB import/add flags
    cl.add_argument("--db-import-test", type=str,
            help="query the DB for the specified test in --governance-type",
            default=False)
    cl.add_argument("--db-import-all-tests", action='store_true',
            help="Import all --governance-type tests",
            default=False)
    cl.add_argument("--db-add-gov-type", action='store_true',
            help="Add --governance-type to the DB",
            default=False)
    cl.add_argument("--db-gov-is-system", type=int,
            help="Set the isSystem flag for the regime",
            default=0)
    cl.add_argument("--db-gov-is-internal", type=int,
            help="Set the isInternal flag for the regime",
            default=0)

    ### audit configs with audit tests from the DB instead of the filesystem
    cl.add_argument("--db-audit", action='store_true',
            help="Audit configs with tests from the DB instead of the filesystem",
            default=False)

    ### DB delete flags
    cl.add_argument("--db-rm-test", type=str,
            help="remove the specified test from --governance-type",
            default=False)
    cl.add_argument("--db-rm-gov-type", action='store_true',
            help="remove the specified --governance-type",
            default=False)
    cl.add_argument("--db-rm-all-gov-data", action='store_true',
            help="remove all Governance data (careful!)",
            default=False)
    cl.add_argument("--db-rm-all-gov-data-force", action='store_true',
            help="Force removal of all Governance data",
            default=False)

    ### set type of governance regime to use
    cl.add_argument("--governance-type", type=str,
            help="governance regime", default=False)

    ### output modes to stdout - files in git are not updated
    cl.add_argument("-s", "--stdout", action='store_true',
            help="print everything to stdout (files in git not updated)",
            default=False)
    cl.add_argument("--print-regex-matches", action='store_true',
            help="print individual lines from regex matches", default=False)

    ### top level directories and files
    cl.add_argument("--netsight-dir", type=str,
            help="path to top level NetSight directory")
    cl.add_argument("--dotnetsight-file", type=str,
            help="path to .netsight file")
    cl.add_argument("--log-threats-file", type=str,
            help="path to bk_polls/threat.txt file")
    cl.add_argument("--jboss-properties-file", type=str,
            help="path to NSJBoss.properties file")
    cl.add_argument("--skip-log-parsing", action='store_true',
            help="do not parse threat.txt log data", default=False)
    cl.add_argument("--skip-jboss-properties", action='store_true',
            help="Do not parse the NSJBoss.properties file for DB user/pass information",
            default=False)

    ### optionally reset pygtail log tracking offset to re-read the
    ### entire logfile instead of picking up where we left off from
    ### the previous governance engine run
    cl.add_argument("--log-reset-offset", action='store_true',
            help="reset pygtail log tracking offsets to re-read all log data",
            default=False)

    ### git args
    cl.add_argument("--git-cmd", type=str,
            help="path to git command",
            default=os.path.abspath("/usr/bin/git"))
    cl.add_argument("--git-repo", type=str,
            help="path to git repository for configs")
    cl.add_argument("--git-disable", action='store_true',
            help="disable interactions with git", default=False)
    cl.add_argument("--git-enable", action='store_true',
            help="enable interactions with git", default=False)

    ### filters
    cl.add_argument("--device-ip", type=str,
            help="process a single device by IP address")
    cl.add_argument("--audit-file", type=str,
            help="audit a single config or command output file pulled from a device/switch")
    cl.add_argument("--audit-dir", type=str,
            help="audit all configs in the specified directory")

    ### archive matching strings
    cl.add_argument("--archive-version", type=str,
            help="restrict to a specific InventoryMgr archive version number /<VERSION>/<date>")
    cl.add_argument("--archive-date", type=str,
            help="restrict to a specific InventoryMgr archive date string /<version>/<DATE>")

    ### path to audit tests
    cl.add_argument("--tests-dir", type=str,
            help="path to the audit config files",
            default=os.path.abspath("./audit-tests"))
    cl.add_argument("--tests-file", type=str,
            help="Apply audit tests from a specific file regardless of OS matches",
            default=False)
    cl.add_argument("--test-title", type=str,
            help="Restrict tests to those whose titles match this string")
    cl.add_argument("--test-type", type=str,
            help="Restrict tests to those in the audit-tests/<title> directory")

    ### syslog handling
    cl.add_argument("--disable-syslog", action='store_true',
            help="disable syslog messages", default=False)

    ### misc
    cl.add_argument("--dump-tests", action='store_true',
            help="dump audit tests and exit", default=False)
    cl.add_argument("--dump-to-html", action='store_true',
            help="dump audit tests to HTML files and exit", default=False)
    cl.add_argument("--flat-output-dir", type=str,
            help="put all output files in a single flat directory",
            default=False)
    cl.add_argument("-j", "--job-file", type=str,
            help="Run audit tests specified by the --job-file create by NetSight",
            default=False)
    cl.add_argument("--import-device-identities", action='store_true', 
                    help="Import manually entered devices in deviceIdentities.properties file", 
                    default=False)
    cl.add_argument("--import-third-party-devices",action='store_true',
                    help="add/modify Entries in thirdPartyDevices.properties file",
                    default=False)
    cl.add_argument("--read-third-party-devices",action='store_true',
                    help="Fetches and displays all user imported Third Party Devices",
                    default=False)
    cl.add_argument("--delete-third-party-device",action='store_true',
                    help="deletes the sysoid from govsysoidtodevicetype table, add --device-sysoid <sysoid> to this arguement",
                    default=False)
    cl.add_argument("--device-sysoid",type=str,
                    help="specify the sysoid you want to remove",
                    default=False)
    cl.add_argument("--reimport-third-party-devices",action='store_true',
                    help="deletes all entries made by the user and reimports from the properties file",
                    default=False)
    cl.add_argument("--rename-third-party-os-name",action='store_true',
                    help="renames A previously entered OS NAME for a third party device. add --old-os-name and --new-os-name to this argument",
                    default=False)
    cl.add_argument("--old-os-name",type=str,
                    help="The OS Name Preivously added",
                    default=False)
    cl.add_argument("--new-os-name",type=str,
                    help="The new OS Name  added",
                    default=False)
    cl.add_argument("--upgrade-operations",action='store_true',
                    help="Add any operations that must be performed during an upgrade",
                    default=False)
    

    ### for Google charts integration
    cl.add_argument("--google-charts", action='store_true',
            help="build .html audit files to interface with Google Charts",
            default=False)

    ### gitstats
    cl.add_argument("--enable-gitstats", action='store_true',
            help="enable gitstats", default=False)
    cl.add_argument("--gitstats-cmd", type=str,
            help="path to gitstats command",
            default=os.path.abspath("/usr/bin/gitstats"))
    cl.add_argument("--gitstats-dir", type=str,
            help="path to gitstats output directory")

    ### command paths
    cl.add_argument("--cracklib-check-cmd", type=str,
            help="path to cracklib-check command", default=False)

    cl.add_argument("-V", "--version", action='store_true',
            help="print version and exit", default=False)
    cl.add_argument("-v", "--verbose", action='store_true',
            help="vebose mode", default=False)

    return cl.parse_args()

if __name__ == "__main__":
    sys.exit(main())
