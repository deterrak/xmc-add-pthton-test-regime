#!/bin/sh -x

### delete all data from gov* tables in the local MySQL instance
### and re-import all tests

./governance-engine.py --db-rm-all-gov-data --db-rm-all-gov-data-force $@

echo "Importing Devices from Properties"
./governance-engine.py --import-device-identities $@

for GOV_TYPE in PCI HIPAA GDPR STIG 
do
    echo $GOV_TYPE
    ./governance-engine.py --db-import-all-tests --governance-type $GOV_TYPE --db-gov-is-internal 1 $@
done

exit
